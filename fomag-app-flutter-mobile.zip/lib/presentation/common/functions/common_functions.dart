import 'package:intl/intl.dart';

class CommonFunctions {
  
  String formatDateString(String dateString, String format) {
    final date = DateTime.parse(dateString); 
    final formatter = DateFormat(format);
    return formatter.format(date); 
  }

}