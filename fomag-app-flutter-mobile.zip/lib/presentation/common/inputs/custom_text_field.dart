import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class CustomTextField extends StatefulWidget {
  final TextEditingController? controller;
  final String hintText;
  final bool isPassword;
  final TextInputType keyboardType;
  final String? Function(String?)? validator;
  final int? maxLines;
  final IconData? prefixIcon;
  final bool isVisible;
  final bool readOnly;
  final bool isEnabled;
  final VoidCallback? onTogglePasswordVisibility;

  const CustomTextField({
    super.key,
    this.controller,
    required this.hintText,
    this.isPassword = false,
    this.keyboardType = TextInputType.text,
    this.validator,
    this.maxLines,
    this.prefixIcon,
    this.isVisible = true,
    this.readOnly = false,
    this.isEnabled = true,
    this.onTogglePasswordVisibility,
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  bool obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: widget.isVisible,
      child: TextFormField(
        readOnly: widget.readOnly,
        controller: widget.controller,
        obscureText: widget.isPassword && obscureText, // Usar el estado local
        maxLines: widget.maxLines ?? 1,
        keyboardType: widget.keyboardType,
        validator: widget.validator,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          hintText: widget.hintText,
          hintStyle: TextStyle(
            color: FomagColors.black,
            fontSize: 16,
            fontFamily: 'NunitoSans',
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: FomagColors.mediumGray),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: FomagColors.darkBlue),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: FomagColors.error),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: FomagColors.error),
          ),
          prefixIcon:
              widget.prefixIcon != null
                  ? Icon(widget.prefixIcon, color: FomagColors.black)
                  : null,
          suffixIcon:
              widget.isPassword
                  ? IconButton(
                    icon: Icon(
                      obscureText ? Icons.visibility_off : Icons.visibility,
                      color: FomagColors.black,
                    ),
                    onPressed: () {
                      setState(() {
                        obscureText = !obscureText; // Alternar visibilidad
                      });
                    },
                  )
                  : null,
        ),
      ),
    );
  }
}
