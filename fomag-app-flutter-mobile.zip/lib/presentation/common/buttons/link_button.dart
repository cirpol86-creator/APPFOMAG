import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/widgets/link_text.dart';

class LinkButtonWidget extends StatefulWidget {
  const LinkButtonWidget({
    super.key,
    required this.text,
    required this.onPressed,
  });

  final String text;
  final VoidCallback onPressed;

  @override
  State<LinkButtonWidget> createState() => _LinkButtonWidgetState();
}

class _LinkButtonWidgetState extends State<LinkButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: widget.onPressed,
      child: LinkTextWidget(text: widget.text),
    );
  }
}
