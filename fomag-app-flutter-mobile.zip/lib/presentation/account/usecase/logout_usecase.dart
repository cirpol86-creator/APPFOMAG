import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:fomagapp/data/repositories/logout_repository.dart';

class LogoutUsecase {
  final LogoutRepository _repository;

  LogoutUsecase({required LogoutRepository repository})
    : _repository = repository;

  Future<Either<Failure<DioExceptionType>, void>> call(
    LogoutRequest request,
  ) async {
    return _repository(request);
  }
}
