import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/data/model/delete_account_model.dart';
import 'package:fomagapp/data/repositories/delete_account_repository.dart';

class DeleteAccountUsecase {
  final DeleteAccountRepository _deleteAccountRepository;

  DeleteAccountUsecase({
    required DeleteAccountRepository deleteAccountRepository,
  }) : _deleteAccountRepository = deleteAccountRepository;

  Future<Either<Failure<DioExceptionType>, DeleteAccountModel>>
  deleteAccount() async {
    final result = await _deleteAccountRepository.deleteAccount();

    return result.fold((failure) => Left(failure), (response) {
      final message = response.message;
      final parts = message.split('-');

      if (parts.length >= 2) {
        final title = parts[0].trim();
        final message = parts[1].trim();
        return Right(DeleteAccountModel(title: title, message: message));
      } else {
        return Left(
          Failure(
            data: DioExceptionType.badResponse,
            message: Const.defaultMessageErrorServer,
          ),
        );
      }
    });
  }
}
