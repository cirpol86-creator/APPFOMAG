import 'package:equatable/equatable.dart';
import 'package:fomagapp/data/model/delete_account_model.dart';

abstract class DeleteAccountState extends Equatable {
  const DeleteAccountState();

  @override
  List<Object?> get props => [];
}

class DeleteAccountInitial extends DeleteAccountState {}

class DeleteAccountLoading extends DeleteAccountState {}

class DeleteAccountSuccess extends DeleteAccountState {
  final DeleteAccountModel deleteAccountResponse;

  const DeleteAccountSuccess(this.deleteAccountResponse);

  @override
  List<Object?> get props => [deleteAccountResponse];
}

class DeleteAccountError extends DeleteAccountState {
  final String message;

  const DeleteAccountError({required this.message});

  @override
  List<Object?> get props => [message];
}

class Logouted extends DeleteAccountState {}
