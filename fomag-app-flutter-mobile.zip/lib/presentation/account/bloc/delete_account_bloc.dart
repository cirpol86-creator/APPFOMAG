import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/delete_account_model.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/account/usecase/delete_account_usecase.dart';
import 'package:fomagapp/presentation/account/usecase/logout_usecase.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';

import 'delete_account_event.dart';
import 'delete_account_state.dart';

class DeleteAccountBloc extends Bloc<DeleteAccountEvent, DeleteAccountState> {
  final DeleteAccountUsecase _deleteAccountUsecase;
  final LogoutUsecase _logoutUsecase;
  final TrackUserEventUseCase _trackUserEventUseCase;

  DeleteAccountBloc({
    required DeleteAccountUsecase deleteAccountUsecase,
    required LogoutUsecase logoutUsecase,
    required TrackUserEventUseCase trackUserEventUseCase,
  }) : _deleteAccountUsecase = deleteAccountUsecase,
       _logoutUsecase = logoutUsecase,
       _trackUserEventUseCase = trackUserEventUseCase,
       super(DeleteAccountInitial()) {
    on<DeleteAccount>(_onDeleteAccount);
    on<Logout>(_onLogout);
    on<TrackerEvent>(_onTrackerEvent);
  }

  Future<void> _onDeleteAccount(
    DeleteAccountEvent event,
    Emitter<DeleteAccountState> emit,
  ) async {
    emit(DeleteAccountLoading());

    final result = await _deleteAccountUsecase.deleteAccount();

    result.fold(
      (Failure failure) {
        emit(DeleteAccountInitial());
        final context = NavigationController.globalNavigatorKey.currentContext!;
        InformativeModal.show(
          context: context,
          title: 'Error',
          message: 'No se pudo eliminar la cuenta. Serás redirigido al inicio.',
          buttonText: 'Aceptar',
          onButtonPressed: () {
            NavigationController.push(Routes.home.routePath, clean: true);
          },
        );
      },
      (DeleteAccountModel response) {
        emit(DeleteAccountSuccess(response));
      },
    );
  }

  Future<void> _onLogout(Logout event, Emitter<DeleteAccountState> emit) async {
    emit(DeleteAccountLoading());

    await SecureStorageManager.clearSession();
    await NavigationController.push(Routes.splashScreen.routePath, clean: true);

    emit(Logouted());
  }

  void _onTrackerEvent(TrackerEvent event, Emitter<DeleteAccountState> emit) {
    _trackUserEventUseCase.call(
      UserEventModel(UserEventType.deleteAccount, {
        'screen_name': 'AccountPage',
      }),
    );
  }
}
