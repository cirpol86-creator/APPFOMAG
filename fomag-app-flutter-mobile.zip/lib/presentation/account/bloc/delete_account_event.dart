import 'package:equatable/equatable.dart';

abstract class DeleteAccountEvent extends Equatable {
  const DeleteAccountEvent();

  @override
  List<Object> get props => [];
}

class TrackerEvent extends DeleteAccountEvent {}

class DeleteAccount extends DeleteAccountEvent {}

class Logout extends DeleteAccountEvent {}
