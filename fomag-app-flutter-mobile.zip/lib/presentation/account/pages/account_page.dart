import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_bloc.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_event.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_state.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/modals/confirmation_modal.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';

part 'account_page_mixin.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> with AccountPageMixin {
  @override
  void initState() {
    super.initState();
    _loadUserName();
    _trackerEvent();
  }

  Future<void> _loadUserName() async {
    final user = await SecureStorageManager.decodeJwtUser();
    setState(() {
      userName = user?.name?.capitalize() ?? 'Usuario';
    });
  }

  void _trackerEvent() {
    context.read<DeleteAccountBloc>().add(TrackerEvent());
  }

  void _onChangePassword(BuildContext context) {
    NavigationController.push(Routes.passwordResetHome.routePath, clean: false);
  }

  Widget _buildUserHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      decoration: BoxDecoration(
        color: FomagColors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const CircleAvatar(
            radius: 42,
            backgroundColor: FomagColors.buttonOutline,
            child: Icon(Icons.person, size: 52, color: Colors.white),
          ),
          const SizedBox(height: 16),
          Text(
            userName ?? 'Usuario',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              fontFamily: 'NunitoSans',
              color: FomagColors.black,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Future<void> showDeleteAccountDialog(BuildContext context) async {
    bool isChecked = false;

    await showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              contentPadding: const EdgeInsets.all(20),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: const [
                      Icon(
                        Icons.warning_amber_rounded,
                        color: Colors.black54,
                        size: 24,
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '¿Está seguro de eliminar su cuenta?\nEsta acción es irreversible.',
                          style: TextStyle(
                            fontFamily: 'NunitoSans',
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Checkbox(
                        value: isChecked,
                        onChanged: (val) {
                          setState(() {
                            isChecked = val ?? false;
                          });
                        },
                      ),
                      const Expanded(
                        child: Text(
                          'Sí, eliminar mi cuenta',
                          style: TextStyle(
                            fontFamily: 'NunitoSans',
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text(
                          'Cancelar',
                          style: TextStyle(
                            color: FomagColors.black,
                            fontFamily: 'NunitoSans',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed:
                            isChecked
                                ? () {
                                  context.read<DeleteAccountBloc>().add(
                                    DeleteAccount(),
                                  );
                                }
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE53935),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 12,
                          ),
                        ),
                        child: const Text(
                          'Eliminar cuenta',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'NunitoSans',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _onLogout() {
    NavigationController.push(Routes.splashScreen.routePath, clean: true);
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<DeleteAccountBloc, DeleteAccountState>(
      listener: (context, state) {
        if (state is DeleteAccountLoading) {
          setLoading(true);
        }
        if (state is Logouted) {
          setLoading(false);
        }
        if (state is DeleteAccountSuccess) {
          _deleteAccountSuccess(state);
        }
        if (state is DeleteAccountError) {
          _deleteAccountError(state);
        }
      },
      child: ScaffoldMain(
        isLoading: loading,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),

            _buildUserHeader(context),

            const Divider(height: 1),

            _AccountOptionTile(
              icon: Icons.vpn_key_outlined,
              text: 'Cambiar contraseña',
              onTap: () => _onChangePassword(context),
            ),
            const Divider(height: 1),

            _AccountOptionTile(
              icon: Icons.delete_outline,
              text: 'Eliminar cuenta',
              onTap: () => showDeleteAccountDialog(context),
              iconColor: Colors.red,
              textColor: Colors.red,
            ),
            const Divider(height: 1),

            _AccountOptionTile(
              icon: Icons.logout,
              text: 'Cerrar sesión',
              onTap:
                  () => ConfirmationModal.show(
                    context: context,
                    title: 'Cerrar sesión',
                    message: '¿Desea cerrar la sesión?',
                    onButtonPressed: NavigationController.pop,
                    iconColor: FomagColors.black,
                    cancelButtonText: 'Sí, cerrar sesión',
                    secondaryButtonColor: FomagColors.buttonPrincipal,
                    buttonText: 'No',
                    onCancelPressed: () {
                      NavigationController.pop();
                      context.read<DeleteAccountBloc>().add(Logout());
                    },
                    messageIcon: Icons.warning_amber_outlined,
                  ),
            ),
            const Divider(height: 1),
          ],
        ),
      ),
    );
  }
}

extension StringExtensions on String {
  String capitalize() {
    return split(' ')
        .map(
          (word) =>
              word.isNotEmpty
                  ? word[0].toUpperCase() + word.substring(1).toLowerCase()
                  : '',
        )
        .join(' ');
  }
}

class _AccountOptionTile extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final Color? iconColor;
  final Color? textColor;

  const _AccountOptionTile({
    required this.icon,
    required this.text,
    required this.onTap,
    this.iconColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: iconColor ?? FomagColors.black),
      minLeadingWidth: 0,
      contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
      title: Text(
        text,
        style: TextStyle(
          color: textColor ?? FomagColors.black,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          fontFamily: 'NunitoSans',
        ),
      ),
      onTap: onTap,
    );
  }
}
