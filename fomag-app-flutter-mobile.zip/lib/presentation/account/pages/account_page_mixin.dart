part of 'account_page.dart';

mixin AccountPageMixin<T extends StatefulWidget> on State<T> {
  String? userName;
  bool loading = false;

  void setLoading(bool value) {
    setState(() {
      loading = value;
    });
  }

  void _deleteAccountSuccess(DeleteAccountSuccess state) {
    InformativeModal.show(
      context: context,
      title: state.deleteAccountResponse.title,
      message: state.deleteAccountResponse.message,
      buttonText: 'Continuar',
      onButtonPressed: () {
        NavigationController.push(Routes.login.routePath);
      },
      topIcon: Icons.check_circle_outline_rounded,
      iconColor: FomagColors.greenButton,
    );
  }

  void _deleteAccountError(DeleteAccountError state) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(state.message), backgroundColor: Colors.red),
    );
    Navigator.pop(context);
  }

  Future<void> _loadUserName() async {
    final user = await SecureStorageManager.decodeJwtUser();
    setState(() {
      userName = user?.name?.capitalize() ?? 'Usuario';
    });
  }

  void _onChangePassword(BuildContext context) {
    NavigationController.push(Routes.passwordResetHome.routePath, clean: false);
  }

  Widget _buildUserHeader(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      decoration: BoxDecoration(
        color: FomagColors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const CircleAvatar(
            radius: 42,
            backgroundColor: FomagColors.buttonOutline,
            child: Icon(Icons.person, size: 52, color: Colors.white),
          ),
          const SizedBox(height: 16),
          Text(
            userName ?? 'Usuario',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              fontFamily: 'NunitoSans',
              color: FomagColors.black,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Future<void> showDeleteAccountDialog(BuildContext context) async {
    bool isChecked = false;

    await showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              contentPadding: const EdgeInsets.all(20),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: const [
                      Icon(
                        Icons.warning_amber_rounded,
                        color: Colors.black54,
                        size: 24,
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '¿Está seguro de eliminar su cuenta?\nEsta acción es irreversible.',
                          style: TextStyle(
                            fontFamily: 'NunitoSans',
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Checkbox(
                        value: isChecked,
                        onChanged: (val) {
                          setState(() {
                            isChecked = val ?? false;
                          });
                        },
                      ),
                      const Expanded(
                        child: Text(
                          'Sí, eliminar mi cuenta',
                          style: TextStyle(
                            fontFamily: 'NunitoSans',
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text(
                          'Cancelar',
                          style: TextStyle(
                            color: FomagColors.black,
                            fontFamily: 'NunitoSans',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed:
                            isChecked
                                ? () {
                                  context.read<DeleteAccountBloc>().add(
                                    DeleteAccount(),
                                  );
                                }
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE53935),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 12,
                          ),
                        ),
                        child: const Text(
                          'Eliminar cuenta',
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'NunitoSans',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
