import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/repositories/terms_conditions_repository.dart';

class TermsConditionsUsecase {
  final TermsConditionsRepository _termsConditionsRepository;

  TermsConditionsUsecase({
    required TermsConditionsRepository termsConditionsRepository,
  }) : _termsConditionsRepository = termsConditionsRepository;

  Future<Either<Failure<DioExceptionType>, String>>getTerms() async {
    return _termsConditionsRepository.fetchTermsAndConditions();
  }
}