import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_bloc.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_event.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_state.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

// ... imports sin cambios

class TermsConditionsModal extends StatelessWidget {
  final VoidCallback? onButtonPressed;

  const TermsConditionsModal({super.key, this.onButtonPressed});

  static void show({
    required BuildContext context,
    VoidCallback? onButtonPressed,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (_) => BlocProvider.value(
            value: BlocProvider.of<TermsConditionsBloc>(context)
              ..add(TermsConditionsSubmitted()),
            child: TermsConditionsModal(onButtonPressed: onButtonPressed),
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: FomagColors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 500),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: BlocBuilder<TermsConditionsBloc, TermsConditionsState>(
            builder: (context, state) {
              if (state is TermsConditionsLoading) {
                return const Center(child: CircularProgressIndicator());
              } else if (state is TermsConditionsFailure) {
                return Center(
                  child: Text(
                    state.message,
                    style: const TextStyle(fontSize: 16),
                  ),
                );
              } else if (state is TermsConditionsSuccess) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Encabezado: título y botón cerrar alineados
                    Row(
                      children: [
                        const SizedBox(width: 8),
                        Expanded(
                          child: Center(
                            child: Text(
                              'Términos y Condiciones',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.normal,
                                color: FomagColors.neutralTitleText,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.of(context).pop(),
                          tooltip: 'Cerrar',
                        ),
                      ],
                    ),
                    const Divider(),

                    // Contenido scrollable
                    Expanded(
                      child: SingleChildScrollView(
                        child: Html(
                          data: state.terms,
                          style: {
                            "body": Style(
                              fontSize: FontSize(14),
                              fontFamily: 'NunitoSans',
                              color: FomagColors.black,
                            ),
                          },
                        ),
                      ),
                    ),
                    const Divider(),

                    // Botones
                    if (onButtonPressed != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(),
                              child: Text(
                                'Cancelar',
                                style: TextStyle(
                                  color: FomagColors.black,
                                  fontFamily: 'NunitoSans',
                                ),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: onButtonPressed,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: FomagColors.buttonPrincipal,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 24,
                                  vertical: 12,
                                ),
                              ),
                              child: Text(
                                'Aceptar',
                                style: TextStyle(
                                  fontFamily: 'NunitoSans',
                                  color: FomagColors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                );
              }
              return const SizedBox();
            },
          ),
        ),
      ),
    );
  }
}
