import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_event.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_state.dart';
import 'package:fomagapp/presentation/terms_conditions/usecase/terms_conditions_usecase.dart';

class TermsConditionsBloc extends Bloc<TermsConditionsEvent, TermsConditionsState> {
  final TermsConditionsUsecase  _termsConditionsUsecase;

  TermsConditionsBloc({required TermsConditionsUsecase termsConditionsUsecase})
    : _termsConditionsUsecase = termsConditionsUsecase,
      super(TermsConditionsLoading()) {
    on<TermsConditionsSubmitted>(_onTermsCondition);
  }

  Future<void> _onTermsCondition(
    TermsConditionsSubmitted event,
    Emitter<TermsConditionsState> emit,
  ) async {
    emit(TermsConditionsLoading());
    final result = await _termsConditionsUsecase.getTerms();

    result.fold(
      (Failure failure) {
        emit(TermsConditionsFailure(message: mapFailureToMessage(failure)));
      },
      (response) {
        emit(TermsConditionsSuccess(terms: response));
      },
    );
  }
}