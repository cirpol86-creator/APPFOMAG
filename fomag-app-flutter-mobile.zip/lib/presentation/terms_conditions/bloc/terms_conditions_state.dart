import 'package:equatable/equatable.dart';

abstract class TermsConditionsState extends Equatable {
  @override
  List<Object?> get props => [];
}

class TermsConditionsLoading extends TermsConditionsState {}

class TermsConditionsFailure extends TermsConditionsState {
  final String message;
  TermsConditionsFailure({required this.message});

  @override
  List<Object?> get props => [message];
}

class TermsConditionsSuccess extends TermsConditionsState {
  final String terms;

  TermsConditionsSuccess({required this.terms});

  @override
  List<Object?> get props => [terms];
}