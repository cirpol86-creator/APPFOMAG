abstract class TermsConditionsEvent {}

class TermsConditionsSubmitted extends TermsConditionsEvent {

  TermsConditionsSubmitted();
}