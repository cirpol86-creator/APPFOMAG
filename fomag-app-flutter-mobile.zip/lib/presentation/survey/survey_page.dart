import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/data/model/survey_question.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

part 'survey_page_mixin.dart';

class SurveyPage extends StatefulWidget {
  final List<SurveyQuestion> questions;

  const SurveyPage({super.key, required this.questions});

  @override
  State<SurveyPage> createState() => _SurveyPageState();
}

class _SurveyPageState extends State<SurveyPage> with SurveyPageMixin {
  @override
  Widget build(BuildContext context) {
    final currentQuestion = widget.questions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            const Text(
              'Vamos a comenzar...',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: FomagColors.neutralBlueTitle,
              ),
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: progress,
              color: FomagColors.buttonPrimary,
              backgroundColor: FomagColors.buttonOutline,
              borderRadius: BorderRadius.circular(12),
              minHeight: 11,
            ),
            const SizedBox(height: 24),
            Text(
              currentQuestion.question,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: FomagColors.neutralTitleText,
              ),
            ),
            const SizedBox(height: 32),
            ...List.generate(currentQuestion.options.length, (index) {
              final isSelected = currentQuestion.selectedOption == index;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: GestureDetector(
                  onTap: () => selectOption(index),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                      horizontal: 24,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected ? FomagColors.success : Colors.white,
                      border: Border.all(
                        color:
                            isSelected
                                ? FomagColors.success
                                : FomagColors.buttonOutline,
                        width: 1.5,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          currentQuestion.options[index],
                          style: TextStyle(
                            color:
                                isSelected
                                    ? Colors.white
                                    : FomagColors.neutralTitleText,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                          ),
                        ),
                        if (isSelected) SvgManager.checkBordered,
                      ],
                    ),
                  ),
                ),
              );
            }),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                OutlinedButton.icon(
                  onPressed:
                      currentQuestionIndex > 0 ? goToPreviousQuestion : null,
                  icon: SvgManager.arrowLeftSimple,
                  label: const Text(
                    'Anterior',
                    style: TextStyle(color: FomagColors.neutralTitleText),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: FomagColors.buttonOutline),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 16,
                    ),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed:
                      currentQuestion.selectedOption != null
                          ? goToNextQuestion
                          : null,
                  icon:
                      currentQuestionIndex == widget.questions.length - 1
                          ? const Text(
                            'Finalizar',
                            style: TextStyle(color: Colors.white),
                          )
                          : const Text(
                            'Siguiente',
                            style: TextStyle(
                              color: FomagColors.neutralTitleText,
                            ),
                          ),
                  label:
                      currentQuestionIndex == widget.questions.length - 1
                          ? SvgManager.getSvgWithColor(
                            SvgManager.arrowRightSimplePath,
                            Colors.white,
                          )
                          : SvgManager.getSvgWithColor(
                            SvgManager.arrowRightSimplePath,
                            FomagColors.neutralTitleText,
                          ),
                  style:
                      currentQuestionIndex == widget.questions.length - 1
                          ? OutlinedButton.styleFrom(
                            backgroundColor: FomagColors.buttonPrimary,
                            side: BorderSide.none,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 16,
                            ),
                          )
                          : OutlinedButton.styleFrom(
                            side: BorderSide(color: FomagColors.buttonOutline),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 16,
                            ),
                          ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
