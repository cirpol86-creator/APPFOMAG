part of 'survey_page.dart';

mixin SurveyPageMixin<T extends StatefulWidget> on State<T> {
  int currentQuestionIndex = 0;

  void goToNextQuestion() {
    if (currentQuestionIndex < (widget as SurveyPage).questions.length - 1) {
      setState(() {
        currentQuestionIndex++;
      });
    } else {
      NavigationController.pop();
    }
  }

  void goToPreviousQuestion() {
    if (currentQuestionIndex > 0) {
      setState(() {
        currentQuestionIndex--;
      });
    }
  }

  void selectOption(int index) {
    setState(() {
      (widget as SurveyPage).questions[currentQuestionIndex].selectedOption = index;
    });
  }

  double get progress => (currentQuestionIndex + 1) / (widget as SurveyPage).questions.length;
}