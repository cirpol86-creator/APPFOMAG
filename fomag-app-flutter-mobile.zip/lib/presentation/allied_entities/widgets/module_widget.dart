import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/green_button.dart';

class ModuleWidget extends StatelessWidget {
  final String title;
  final String subtitle;
  final String buttontext;
  final VoidCallback onPressed;
  const ModuleWidget({
    super.key,
    required this.title,
    required this.subtitle,
    required this.buttontext,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.7
                  ..color = FomagColors.neutralBlueTitle,
          ),
        ),
        const SizedBox(height: 16),
        Text(
          subtitle,
          style: TextStyle(
            color: FomagColors.black,
            fontSize: 16,
            fontWeight: FontWeight.w700,
            fontFamily: 'NunitoSans',
          ),
        ),
        const SizedBox(height: 16),
        GreenButton(
          text: buttontext,
          onPressed: onPressed,
          buttonTextAlignment: MainAxisAlignment.center,
        ),
      ],
    );
  }
}
