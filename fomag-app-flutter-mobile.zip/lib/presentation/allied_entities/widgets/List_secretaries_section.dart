import 'package:flutter/widgets.dart';
import 'package:fomagapp/data/model/education_secretaries_model.dart';
import 'package:fomagapp/presentation/allied_entities/widgets/list_secretaries_widget.dart';

class ListSecretariesSection extends StatefulWidget {
  final TextEditingController searchController;
  final VoidCallback onSearchPressed;
  final List<SecretaryModel> secretarias;
  final int currentPage;
  final int totalPages;
  final VoidCallback onNextPage;
  final VoidCallback onPreviousPage;

  const ListSecretariesSection({
    super.key,
    required this.searchController,
    required this.onSearchPressed,
    required this.secretarias,
    required this.currentPage,
    required this.totalPages,
    required this.onNextPage,
    required this.onPreviousPage,
  });

  @override
  State<ListSecretariesSection> createState() => _ListSecretariesSectionState();
}

class _ListSecretariesSectionState extends State<ListSecretariesSection> {
  @override
  Widget build(BuildContext context) {
    return ListSecretariesWidget(
      searchController: widget.searchController,
      onSearchPressed: widget.onSearchPressed,
      secretarias: widget.secretarias,
      currentPage: widget.currentPage,
      totalPages: widget.totalPages,
      onNextPage: widget.onNextPage,
      onPreviousPage: widget.onPreviousPage,
    );
  }
}
