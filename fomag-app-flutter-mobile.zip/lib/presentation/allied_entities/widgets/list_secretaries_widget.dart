import 'package:flutter/material.dart';
import 'package:fomagapp/data/model/education_secretaries_model.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:url_launcher/url_launcher.dart';

class ListSecretariesWidget extends StatelessWidget {
  final TextEditingController searchController;
  final VoidCallback onSearchPressed;
  final List<SecretaryModel> secretarias;
  final int currentPage;
  final int totalPages;
  final VoidCallback onNextPage;
  final VoidCallback onPreviousPage;

  const ListSecretariesWidget({
    super.key,
    required this.searchController,
    required this.onSearchPressed,
    required this.secretarias,
    required this.currentPage,
    required this.totalPages,
    required this.onNextPage,
    required this.onPreviousPage,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Listado de Secretarias de Educación',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              fontFamily: 'NunitoSans',
              foreground:
                  Paint()
                    ..style = PaintingStyle.stroke
                    ..strokeWidth = 0.7
                    ..color = FomagColors.neutralBlueTitle,
            ),
          ),
        ),
        const SizedBox(height: 20),
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Buscar',
            style: TextStyle(
              color: FomagColors.black,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: 'NunitoSans',
            ),
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: searchController,
          decoration: InputDecoration(
            hintText: 'Buscar secretaría...',
            filled: true,
            fillColor: Colors.white,
            suffixIcon: const Icon(Icons.search, size: 30),
            contentPadding: const EdgeInsets.symmetric(
              vertical: 14.0,
              horizontal: 14.0,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: const BorderSide(
                color: FomagColors.black,
                width: 1.5,
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        PrimaryButton(text: 'Buscar', onPressed: onSearchPressed),
        const SizedBox(height: 14),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: secretarias.length,
          itemBuilder: (context, index) {
            final secretaria = secretarias[index];
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      'assets/images/ic_human_logo.jpg',
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          secretaria.nombre,
                          style: const TextStyle(
                            color: FomagColors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'NunitoSans',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Align(
                          alignment: Alignment.centerRight,
                          child: GestureDetector(
                            onTap: () {
                              final uri = Uri.tryParse(secretaria.url);
                              if (uri != null) {
                                launchUrl(
                                  uri,
                                  mode: LaunchMode.externalApplication,
                                );
                              }
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Text(
                                  'Ingrese aquí',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: FomagColors.black,
                                    fontSize: 14,
                                    fontFamily: 'NunitoSans',
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                                SizedBox(width: 4),
                                Icon(Icons.arrow_forward, size: 18),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 16),
        if ((searchController.text.isEmpty && totalPages > 1) ||
            (searchController.text.isNotEmpty && secretarias.length >= 20))
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (currentPage > 1)
                IconButton(
                  onPressed: onPreviousPage,
                  icon: const Icon(
                    Icons.arrow_back,
                    color: FomagColors.neutralBlueTitle,
                  ),
                ),
              Text(
                'Página $currentPage de $totalPages',
                style: const TextStyle(
                  color: FomagColors.neutralBlueTitle,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'NunitoSans',
                ),
              ),
              if (currentPage < totalPages)
                IconButton(
                  onPressed: onNextPage,
                  icon: const Icon(
                    Icons.arrow_forward,
                    color: FomagColors.neutralBlueTitle,
                  ),
                ),
            ],
          ),
      ],
    );
  }
}
