import 'package:flutter/material.dart';
import 'package:fomagapp/data/model/education_secretaries_model.dart';
import 'package:fomagapp/data/repositories/education_secretaries_repository.dart';
import 'package:fomagapp/presentation/allied_entities/widgets/List_secretaries_section.dart';

import 'package:fomagapp/presentation/allied_entities/widgets/module_widget.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';
import 'package:url_launcher/url_launcher.dart';

class AlliedEntitiesPage extends StatefulWidget {
  const AlliedEntitiesPage({super.key});

  @override
  State<AlliedEntitiesPage> createState() => _AlliedEntitiesPageState();
}

class _AlliedEntitiesPageState extends State<AlliedEntitiesPage> {
  final SecretaryRepository _repository = SecretaryRepository();
  final TextEditingController _searchController = TextEditingController();
  List<SecretaryModel> _currentList = [];
  int _currentPage = 1;
  String _searchQuery = '';
  final ScrollController _listScrollController = ScrollController();
  final GlobalKey _listKey = GlobalKey();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchFieldChanged);
    _loadData();
  }

  Future<void> _loadData() async {
    await _repository.loadSecretarias();
    setState(() {
      _currentList = _repository.getSecretarias(
        page: _currentPage,
        query: _searchQuery.isNotEmpty ? _searchQuery : null,
      );
    });
  }

  void _nextPage() {
    if (_currentPage < _repository.totalPages) {
      setState(() {
        _currentPage++;
        _currentList = _repository.getSecretarias(
          page: _currentPage,
          query: _searchQuery.isNotEmpty ? _searchQuery : null,
        );
      });
      _scrollToTop();
    }
  }

  void _previousPage() {
    if (_currentPage > 1) {
      setState(() {
        _currentPage--;
        _currentList = _repository.getSecretarias(
          page: _currentPage,
          query: _searchQuery.isNotEmpty ? _searchQuery : null,
        );
      });
      _scrollToTop();
    }
  }

  void _onSearchPressed() {
    setState(() {
      final query = _searchController.text.trim().toLowerCase();
      if (query.isEmpty) return;
      _currentPage = 1;
      _searchQuery = _searchController.text.trim().toLowerCase();
      _currentList = _repository.getSecretarias(
        page: _currentPage,
        query: _searchQuery,
      );
    });
  }

  void _onSearchFieldChanged() {
    if (_searchController.text.trim().isEmpty && _searchQuery.isNotEmpty) {
      setState(() {
        _searchQuery = '';
        _currentPage = 1;
        _currentList = _repository.getSecretarias(page: _currentPage);
      });
    }
  }

  void _scrollToTop() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final contextTarget = _listKey.currentContext;
      if (contextTarget != null) {
        Scrollable.ensureVisible(
          contextTarget,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          alignment: 0, // 0 = top
        );
      }
    });
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchFieldChanged);
    _searchController.dispose();
    _listScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldMain(
      body: SingleChildScrollView(
        controller: _scrollController,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              const SizedBox(height: 24),
              ModuleWidget(
                title: 'HORUS',
                subtitle: 'Módulo de autogestión de servicios de salud',
                buttontext: 'Ir a Horus',
                onPressed: () {
                  final uri = Uri.tryParse('https://horus2.horus-health.com/');
                  if (uri != null) {
                    launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
              ),
              const SizedBox(height: 24),
              ModuleWidget(
                title: 'HUMANO en línea',
                subtitle:
                    'Módulo donde podrá validar el estado de sus prestaciones',
                buttontext: 'Ir a Humano',
                onPressed: () {
                  final uri = Uri.tryParse(
                    'https://humano.educacionbogota.edu.co/HumanoEL/Ingresar.aspx?Ent=RHBogota',
                  );
                  if (uri != null) {
                    launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
              ),
              const SizedBox(height: 30),
              ListSecretariesSection(
                key: _listKey,
                searchController: _searchController,
                onSearchPressed: _onSearchPressed,
                secretarias: _currentList,
                currentPage: _currentPage,
                totalPages: _repository.totalPages,
                onNextPage: _nextPage,
                onPreviousPage: _previousPage,
              ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
