import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class SecondaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool iconAfterText; // Indica si el icono va después del texto
  final bool enabled;

  const SecondaryButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.icon,
    this.iconAfterText = false, // Por defecto el icono va antes del texto
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: enabled ? onPressed : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: FomagColors.secondaryColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.8
                  ..color = Colors.white,
          ),
        ),
      ),
    );
  }
}
