import 'package:flutter/material.dart';

class BorderedButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final bool enabled;

  const BorderedButton({
    super.key,
    required this.text,
    required this.onPressed,

    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: enabled ? onPressed : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.white),
          ),
          elevation: 0,
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.8
                  ..color = Colors.white,
          ),
        ),
      ),
    );
  }
}
