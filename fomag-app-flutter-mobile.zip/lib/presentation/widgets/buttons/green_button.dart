import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class GreenButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool iconAfterText;
  final bool enabled;
  final MainAxisAlignment buttonTextAlignment;

  const GreenButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.icon,
    this.buttonTextAlignment = MainAxisAlignment.start,
    this.iconAfterText = false,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: enabled ? onPressed : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: FomagColors.greenButton,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
        ),
        child: Row(
          mainAxisAlignment: buttonTextAlignment,
          children: [
            if (icon != null && !iconAfterText) Icon(icon, color: Colors.white),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                text,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'NunitoSans',
                  foreground:
                      Paint()
                        ..style = PaintingStyle.stroke
                        ..strokeWidth = 0.8
                        ..color = Colors.white,
                ),
              ),
            ),
            if (icon != null && iconAfterText)
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Icon(icon, color: Colors.white),
              ),
          ],
        ),
      ),
    );
  }
}
