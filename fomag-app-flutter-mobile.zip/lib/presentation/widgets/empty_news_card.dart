import 'package:flutter/material.dart';

class EmptyNewsCard extends StatelessWidget {
  const EmptyNewsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F6F6),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE0E0E0), width: 1),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            'Categoría',
            style: TextStyle(
              color: Color(0xFF8B8B8B),
              fontSize: 14,
              fontWeight: FontWeight.w400,
              fontFamily: 'NunitoSans',
            ),
          ),
          const SizedBox(height: 12),
          const Icon(
            Icons.sentiment_satisfied_alt,
            size: 40,
            color: Color(0xFF8B8B8B),
          ),
          const SizedBox(height: 8),
          const Text(
            'No hay novedades',
            style: TextStyle(
              color: Color(0xFF222222),
              fontSize: 20,
              fontWeight: FontWeight.w600,
              fontFamily: 'NunitoSans',
            ),
          ),
        ],
      ),
    );
  }
}
