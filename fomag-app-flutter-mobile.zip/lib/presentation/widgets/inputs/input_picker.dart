import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class RoundedPicker<T> extends StatefulWidget {
  final String label;
  final String hintText;
  final List<String>? options;
  final void Function(T?) onChanged;
  final T? selectedValue;
  final String? Function(T?)? validator;
  final List<DropdownMenuItem<T>>? buildItems;
  final bool disabled;

  RoundedPicker({
    super.key,
    required this.label,
    required this.hintText,
    required this.onChanged,
    required this.selectedValue,
    this.validator,
    this.options,
    this.buildItems,
    this.disabled = false,
  }) : assert(
         (options?.isNotEmpty == true && buildItems == null) ||
             (options == null && buildItems != null),
         'Solo uno de los parámetros "options" o "buildItems" debe ser proporcionado, no ambos.',
       );

  @override
  State<RoundedPicker<T>> createState() => _RoundedPickerState<T>();
}

class _RoundedPickerState<T> extends State<RoundedPicker<T>> {
  String? _validationError;

  @override
  void initState() {
    super.initState();
  }

  List<DropdownMenuItem<T>> _buildItems() {
    if (widget.buildItems != null) {
      return widget.buildItems!;
    }

    if (widget.options != null) {
      return widget.options!.map((String value) {
        return DropdownMenuItem<T>(value: value as T, child: Text(value));
      }).toList();
    }

    return [];
  }

  String? _customValidator(T? value) {
    String? result;

    if (widget.validator == null) return null;

    result = widget.validator!(value);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _validationError = result;
        });
      }
    });

    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            color:
                _validationError != null
                    ? FomagColors.redButton
                    : FomagColors.black,
            fontFamily: 'NunitoSans',
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<T>(
          value: widget.selectedValue,
          isExpanded: true,
          icon: Icon(Icons.expand_more_rounded, color: FomagColors.black),
          decoration: InputDecoration(
            hintText: widget.hintText,
            fillColor: FomagColors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 8,
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.primaryColor,
                width: 2,
              ),
            ),
          ),
          items: _buildItems(),
          onChanged: widget.disabled ? null : widget.onChanged,
          validator: _customValidator,
          errorBuilder: (context, error) {
            return Text(error, style: TextStyle(color: FomagColors.redButton));
          },
        ),
      ],
    );
  }
}
