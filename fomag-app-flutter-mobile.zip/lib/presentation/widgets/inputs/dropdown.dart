import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class InputDropdown<T> extends StatefulWidget {
  final String label;
  final String hintText;
  final List<DropdownMenuItem<String>> options;
  final void Function(T? value)? onChanged;
  final String? selectedValue;
  final String? Function(String?)? validator;

  const InputDropdown({
    super.key,
    required this.label,
    required this.hintText,
    required this.options,
    this.onChanged,
    this.selectedValue,
    this.validator,
  });

  @override
  State<InputDropdown> createState() => _InputDropdownState<T>();
}

class _InputDropdownState<T> extends State<InputDropdown> {
  String? _validationError;

  @override
  void initState() {
    super.initState();
  }

  String? _customValidator(String? value) {
    String? result;

    if (widget.validator != null) {
      result = widget.validator!(value);
    } else {
      if (value == null || value.isEmpty) {
        result = 'Seleccione una opción';
      } else {
        result = null;
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _validationError = result;
        });
      }
    });

    return result;
  }

  @override
  Widget build(BuildContext context) {
    return FormField<String>(
      initialValue: widget.selectedValue,
      validator: widget.validator,
      builder: (FormFieldState<String> state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.label,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color:
                    _validationError != null
                        ? FomagColors.redButton
                        : FomagColors.black,
                fontFamily: 'NunitoSans',
              ),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: widget.selectedValue,
              isExpanded: true,
              icon: Icon(Icons.expand_more_rounded, color: FomagColors.black),
              decoration: InputDecoration(
                hintText: widget.hintText,
                fillColor: FomagColors.white,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(
                    color: FomagColors.primaryColor,
                    width: 2,
                  ),
                ),
              ),
              items: widget.options,
              onChanged: (value) {
                if (widget.onChanged != null) {
                  widget.onChanged!(value);
                }
              },
              validator: _customValidator,
            ),
          ],
        );
      },
    );
  }
}
