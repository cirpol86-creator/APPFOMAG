import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class RoundedEntry extends StatefulWidget {
  final TextEditingController? controller;
  final String label;
  final String hintText;
  final bool isPassword;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;

  const RoundedEntry({
    super.key,
    this.controller,
    required this.label,
    this.hintText = '',
    this.isPassword = false,
    this.validator,
    this.keyboardType,
    this.inputFormatters,
  });

  @override
  State<RoundedEntry> createState() => _RoundedEntryState();
}

class _RoundedEntryState extends State<RoundedEntry> {
  bool _obscureText = true;
  String? _validationError;

  @override
  void initState() {
    super.initState();
    _obscureText = widget.isPassword;
  }

  void _toggleVisibility() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  String? _customValidator(String? value) {
    String? result;

    if (widget.validator != null) {
      result = widget.validator!(value);
    } else {
      if (value == null || value.isEmpty) {
        result = 'Este campo es obligatorio';
      } else {
        result = null;
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _validationError = result;
        });
      }
    });

    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            color:
                _validationError != null
                    ? FomagColors.redButton
                    : FomagColors.black,
            fontFamily: 'NunitoSans',
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: widget.controller,
          cursorColor: FomagColors.primaryColor,
          keyboardType: widget.keyboardType,
          inputFormatters: widget.inputFormatters,
          obscureText: widget.isPassword ? _obscureText : false,
          validator: _customValidator,
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
            hintText: widget.hintText,
            fillColor: FomagColors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.primaryColor,
                width: 2,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.redButton,
                width: 1,
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.redButton,
                width: 1,
              ),
            ),
            errorStyle: const TextStyle(
              color: FomagColors.redButton,
              fontSize: 12,
              fontWeight: FontWeight.normal,
              height: 1.2,
            ),
            suffixIcon:
                widget.isPassword
                    ? IconButton(
                      onPressed: _toggleVisibility,
                      icon: Icon(
                        _obscureText == false
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: FomagColors.black,
                      ),
                    )
                    : null,
          ),
        ),
      ],
    );
  }
}
