import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class ErrorText extends StatelessWidget {
  final String message;
  const ErrorText({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(top: 16),
        child: Text(
          message,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: FomagColors.errorOtp,
            fontSize: 16,
            fontFamily: 'NunitoSans',
          ),
        ),
      ),
    );
  }
}
