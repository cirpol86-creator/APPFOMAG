import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;

class DownloadPdfUseCase {
  /// Descarga un PDF desde [url] y lo guarda como [filename].
  /// Devuelve la ruta del archivo guardado (interno).
  Future<String> execute({
    required String url,
    required String filename,
  }) async {
    // Validar URL
    final uri = Uri.tryParse(url);
    if (uri == null || !uri.isAbsolute || !uri.path.endsWith('.pdf')) {
      throw Exception("URL inválida o no apunta a un PDF.");
    }

    try {
      // Descargar el archivo
      final response = await http.get(uri);
      if (response.statusCode != 200) {
        throw Exception(
          "Error al descargar el PDF. Código: ${response.statusCode}",
        );
      }

      // Validar contenido mínimo del archivo
      final bytes = response.bodyBytes;
      if (!String.fromCharCodes(bytes.take(4)).contains('%PDF')) {
        throw Exception("El archivo descargado no parece ser un PDF válido.");
      }

      // Obtener directorio de almacenamiento interno (sin permisos)
      final directory = await getApplicationDocumentsDirectory();
      final filePath = path.join(directory.path, filename);

      // Guardar el archivo
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
      }
      await file.writeAsBytes(bytes);

      return file.path;
    } catch (e) {
      throw Exception("Fallo al descargar o guardar el PDF: $e");
    }
  }
}
