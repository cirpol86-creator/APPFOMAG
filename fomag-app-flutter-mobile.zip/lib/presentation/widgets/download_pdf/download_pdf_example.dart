import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/widgets/download_pdf/download_pdf.dart';

class DownloadPdfScreen extends StatefulWidget {
  const DownloadPdfScreen({super.key});

  @override
  State<DownloadPdfScreen> createState() => _DownloadPdfScreenState();
}

class _DownloadPdfScreenState extends State<DownloadPdfScreen> {
  final _useCase = DownloadPdfUseCase(); // instancia del caso de uso

  //TODO cambiar la url por la que se quiera descargar
  Future<void> _handleDownload() async {
    const pdfUrl =
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';
    const filename = 'archivo_ejemplo.pdf';

    try {
      final savedPath = await _useCase.execute(url: pdfUrl, filename: filename);
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('PDF guardado en:\n$savedPath')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Descargar PDF')),
      body: Center(
        child: ElevatedButton.icon(
          icon: const Icon(Icons.download),
          label: const Text('Descargar PDF'),
          onPressed: _handleDownload,
        ),
      ),
    );
  }
}
