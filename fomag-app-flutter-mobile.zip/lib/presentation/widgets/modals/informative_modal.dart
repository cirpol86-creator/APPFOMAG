import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class InformativeModal extends StatelessWidget {
  final String title;
  final String? message;
  final String buttonText;
  final VoidCallback onButtonPressed;
  final IconData? topIcon;
  final Color iconColor;
  final Color buttonColor;
  final bool dismissible;

  const InformativeModal({
    super.key,
    required this.title,
    required this.message,
    required this.onButtonPressed,
    required this.buttonText,
    this.topIcon,
    this.iconColor = FomagColors.primaryColor,
    this.buttonColor = FomagColors.primaryColor,
    this.dismissible = false,
  });

  static void show({
    required BuildContext context,
    required String title,
    required VoidCallback onButtonPressed,
    required String buttonText,
    IconData? topIcon,
    String? message,
    Color buttonColor = FomagColors.primaryColor,
    bool dismissible = false,
    Color iconColor = FomagColors.primaryColor,
  }) {
    showDialog(
      context: context,
      barrierDismissible: dismissible,
      builder:
          (_) => InformativeModal(
            title: title,
            message: message,
            onButtonPressed: onButtonPressed,
            buttonText: buttonText,
            topIcon: topIcon,
            iconColor: iconColor,
            buttonColor: buttonColor,
            dismissible: dismissible,
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: dismissible,
      child: Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.85,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 24.0,
              horizontal: 16.0,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (topIcon != null) ...[
                  Icon(topIcon, size: 40, color: iconColor),
                  const SizedBox(height: 12),
                ],
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontFamily: 'NunitoSans',
                  ),
                ),
                if (message != null) ...[
                  const SizedBox(height: 12),
                  Flexible(
                    child: Text(
                      message!,
                      style: const TextStyle(
                        fontFamily: 'NunitoSans',
                        color: Colors.black54,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: onButtonPressed,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: buttonColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 16,
                    ),
                  ),
                  child: Text(
                    buttonText,
                    style: TextStyle(fontFamily: 'NunitoSans'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
