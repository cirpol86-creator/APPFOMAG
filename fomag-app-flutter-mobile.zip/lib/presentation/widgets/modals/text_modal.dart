import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class TextModal extends StatelessWidget {
  final String title;
  final String message;
  final String buttonText;
  final String secondaryButtonText;
  final Color buttonTextColor;
  final Color secondaryButtonTextColor;
  final Color buttonColor;
  final Color secondaryButtonColor;
  final Color iconColor;
  final VoidCallback onButtonPressed;
  final VoidCallback onSecondaryPressed;
  final IconData? buttonIcon;
  final TextEditingController controller;
  final bool showError;

  const TextModal({
    super.key,
    required this.title,
    required this.message,
    required this.onButtonPressed,
    this.buttonIcon,
    required this.onSecondaryPressed,
    required this.secondaryButtonText,
    required this.buttonText,
    required this.controller,
    this.showError = false,
    this.buttonColor = FomagColors.white,
    this.secondaryButtonColor = FomagColors.primaryColor,
    this.buttonTextColor = FomagColors.secondaryColor,
    this.secondaryButtonTextColor = FomagColors.white,
    this.iconColor = FomagColors.secondaryColor,
  });

  static void show({
    required BuildContext context,
    required String title,
    required String message,
    required VoidCallback onButtonPressed,
    required String buttonText,
    required String secondaryButtonText,
    required VoidCallback onSecondaryPressed,
    IconData? buttonIcon,
    bool dismissible = false,
    required TextEditingController controller,
    Color buttonColor = FomagColors.white,
    Color secondaryButtonColor = FomagColors.primaryColor,
    Color buttonTextColor = FomagColors.secondaryColor,
    Color secondaryButtonTextColor = FomagColors.white,
    Color iconColor = FomagColors.secondaryColor,
  }) {
    showDialog(
      context: context,
      barrierDismissible: dismissible,
      builder: (context) {
        final TextEditingController controller0 = controller;
        bool showError = false;
        return StatefulBuilder(
          builder: (context, setState) {
            return TextModal(
              title: title,
              message: message,
              controller: controller0,
              buttonIcon: buttonIcon,
              buttonText: buttonText,
              secondaryButtonText: secondaryButtonText,
              onSecondaryPressed: () {
                if (controller0.text.trim().isEmpty) {
                  setState(() => showError = true);
                } else {
                  onButtonPressed();
                  Navigator.of(context).pop();
                }
              },
              onButtonPressed: onButtonPressed,
              showError: showError,
              buttonColor: buttonColor,
              secondaryButtonColor: secondaryButtonColor,
              buttonTextColor: buttonTextColor,
              secondaryButtonTextColor: secondaryButtonTextColor,
              iconColor: iconColor,
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.all(16),
      child: UnconstrainedBox(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.90,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 24.0,
              horizontal: 16.0,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                        fontFamily: 'NunitoSans',
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close),
                      color: FomagColors.black,
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: Text(
                    message,
                    style: const TextStyle(
                      fontFamily: 'NunitoSans',
                      color: Colors.black54,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: controller,
                  decoration: const InputDecoration(
                    hintText: 'Escribe aquí...',
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: FomagColors.white,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                if (showError)
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text(
                      'Este campo es obligatorio.',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 12,
                        fontFamily: 'NunitoSans',
                      ),
                    ),
                  ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: onButtonPressed,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: buttonColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 16,
                        ),
                      ),
                      child: Row(
                        children: [
                          Text(
                            buttonText,
                            style: TextStyle(
                              fontFamily: 'NunitoSans',
                              color: buttonTextColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(width: 15),
                          Icon(buttonIcon, color: iconColor),
                        ],
                      ),
                    ),
                    ElevatedButton(
                      onPressed: onSecondaryPressed,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: secondaryButtonColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 25,
                          vertical: 16,
                        ),
                      ),
                      child: Text(
                        secondaryButtonText,
                        style: TextStyle(
                          fontFamily: 'NunitoSans',
                          color: secondaryButtonTextColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
