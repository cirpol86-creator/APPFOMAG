import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class ConfirmationModal extends StatelessWidget {
  final String title;
  final String message;
  final String buttonText;
  final String cancelButtonText;
  final VoidCallback onButtonPressed;
  final VoidCallback onCancelPressed;
  final IconData? topIcon;
  final Color iconColor;
  final IconData messageIcon;
  final Color buttonTextColor;
  final Color secondaryButtonTextColor;
  final Color buttonColor;
  final Color secondaryButtonColor;

  const ConfirmationModal({
    super.key,
    this.title = '',
    required this.message,
    required this.onButtonPressed,
    required this.iconColor,
    required this.buttonText,
    this.topIcon,
    required this.cancelButtonText,
    required this.onCancelPressed,
    required this.messageIcon,
    this.buttonColor = FomagColors.white,
    this.secondaryButtonColor = FomagColors.redButton,
    this.buttonTextColor = FomagColors.secondaryColor,
    this.secondaryButtonTextColor = FomagColors.white,
  });

  static void show({
    required BuildContext context,
    String title = '',
    required String message,
    required VoidCallback onButtonPressed,
    required String buttonText,
    IconData? topIcon,
    required String cancelButtonText,
    required VoidCallback onCancelPressed,
    bool dismissible = false,
    required Color iconColor,
    required IconData messageIcon,
    Color buttonColor = FomagColors.white,
    Color secondaryButtonColor = FomagColors.redButton,
    Color buttonTextColor = FomagColors.secondaryColor,
    Color secondaryButtonTextColor = FomagColors.white,
  }) {
    showDialog(
      context: context,
      barrierDismissible: dismissible,
      builder:
          (_) => ConfirmationModal(
            title: title,
            message: message,
            onButtonPressed: onButtonPressed,
            buttonText: buttonText,
            topIcon: topIcon,
            iconColor: iconColor,
            cancelButtonText: cancelButtonText,
            onCancelPressed: onCancelPressed,
            messageIcon: messageIcon,
            buttonColor: buttonColor,
            secondaryButtonColor: secondaryButtonColor,
            buttonTextColor: buttonTextColor,
            secondaryButtonTextColor: secondaryButtonTextColor,
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.90,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'NunitoSans',
                    foreground:
                        Paint()
                          ..style = PaintingStyle.stroke
                          ..strokeWidth = 0.7
                          ..color = FomagColors.black,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(messageIcon, color: Colors.black54),
                  const SizedBox(width: 8),

                  Flexible(
                    child: Text(
                      message,
                      style: const TextStyle(
                        fontSize: 16,
                        color: FomagColors.black,
                        fontWeight: FontWeight.w700,

                        fontFamily: 'NunitoSans',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton(
                    onPressed: onButtonPressed,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: buttonColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 16,
                      ),
                    ),
                    child: Text(
                      buttonText,
                      style: TextStyle(
                        fontFamily: 'NunitoSans',
                        color: buttonTextColor,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: onCancelPressed,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: secondaryButtonColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 16,
                      ),
                    ),
                    child: Text(
                      cancelButtonText,
                      style: TextStyle(
                        fontFamily: 'NunitoSans',
                        color: secondaryButtonTextColor,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
