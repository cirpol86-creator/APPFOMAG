import 'dart:async';
import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:go_router/go_router.dart';

class InactivityHandler extends StatefulWidget {
  final Widget child;
  final Duration timeoutDuration;

  const InactivityHandler({
    required this.child,
    this.timeoutDuration = const Duration(minutes: 2),
    super.key,
  });

  @override
  State<InactivityHandler> createState() => _InactivityHandlerState();
}

class _InactivityHandlerState extends State<InactivityHandler> {
  Timer? _inactivityTimer;
  bool _dialogIsOpen = false;

  void _resetTimer() {
    _inactivityTimer?.cancel();
    _inactivityTimer = Timer(widget.timeoutDuration, _onInactivityDetected);
  }

  Future<void> _onInactivityDetected() async {
    if (_dialogIsOpen || !mounted) return;

    final context = NavigationController.globalNavigatorKey.currentContext;
    if (context == null) return;

    final goRouter = GoRouter.of(context);
    final uri = goRouter.routerDelegate.currentConfiguration.uri;
    final location = uri.toString();
    if (location == Routes.login.routePath ||
        location == Routes.splashScreen.routePath) {
      return;
    }

    _dialogIsOpen = true;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return InformativeModal(
          title: 'Su sesión ha expirado por inactividad.',
          message: 'Por favor, inicie sesión nuevamente.',
          onButtonPressed: () {
            NavigationController.push(
              Routes.splashScreen.routePath,
              clean: true,
            );
          },
          buttonText: 'Iniciar sesión',
        );
      },
    );

    _dialogIsOpen = false;
    _resetTimer();
  }

  @override
  void initState() {
    super.initState();
    _resetTimer();
  }

  @override
  void dispose() {
    _inactivityTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _resetTimer(),
      behavior: HitTestBehavior.translucent,
      child: widget.child,
    );
  }
}
