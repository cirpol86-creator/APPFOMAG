import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class CustomModalDialog extends StatefulWidget {
  final String title;
  final Widget content;
  final Function onConfirm;
  final String confirmText;
  final String cancelText;
  final Color buttonColor;

  const CustomModalDialog({
    super.key,
    required this.title,
    required this.content,
    required this.onConfirm,
    this.confirmText = 'Generar',
    this.cancelText = 'Cancelar',
    this.buttonColor = FomagColors.primaryColor,
  });

  static void show({
    required BuildContext context,
    required String title,
    required Widget content,
    required Function onConfirm,
    String confirmText = 'Generar',
    String cancelText = 'Cancelar',
    Color buttonColor = FomagColors.primaryColor,
  }) {
    showDialog(
      context: context,
      builder: (context) {
        return CustomModalDialog(
          title: title,
          content: content,
          onConfirm: () {
            onConfirm();
            // Navigator.of(context).pop();
          },
        );
      },
    );
  }

  @override
  State<CustomModalDialog> createState() => _CustomModalDialogState();
}

class _CustomModalDialogState extends State<CustomModalDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Título y botón de cerrar
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    widget.title,
                    style: TextStyle(
                      foreground:
                          Paint()
                            ..style = PaintingStyle.stroke
                            ..strokeWidth = 0.7
                            ..color = FomagColors.black,
                      fontSize: 20,
                      fontFamily: 'NunitoSans',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Contenido personalizado
            widget.content,
            const SizedBox(height: 20),

            // Botones
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    widget.cancelText,
                    style: TextStyle(
                      color: FomagColors.black,
                      fontSize: 16,
                      fontFamily: 'NunitoSans',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: FomagColors.buttonPrincipal,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 25,
                      vertical: 16,
                    ),
                  ),
                  onPressed: () => widget.onConfirm(),
                  child: Text(widget.confirmText),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
