import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class LinkTextWidget extends StatelessWidget {
  const LinkTextWidget({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 16,
        color: FomagColors.black,
        fontWeight: FontWeight.w400,
        decoration: TextDecoration.underline,
        decorationThickness: 2,
        decorationColor: FomagColors.black,
        fontFamily: 'NunitoSans',
      ),
    );
  }
}
