import 'package:flutter/material.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class RetryWidget extends StatelessWidget {
  const RetryWidget({
    super.key,
    required this.errorMessage,
    required this.onPressed,
  });

  final String? errorMessage;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgManager.stroke,
            const SizedBox(height: 16),
            Text(
              errorMessage ?? 'Ha ocurrido un error',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: FomagColors.black,
                fontFamily: 'NunitoSans',
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: FomagColors.buttonPrincipal,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 16,
                ),
              ),
              child: const Text(
                'Reintentar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontFamily: 'NunitoSans',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
