import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:intl/intl.dart';

class DatePickerField extends StatefulWidget {
  final String label;
  final TextEditingController controller;
  final void Function(String) onChanged;
  final DateTime? initialDate;
  final DateTime? firstDate;
  final DateTime? lastDate;
  final String format;
  final String? Function(String?)? validator;

  const DatePickerField({
    super.key,
    required this.label,
    required this.controller,
    required this.onChanged,
    this.initialDate,
    this.firstDate,
    this.lastDate,
    this.format = 'yyyy-MM-dd',
    this.validator,
  });

  @override
  State<DatePickerField> createState() => _DatePickerFieldState();
}

class _DatePickerFieldState extends State<DatePickerField> {
  String? _validationError;

  String? _customValidator(String? value) {
    String? result;

    if (widget.validator != null) {
      result = widget.validator!(value);
    } else {
      if (value == null || value.isEmpty) {
        result = 'Este campo es obligatorio';
      } else {
        result = null;
      }
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _validationError = result;
        });
      }
    });

    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
            color:
                _validationError != null
                    ? FomagColors.redButton
                    : FomagColors.black,
            fontFamily: 'Poppins',
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: widget.controller,
          readOnly: true,
          cursorColor: FomagColors.primaryColor,
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
            fillColor: FomagColors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.primaryColor,
                width: 2,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.redButton,
                width: 1,
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.redButton,
                width: 1,
              ),
            ),
            errorStyle: const TextStyle(
              color: FomagColors.redButton,
              fontSize: 12,
              fontWeight: FontWeight.normal,
              height: 1.2,
            ),
            suffixIcon: const Icon(
              Icons.calendar_today_outlined,
              color: FomagColors.black,
            ),
          ),
          onTap: () async {
            final pickedDate = await showDatePicker(
              context: context,
              initialDate: widget.initialDate ?? DateTime.now(),
              firstDate: widget.firstDate ?? DateTime(1990),
              lastDate: widget.lastDate ?? DateTime(2100),
              builder: (BuildContext context, Widget? child) {
                return Theme(
                  data: Theme.of(context).copyWith(
                    colorScheme: const ColorScheme.light(
                      primary: FomagColors.primaryColor,
                      onPrimary: FomagColors.white,
                      onSurface: FomagColors.black,
                    ),
                    textButtonTheme: TextButtonThemeData(
                      style: TextButton.styleFrom(
                        foregroundColor: FomagColors.primaryColor,
                      ),
                    ),
                  ),
                  child: child!,
                );
              },
            );

            if (pickedDate != null) {
              final formatted = DateFormat(widget.format).format(pickedDate);
              widget.controller.text = formatted;
              widget.onChanged(formatted);
            }
          },
          validator: _customValidator,
        ),
      ],
    );
  }
}
