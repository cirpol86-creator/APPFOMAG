import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class DynamicDropdownField extends StatelessWidget {
  final String label;
  final String hintText;
  final List<dynamic> options;
  final dynamic value;
  final void Function(dynamic)? onChanged;
  final String? Function(dynamic)? validator;

  const DynamicDropdownField({
    super.key,
    required this.label,
    required this.hintText,
    required this.options,
    this.value,
    this.onChanged,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        /// Etiqueta superior
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: FomagColors.black,
            fontFamily: 'NunitoSans',
          ),
        ),
        const SizedBox(height: 8),

        /// Dropdown estilizado
        DropdownButtonFormField<dynamic>(
          value: value,
          hint: Text(hintText),
          isExpanded: true,
          icon: const Icon(Icons.expand_more_rounded, color: FomagColors.black),
          decoration: InputDecoration(
            fillColor: FomagColors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 8,
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(
                color: FomagColors.primaryColor,
                width: 2,
              ),
            ),
          ),
          items:
              options.map((option) {
                return DropdownMenuItem<dynamic>(
                  value: option['id'],
                  child: Text(option['label'].toString()),
                );
              }).toList(),
          onChanged: onChanged,
          validator: validator,
        ),
      ],
    );
  }
}
