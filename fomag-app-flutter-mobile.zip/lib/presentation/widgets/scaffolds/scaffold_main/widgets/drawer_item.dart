import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class DrawerItem extends StatelessWidget {
  final Widget icon;
  final String text;
  final Function() onTap;

  const DrawerItem({
    super.key,
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: FomagColors.buttonOutline, width: 1),
        ),
      ),
      child: ListTile(
        leading: icon,
        minLeadingWidth: 0,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 10,
        ),
        title: Text(
          text,
          style: TextStyle(
            color: FomagColors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'NunitoSans',
          ),
        ),
        onTap: onTap,
      ),
    );
  }
}

class DrawerItemData {
  final Widget icon;
  final String text;
  final Function() onTap;
  DrawerItemData({required this.icon, required this.text, required this.onTap});

  static List<DrawerItemData> get drawerItems => [
    DrawerItemData(
      icon: SvgManager.house,
      text: 'Inicio',
      onTap: () {
        NavigationController.drawerItemTap(Routes.home.routePath);
      },
    ),
    DrawerItemData(
      icon: SvgManager.news,
      text: 'Noticias',
      onTap: () {
        NavigationController.drawerItemTap(Routes.listNews.routePath);
      },
    ),
    // DrawerItemData(
    //   icon: SvgManager.headset,
    //   text: 'Encuestas',
    //   onTap: () {
    //     NavigationController.drawerItemTap(Routes.survey.routePath);
    //   },
    // ),
    DrawerItemData(
      icon: SvgManager.ask,
      text: 'Radicar / Consultar PQRS',
      onTap: () {
        NavigationController.drawerItemTap(Routes.pqr.routePath);
      },
    ),
    DrawerItemData(
      icon: SvgManager.hospital,
      text: 'Centros Administrativos de Salud',
      onTap: () {
        NavigationController.drawerItemTap(Routes.healthcenter.routePath);
      },
    ),
    DrawerItemData(
      icon: SvgManager.certificate,
      text: 'Certificados',
      onTap: () {
        NavigationController.drawerItemTap(Routes.certificates.routePath);
      },
    ),
    DrawerItemData(
      icon: SvgManager.checkCloud,
      text: 'Entidades Aliadas',
      onTap: () {
        NavigationController.drawerItemTap(Routes.alliedEntities.routePath);
      },
    ),
    DrawerItemData(
      icon: SvgManager.phone,
      text: 'Contáctenos',
      onTap: () {
        NavigationController.drawerItemTap(Routes.contact.routePath);
      },
    ),
  ];
}
