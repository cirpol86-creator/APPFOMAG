import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/widgets/drawer_item.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.of(context).size.width,
      child: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.only(top: 50.0),
              color: Colors.white,
              child: ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: DrawerItemData.drawerItems.length,
                itemBuilder: (context, index) {
                  final item = DrawerItemData.drawerItems[index];
                  return DrawerItem(
                    icon: item.icon,
                    text: item.text,
                    onTap: item.onTap,
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
