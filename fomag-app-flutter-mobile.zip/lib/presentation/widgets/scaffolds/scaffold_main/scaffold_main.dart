import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/retry_widget.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/widgets/custom_drawer.dart';

class ScaffoldMain extends StatelessWidget {
  const ScaffoldMain({
    super.key,
    required this.body,
    this.errorMessage,
    this.onRetry,
    this.isLoading = false,
  });

  final Widget body;
  final String? errorMessage;
  final VoidCallback? onRetry;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: FomagColors.white,
              title: Image.asset('assets/images/fomag_logo.png', width: 116),
              actionsPadding: EdgeInsets.only(right: 24),
              centerTitle: true,
              elevation: 0,
              leading: Builder(
                builder: (context) {
                  return IconButton(
                    icon: SvgManager.menu,
                    onPressed: () {
                      Scaffold.of(context).openDrawer();
                    },
                  );
                },
              ),
              actions: [
                PopupMenuButton<int>(
                  icon: SvgManager.user,

                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16),
                      bottomLeft: Radius.circular(16),
                      bottomRight: Radius.circular(16),
                    ),
                  ),
                  offset: Offset(-40, 50),
                  elevation: 4,
                  itemBuilder:
                      (context) => [
                        PopupMenuItem(
                          value: 1,
                          child: Row(
                            children: [
                              SvgManager.user,
                              SizedBox(width: 8),
                              Text('Mi cuenta'),
                            ],
                          ),
                          onTap: () {
                            NavigationController.push(
                              Routes.accountPage.routePath,
                            );
                          },
                        ),
                      ],
                  onSelected: (value) {
                    if (value == 1) {
                      // Acción para cambiar contraseña
                    } else if (value == 2) {
                      // Acción para cerrar sesión
                    }
                  },
                ),
              ],
            ),
            body:
                errorMessage != null && onRetry != null
                    ? Center(
                      child: RetryWidget(
                        errorMessage: errorMessage,
                        onPressed: onRetry,
                      ),
                    )
                    : SingleChildScrollView(child: body),
            drawer: CustomDrawer(),
          ),
        ),
        if (isLoading)
          Container(
            color: Colors.black.withAlpha((0.5 * 255).toInt()),
            child: const Center(child: CircularProgressIndicator()),
          ),
      ],
    );
  }
}
