import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class ScaffoldSimple extends StatelessWidget {
  const ScaffoldSimple({super.key, required this.body, this.isLoading = false});

  final Widget body;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            backgroundColor: FomagColors.white,
            body: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 40,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 32),

                    // Botón Atrás con feedback visual (InkWell + Material)
                    Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: NavigationController.pop,
                        borderRadius: BorderRadius.circular(32),
                        splashColor: FomagColors.darkBlue.withOpacity(0.2),
                        highlightColor: FomagColors.darkBlue.withOpacity(0.1),
                        child: Padding(
                          padding: const EdgeInsets.all(
                            8.0,
                          ), // Área táctil ampliada
                          child: SizedBox(
                            width: 24,
                            height: 24,
                            child: SvgManager.arrowLeft,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 32),
                    body,
                  ],
                ),
              ),
            ),
          ),
        ),

        // Capa de carga si isLoading = true
        if (isLoading)
          Container(
            color: Colors.black.withAlpha((0.5 * 255).toInt()),
            child: const Center(child: CircularProgressIndicator()),
          ),
      ],
    );
  }
}
