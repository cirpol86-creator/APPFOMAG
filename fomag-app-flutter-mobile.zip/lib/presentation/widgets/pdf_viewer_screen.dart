import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class PdfViewerScreen extends StatefulWidget {
  final String filePath;

  const PdfViewerScreen({super.key, required this.filePath});

  @override
  State<PdfViewerScreen> createState() => _PdfViewerState();
}

class _PdfViewerState extends State<PdfViewerScreen> {
  final PdfViewerController _pdfViewerController = PdfViewerController();
  Uint8List? _pdfBytes;

  @override
  void initState() {
    super.initState();
    _openFile();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(onPressed: _saveFile, icon: const Icon(Icons.save)),
          Spacer(),
        ],
      ),
      body:
          _pdfBytes != null
              ? SfPdfViewer.memory(_pdfBytes!, controller: _pdfViewerController)
              : const Center(child: Text('Choose a PDF file to open')),
    );
  }

  /// Open a PDF file from the local device's storage.
  Future<void> _openFile() async {
    // FilePickerResult? filePickerResult = await FilePicker.platform.pickFiles(
    //   type: FileType.custom,
    //   allowedExtensions: ['pdf'],
    // );

    // if (filePickerResult != null) {
    //   if (kIsWeb) {
    //     _pdfBytes = filePickerResult.files.single.bytes;
    //   } else {
    //     _pdfBytes =
    //         await File(filePickerResult.files.single.path!).readAsBytes();
    //   }
    // }

    _pdfBytes = await File(widget.filePath).readAsBytes();
    setState(() {});
  }

  /// Save a PDF file to the desired local device's storage location.
  Future<void> _saveFile() async {
    if (_pdfViewerController.pageCount > 0) {
      List<int> bytes = await _pdfViewerController.saveDocument();
      SaveHelper.save(bytes, 'Saved.pdf');
    }
  }
}

class SaveHelper {
  static Future<void> save(List<int> bytes, String fileName) async {
    String? saveLocation = await FilePicker.platform.saveFile(
      bytes: Uint8List.fromList(bytes),
      fileName: fileName,
      allowedExtensions: <String>['pdf'],
    );

    if (Platform.isWindows || Platform.isMacOS) {
      if (saveLocation != null) {
        final File file = File(saveLocation);
        if (file.existsSync()) {
          await file.delete();
        }
        await file.writeAsBytes(bytes);
      }
    }
  }
}
