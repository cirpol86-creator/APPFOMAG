import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/data/model/image_carousel_model.dart';
import 'package:skeletonizer/skeletonizer.dart';

class ImageCarouselCard extends StatefulWidget {
  final List<CarouselCardData> items;

  const ImageCarouselCard({super.key, required this.items});

  @override
  State<ImageCarouselCard> createState() => _ImageCarouselCardState();
}

class _ImageCarouselCardState extends State<ImageCarouselCard> {
  int _currentPage = 0;
  final PageController _controller = PageController(viewportFraction: 0.88);

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Skeleton.leaf(
      child: Skeleton.replace(
        replacement: Container(
          height: screenHeight * 0.55,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: Column(
          children: [
            SizedBox(
              height: screenHeight * 0.52, // MÁS ALTURA para evitar cortes
              child: PageView.builder(
                controller: _controller,
                itemCount: widget.items.length,
                onPageChanged: (index) {
                  setState(() {
                    _currentPage = index;
                  });
                },
                itemBuilder: (context, index) {
                  final item = widget.items[index];
                  final isActive = _currentPage == index;

                  return GestureDetector(
                    onTap: () {
                      NavigationController.push(
                        Routes.newInfo.routePath,
                        arguments: item.id,
                      );
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      margin: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 12,
                      ),
                      transform:
                          isActive ? Matrix4.identity() : Matrix4.identity()
                            ..scale(0.95),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(
                              isActive ? 0.15 : 0.05,
                            ),
                            blurRadius: 12,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(20),
                            ),
                            child: SizedBox(
                              height: 250,
                              width: double.infinity,
                              child: ClipRRect(
                                borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(20),
                                ),
                                child: Image.network(
                                  item.imageUrl,
                                  fit: BoxFit.fill,
                                  width: double.infinity,
                                  errorBuilder:
                                      (context, error, stackTrace) =>
                                          Container(color: Colors.grey[300]),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.title,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Poppins',
                                  ),
                                  maxLines: 4, // ✅ HASTA 3 LÍNEAS
                                  overflow: TextOverflow.ellipsis,
                                ),
                                // if (item.subtitle != null)
                                //   Padding(
                                //     padding: const EdgeInsets.only(top: 6),
                                //     child: Text(
                                //       item.subtitle!,
                                //       style: const TextStyle(
                                //         fontSize: 14,
                                //         color: Colors.grey,
                                //       ),
                                //       maxLines: 2,
                                //       overflow: TextOverflow.ellipsis,
                                //     ),
                                //   ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 12),

            // Indicadores refinados
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(widget.items.length, (index) {
                final isActive = _currentPage == index;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: isActive ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: isActive ? Colors.blue : Colors.grey[300],
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
