import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:skeletonizer/skeletonizer.dart';

class CardEntity extends StatelessWidget {
  final String? imageUrl;
  final String title;
  final String address;
  final String? phone;
  final String? phone2;
  final VoidCallback onTap;

  const CardEntity({
    super.key,
    required this.title,
    required this.address,
    required this.onTap,
    this.imageUrl,
    this.phone,
    this.phone2,
  });

  @override
  Widget build(BuildContext context) {
    final double withImage = 100;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: FomagColors.buttonOutline, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha((0.03 * 255).toInt()),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Skeleton.leaf(
                  child: Container(
                    width: withImage,
                    constraints: const BoxConstraints(minHeight: 100),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        imageUrl ?? '',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Center(
                            child: Icon(
                              Icons.health_and_safety,
                              size: 48,
                              color: FomagColors.buttonPrincipal,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Skeleton.replace(
                            replacement: Bone.text(
                              style: TextStyle(fontSize: 16),
                            ),
                            child: Text(
                              title,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: FomagColors.black,
                                overflow: TextOverflow.ellipsis,
                                fontFamily: 'NunitoSans',
                              ),
                              maxLines: 10,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Skeleton.replace(
                            replacement: Bone.text(
                              style: TextStyle(fontSize: 16),
                            ),
                            child: Text(
                              'Salud',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                color: FomagColors.black,
                                overflow: TextOverflow.ellipsis,
                                fontFamily: 'NunitoSans',
                              ),
                              maxLines: 1,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Skeleton.replace(
                            replacement: Bone.text(
                              style: TextStyle(fontSize: 12),
                            ),
                            child: Text(
                              address,
                              style: const TextStyle(
                                fontSize: 14,
                                color: FomagColors.black,
                                fontWeight: FontWeight.w700,
                                overflow: TextOverflow.ellipsis,
                                fontFamily: 'NunitoSans',
                              ),
                              maxLines: 5,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Skeleton.replace(
                            replacement: Bone.text(
                              style: TextStyle(fontSize: 12),
                            ),
                            child: Text(
                              phone ?? '',
                              style: const TextStyle(
                                fontSize: 14,
                                color: FomagColors.black,
                                fontWeight: FontWeight.w700,
                                overflow: TextOverflow.ellipsis,
                                fontFamily: 'NunitoSans',
                              ),
                              maxLines: 10,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Skeleton.replace(
                            replacement: Bone.text(
                              style: TextStyle(fontSize: 12),
                            ),
                            child: Text(
                              phone2 ?? '',
                              style: const TextStyle(
                                fontSize: 14,
                                color: FomagColors.black,
                                fontWeight: FontWeight.w700,
                                overflow: TextOverflow.ellipsis,
                                fontFamily: 'NunitoSans',
                              ),
                              maxLines: 10,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
