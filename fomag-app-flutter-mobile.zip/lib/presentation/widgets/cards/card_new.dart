import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:skeletonizer/skeletonizer.dart';

class CardNew extends StatefulWidget {
  final String imageUrl;
  final String category;
  final String title;
  final String date;
  final VoidCallback onTap;

  const CardNew({
    super.key,
    required this.imageUrl,
    required this.category,
    required this.title,
    required this.date,
    required this.onTap,
  });

  @override
  State<CardNew> createState() => _CardNewState();
}

class _CardNewState extends State<CardNew> {
  double _scale = 1.0;

  void _onTapDown(_) {
    setState(() => _scale = 0.97);
  }

  void _onTapUp(_) {
    setState(() => _scale = 1.0);
  }

  void _onTapCancel() {
    setState(() => _scale = 1.0);
  }

  @override
  Widget build(BuildContext context) {
    const double imageHeight = 160;

    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 100),
        scale: _scale,
        curve: Curves.easeOut,
        child: Container(
          margin: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.10), // Color sutil de sombra
                blurRadius: 16, // Difuminado
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Imagen superior
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(20),
                ),
                child: Skeleton.replace(
                  replacement: Skeleton.leaf(
                    child: Container(
                      height: imageHeight,
                      width: double.infinity,
                      color: Colors.grey.shade100,
                    ),
                  ),
                  child: Image.network(
                    widget.imageUrl,
                    height: imageHeight,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder:
                        (context, error, stackTrace) => Container(
                          height: imageHeight,
                          color: Colors.grey.shade300,
                          child: const Icon(
                            Icons.image_not_supported_outlined,
                            color: Colors.grey,
                            size: 48,
                          ),
                        ),
                  ),
                ),
              ),

              // Contenido textual
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Título
                    Skeleton.replace(
                      replacement: const Bone.multiText(
                        style: TextStyle(fontSize: 16),
                      ),
                      child: Text(
                        widget.title,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: FomagColors.black,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Fecha
                    Skeleton.replace(
                      replacement: const Bone.text(
                        style: TextStyle(fontSize: 12),
                      ),
                      child: Text(
                        widget.date,
                        style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
