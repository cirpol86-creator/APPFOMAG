import 'dart:async';
import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/buttons/secondary_button.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class ProgressLoaderScreenParams {
  final String message;
  final VoidCallback? onFinish;
  final Duration duration;
  final Color color;
  final double startPercent;
  final bool isError;
  final bool forceEnableButton;
  final Widget? messageLink;

  const ProgressLoaderScreenParams({
    this.message = '',
    this.onFinish,
    this.duration = const Duration(seconds: 5),
    this.color = Colors.lightBlue,
    this.startPercent = 0.0,
    this.isError = false,
    this.forceEnableButton = false,
    this.messageLink,
  });
}

class ProgressLoaderScreen extends StatefulWidget {
  final ProgressLoaderScreenParams params;

  ProgressLoaderScreen({
    super.key,
    String message ='',
    VoidCallback? onFinish,
    Duration duration = const Duration(seconds: 5),
    Color color = Colors.lightBlue,
    double startPercent = 0.0,
    bool isError = false,
    bool forceEnableButton = false,
    Widget? messageLink,
  }) : params = ProgressLoaderScreenParams(
         message: message,
         onFinish: onFinish,
         duration: duration,
         color: color,
         startPercent: startPercent,
         isError: isError,
         forceEnableButton: forceEnableButton,
          messageLink: messageLink,
       );

  @override
  State<ProgressLoaderScreen> createState() => _ProgressLoaderScreenState();
}

class _ProgressLoaderScreenState extends State<ProgressLoaderScreen> {
  double percent = 0.0;
  late Timer _timer;
  bool _isEnableButton = false;

  @override
  void initState() {
    super.initState();
    percent = widget.params.startPercent;
    final interval = widget.params.duration.inMilliseconds ~/ 100;
    _isEnableButton = widget.params.forceEnableButton;

    _timer = Timer.periodic(Duration(milliseconds: interval), (timer) {
      setState(() {
        percent += 0.01;
        if (percent >= 1.0) {
          percent = 1.0;
          _timer.cancel();
          // _isEnableButton = true;
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isError = widget.params.isError;
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
          onPressed: () {
            // Navigator.pop(context);
            NavigationController.push(Routes.splashScreen.routePath);
          },
          color: FomagColors.black,
        ),
        elevation: 0,
        backgroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularPercentIndicator(
                  radius: 60.0,
                  lineWidth: 8.0,
                  percent: percent,
                  center:
                      isError
                          ? Text(
                            "Error",
                            style: TextStyle(
                              fontFamily: 'NunitoSans',
                              color: FomagColors.black,
                            ),
                          )
                          : Text(
                            "${(percent * 100).toInt()}%",
                            style: TextStyle(
                              fontFamily: 'NunitoSans',
                              color: FomagColors.black,
                            ),
                          ),
                  progressColor: widget.params.color,
                  backgroundColor: Colors.grey.shade300,
                  circularStrokeCap: CircularStrokeCap.round,
                ),
                const SizedBox(height: 24),
                if(widget.params.messageLink != null)...[
                    widget.params.messageLink!,
                ]else...[
                  Text(
                    widget.params.message,
                    style: const TextStyle(
                      fontSize: 16,
                      fontFamily: 'NunitoSans',
                      color: FomagColors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ]
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child:
              isError
                  ? SecondaryButton(
                    enabled: _isEnableButton,
                    text: 'Reintentar',
                    onPressed: widget.params.onFinish!,
                  )
                  : PrimaryButton(
                    enabled: _isEnableButton,
                    text: 'Continuar',
                    onPressed: widget.params.onFinish!,
                  ),
        ),
      ),
    );
  }
}
