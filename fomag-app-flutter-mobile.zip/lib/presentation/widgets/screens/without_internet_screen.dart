import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/services/conection_service.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class WithoutInternetScreen {
  static OverlayEntry? _overlayEntry;

  static Future<void> show() async {
    final NavigatorState currentState =
        NavigationController.globalNavigatorKey.currentState!;
    final BuildContext context = currentState.context;

    final isConnected = context.read<ConnectionService>().isConnected;

    if (isConnected) {
      hide();
    } else {
      final OverlayState overlay = currentState.overlay!;

      _overlayEntry = OverlayEntry(
        builder:
            (context) => Material(
              color: FomagColors.white,
              child: Stack(
                children: [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(height: 20),
                          SvgManager.withoutInternet,
                          SizedBox(height: 20),
                          Text(
                            "Sin conexión a internet",
                            style: TextStyle(
                              color: FomagColors.neutralTitleText,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
      );

      overlay.insert(_overlayEntry!);
    }
  }

  static void hide() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }
}
