import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class CopyrightWidget extends StatelessWidget {
  final int? year;
  const CopyrightWidget({super.key, this.year});

  @override
  Widget build(BuildContext context) {
    final int displayYear = year ?? DateTime.now().year;
    return Center(
      child: Text(
        '©$displayYear',
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: FomagColors.neutralText,
          fontFamily: 'NunitoSans',
        ),
      ),
    );
  }
}
