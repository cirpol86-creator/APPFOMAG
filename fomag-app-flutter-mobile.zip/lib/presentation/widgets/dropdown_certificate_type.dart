import 'package:flutter/material.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class DropdownCertificateType extends StatefulWidget {
  final String label;
  final String hintText;
  final List<CertificateType> options;
  final void Function(CertificateType?)? onChanged;
  final String? Function(String?)? validator;
  final CertificateType? value;

  const DropdownCertificateType({
    super.key,
    required this.label,
    required this.hintText,
    required this.options,
    this.onChanged,
    this.validator,
    this.value,
  });

  @override
  State<DropdownCertificateType> createState() =>
      _DropdownCertificateTypeState();
}

class _DropdownCertificateTypeState extends State<DropdownCertificateType> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return FormField<String>(
      initialValue: widget.value?.name,
      validator: widget.validator,
      builder: (FormFieldState<String> state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.label,
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
                color: FomagColors.black,
                fontFamily: 'Poppins',
              ),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<CertificateType>(
              value: widget.value,
              hint: const Text(
                'Tipo de certificado',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  color: FomagColors.black,
                  fontFamily: 'Poppins',
                ),
              ),
              isExpanded: true,
              icon: Icon(Icons.expand_more_rounded, color: FomagColors.black),
              decoration: InputDecoration(
                hintText: widget.hintText,
                fillColor: FomagColors.white,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(
                    color: FomagColors.primaryColor,
                    width: 2,
                  ),
                ),
              ),
              items:
                  widget.options.map((cert) {
                    return DropdownMenuItem(
                      value: cert,
                      child: Text(
                        cert.name,
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          color: FomagColors.black,
                        ),
                      ),
                    );
                  }).toList(),
              onChanged: (value) {
                if (value != null) {
                  widget.onChanged!(value);
                }
              },
              validator: (value) {
                if (value == null) {
                  return 'Selecciona un tipo de certificado';
                }
                return null;
              },
            ),
          ],
        );
      },
    );
  }
}
