import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class ScaffoldSimple extends StatelessWidget {
  const ScaffoldSimple({super.key, required this.body});

  final Widget body;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: FomagColors.white,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                  onTap: NavigationController.pop,
                  child: SvgManager.arrowLeft,
                ),
                const SizedBox(height: 32),
                SizedBox(
                  height: MediaQuery.of(context).size.height - 136,
                  child: body,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
