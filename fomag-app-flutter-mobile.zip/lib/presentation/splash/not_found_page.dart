import 'package:flutter/material.dart';

class NotFoundPage extends StatelessWidget {
  const NotFoundPage({super.key});

  static Key get defaultKey => const Key('not_found_page');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: key ?? defaultKey,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Página en construcción'),
              SizedBox(height: 10),
              Text(
                'Esta página no está disponible en este momento',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
