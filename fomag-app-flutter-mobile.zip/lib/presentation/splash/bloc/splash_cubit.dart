import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/utils/validate_version_manager.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';

class SplashCubit extends Cubit<String> {
  final TrackUserEventUseCase _trackUserEvent;

  SplashCubit({required TrackUserEventUseCase trackUserEvent})
    : _trackUserEvent = trackUserEvent,
      super('');

  Future<void> loadVersion() async {
    final version = await ValidateVersionManager.getVersion();

    emit(version);

    // Tracking del evento al cargar la pantalla
    await _trackUserEvent(
      UserEventModel(UserEventType.appOpened, {'screen_name': 'SplashPage'}),
    );
  }
}
