import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/splash/bloc/splash_cubit.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_bloc.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_event.dart';
import 'package:fomagapp/presentation/terms_conditions/pages/terms_conditions_page.dart';
import 'package:fomagapp/presentation/widgets/buttons/bordered_button.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SplashCubit>().loadVersion();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 0.75],
            colors: [FomagColors.blue450, FomagColors.magenta650],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: size.height * 0.6, child: SvgManager.logo),
              Text(
                'Bienvenido',
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'NunitoSans',
                  foreground:
                      Paint()
                        ..style = PaintingStyle.stroke
                        ..strokeWidth = 0.7
                        ..color = FomagColors.white,
                ),
              ),
              PrimaryButton(
                text: 'Iniciar Sesión',
                onPressed: () {
                  NavigationController.push(Routes.login.routePath);
                },
              ),
              const SizedBox(height: 24),
              BorderedButton(
                text: 'Crear una cuenta',
                onPressed: () {
                  NavigationController.push(Routes.register.routePath);
                },
              ),
              const SizedBox(height: 24),
              BlocBuilder<SplashCubit, String>(
                builder: (context, version) {
                  return Text(
                    'v $version -  ${AppConfig.shared.enviromentName}',
                    style: const TextStyle(
                      color: FomagColors.white,
                      fontSize: 16,
                      fontFamily: 'NunitoSans',
                    ),
                  );
                },
              ),
              TextButton(
                onPressed: () {
                  context.read<TermsConditionsBloc>().add(
                    TermsConditionsSubmitted(),
                  );
                  TermsConditionsModal.show(context: context);
                },
                child: Text(
                  'Términos y Condiciones',
                  style: const TextStyle(
                    decoration: TextDecoration.underline,
                    color: FomagColors.white,
                    fontSize: 16,
                    fontFamily: 'NunitoSans',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
