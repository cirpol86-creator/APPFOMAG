import 'package:flutter/material.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/link_text.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';

class SuspendedAccountPage extends StatefulWidget {
  const SuspendedAccountPage({super.key});

  @override
  State<SuspendedAccountPage> createState() => _SuspendedAccountPageState();
}

class _SuspendedAccountPageState extends State<SuspendedAccountPage> {
  @override
  Widget build(BuildContext context) {
    return ScaffoldSimple(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SvgManager.stroke,
          const SizedBox(height: 16),
          Text(
            'Cuenta suspendida',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: FomagColors.neutralRojo,
              fontFamily: 'NunitoSans',
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Su usuario se encuentra suspendido o bloqueado por favor comuníquese con soporte',
            style: TextStyle(
              fontSize: 16,
              color: FomagColors.black,
              fontWeight: FontWeight.w400,
              fontFamily: 'NunitoSans',
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          LinkTextWidget(text: 'soporte@correo.com'),
        ],
      ),
    );
  }
}
