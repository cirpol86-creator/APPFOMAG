part of 'health_center_bloc.dart';

abstract class HealthCenterState {}

class HealthCenterLoading extends HealthCenterState {}

class HealthCenterLoaded extends HealthCenterState {
  final List<HealthCenterResponse> healthCenters;

  HealthCenterLoaded({required this.healthCenters});
}

class HealthCenterError extends HealthCenterState {
  final String message;

  HealthCenterError({required this.message});
}

class DepartmentsLoading extends HealthCenterState {}

class DepartmentsLoaded extends HealthCenterState {
  final List<DepartmentsHealthCenterResponse> departments;

  DepartmentsLoaded({required this.departments});
}

class DepartmentsError extends HealthCenterState {
  final String message;

  DepartmentsError({required this.message});
}

class CitiesLoading extends HealthCenterState {}

class CitiesLoaded extends HealthCenterState {
  final List<CitiesResponse> cities;

  CitiesLoaded({required this.cities});
}

class CitiesError extends HealthCenterState {
  final String message;

  CitiesError({required this.message});
}
