import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/presentation/health/usecase/get_cities_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_departments_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_health_center_usecase.dart';

part 'health_center_event.dart';
part 'health_center_state.dart';

class HealthCenterBloc extends Bloc<HealthCenterEvent, HealthCenterState> {
  final GetHealthCenterUsecase _getHealthCenterUsecase;
  final GetDepartmentsUsecase _getDepartmentsUsecase;
  final GetCitiesUsecase _getCitiesUsecase;

  HealthCenterBloc({
    required GetHealthCenterUsecase getHealthCenterUsecase,
    required GetDepartmentsUsecase getDepartmentsUsecase,
    required GetCitiesUsecase getCitiesUsecase,
  }) : _getHealthCenterUsecase = getHealthCenterUsecase,
       _getDepartmentsUsecase = getDepartmentsUsecase,
       _getCitiesUsecase = getCitiesUsecase,
       super(HealthCenterLoading()) {
    on<HealthCenterLoad>(_onLoadLocations);
    on<DepartmentLoad>(_onLoadDepartments);
    on<CityLoad>(_onLoadCities);
  }

  Future<void> _onLoadDepartments(
    DepartmentLoad event,
    Emitter<HealthCenterState> emit,
  ) async {
    emit(DepartmentsLoading());

    final result = await _getDepartmentsUsecase();

    result.fold(
      (failure) {
        emit(DepartmentsError(message: mapFailureToMessage(failure)));
      },
      (departments) {
        emit(DepartmentsLoaded(departments: departments));
      },
    );
  }

  Future<void> _onLoadCities(
    CityLoad event,
    Emitter<HealthCenterState> emit,
  ) async {
    emit(CitiesLoading());

    final result = await _getCitiesUsecase(event.departmentId);

    result.fold(
      (failure) {
        emit(CitiesError(message: mapFailureToMessage(failure)));
      },
      (cities) {
        emit(CitiesLoaded(cities: cities));
      },
    );
  }

  Future<void> _onLoadLocations(
    HealthCenterLoad event,
    Emitter<HealthCenterState> emit,
  ) async {
    emit(HealthCenterLoading());

    final result = await _getHealthCenterUsecase.getHealthCenters(event.cityId);

    result.fold(
      (failure) {
        emit(HealthCenterError(message: mapFailureToMessage(failure)));
      },
      (locations) {
        emit(HealthCenterLoaded(healthCenters: locations));
      },
    );
  }
}

String mapFailureToMessage(Failure failure) {
  if (failure is ServerFailure) {
    return failure.message;
  } else if (failure is NoConnectionFailure) {
    return failure.message;
  } else {
    return failure.message;
  }
}
