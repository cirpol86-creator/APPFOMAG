part of 'health_center_bloc.dart';

abstract class HealthCenterEvent {}

class DepartmentLoad extends HealthCenterEvent {}

class CityLoad extends HealthCenterEvent {
  final int departmentId;

  CityLoad(this.departmentId);
}

class HealthCenterLoad extends HealthCenterEvent {
  final int cityId;

  HealthCenterLoad(this.cityId);
}
