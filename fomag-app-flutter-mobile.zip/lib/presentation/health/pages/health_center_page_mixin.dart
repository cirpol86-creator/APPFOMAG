part of 'health_center_page.dart';

mixin HealthCenterPageMixin<T extends StatefulWidget> on State<T> {
  final formKey = GlobalKey<FormState>();

  bool? isLoading;
  bool? isLoadingDepartments;
  bool? isLoadingCities;
  int? departmentController;
  CitiesResponse? cityController;
  String? errorMessage;

  List<HealthCenterResponse>? healthCenters;
  List<DepartmentsHealthCenterResponse>? departments;
  List<CitiesResponse>? cities;

  void departmentsSuccess(DepartmentsLoaded state) {
    setIsLoadingDepartments(false);
    setDepartments(state.departments);
  }

  void onDepartmentsError(DepartmentsError state) {
    setIsLoadingDepartments(false);
    setErrorMessage(state.message);
  }

  void citiesSuccess(CitiesLoaded state) {
    if (state.cities.isEmpty) {
      setErrorMessage('No se encontraron ciudades');
    }
    setIsLoadingCities(false);
    setCities(state.cities);
  }

  void onCitiesError(CitiesError state) {
    setIsLoadingCities(false);
    setErrorMessage(state.message);
  }

  void setDepartments(List<DepartmentsHealthCenterResponse> departments) {
    setState(() {
      this.departments = departments;
    });
  }

  void setCities(List<CitiesResponse> cities) {
    setState(() {
      this.cities = cities;
    });
  }

  void setLocations(List<HealthCenterResponse> healthCenters) {
    setState(() {
      this.healthCenters = healthCenters;
    });
  }

  void setErrorMessage(String? message) {
    setState(() {
      errorMessage = message;
    });
  }

  void onHealthCenterLoaded(HealthCenterLoaded state) {
    setIsLoading(false);
    setLocations(state.healthCenters);
  }

  void onHealthCenterError(HealthCenterError state) {
    setIsLoading(false);
    setErrorMessage(state.message);
  }

  void setDepartmentController(int? value) {
    setErrorMessage(null);
    setCityController(null);
    setLocations([]);
    setState(() {
      departmentController = value;
    });

    context.read<HealthCenterBloc>().add(CityLoad(value ?? 0));
  }

  void setCityController(CitiesResponse? value) {
    setErrorMessage(null);
    setLocations([]);
    setState(() {
      cityController = value;
    });
  }

  void setIsLoading(bool value) {
    setState(() {
      isLoading = value;
    });
  }

  void setIsLoadingDepartments(bool value) {
    setState(() {
      isLoadingDepartments = value;
    });
  }

  void setIsLoadingCities(bool value) {
    setState(() {
      isLoadingCities = value;
    });
  }

  void onSearch() {
    if (formKey.currentState!.validate()) {
      context.read<HealthCenterBloc>().add(
        HealthCenterLoad(cityController!.id),
      );
    }
  }

  String? validateDepartment(int? value) {
    if (departmentController == null) {
      return 'El departamento es requerido';
    }
    return null;
  }

  String? validateCity(CitiesResponse? value) {
    if (cityController == null) {
      return 'La ciudad es requerida';
    }
    return null;
  }

  @override
  void dispose() {
    formKey.currentState?.reset();
    super.dispose();
  }
}
