import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/presentation/health/bloc/health_center_bloc.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/cards/card_entity.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_picker.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';
import 'package:skeletonizer/skeletonizer.dart';

part 'health_center_page_mixin.dart';

class HealthCenterPage extends StatefulWidget {
  const HealthCenterPage({super.key});

  @override
  HealthCenterPageState createState() => HealthCenterPageState();
}

class HealthCenterPageState extends State<HealthCenterPage>
    with HealthCenterPageMixin {
  @override
  void initState() {
    super.initState();

    context.read<HealthCenterBloc>().add(DepartmentLoad());
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<HealthCenterBloc, HealthCenterState>(
      listener: (context, state) {
        if (state is HealthCenterLoading) {
          setIsLoading(true);
        }

        if (state is DepartmentsLoading) {
          setIsLoadingDepartments(true);
        }

        if (state is CitiesLoading) {
          setIsLoadingCities(true);
        }

        if (state is DepartmentsLoaded) {
          departmentsSuccess(state);
        }

        if (state is DepartmentsError) {
          onDepartmentsError(state);
        }

        if (state is CitiesLoaded) {
          citiesSuccess(state);
        }

        if (state is CitiesError) {
          onCitiesError(state);
        }

        if (state is HealthCenterLoaded) {
          onHealthCenterLoaded(state);
        }

        if (state is HealthCenterError) {
          onHealthCenterError(state);
        }
      },
      child: ScaffoldMain(
        isLoading: isLoadingDepartments == true || isLoadingCities == true,
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                Text(
                  'Centros Administrativos de Salud',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: FomagColors.neutralBlueText,
                  ),
                ),
                SizedBox(height: 24),
                RoundedPicker<int>(
                  label: 'Seleccione el Departamento',
                  hintText: 'Seleccione el Departamento',
                  buildItems:
                      departments
                          ?.map(
                            (department) => DropdownMenuItem<int>(
                              value: department.id,
                              child: Text(department.name),
                            ),
                          )
                          .toList() ??
                      [],
                  onChanged: setDepartmentController,
                  selectedValue: departmentController,
                  validator: validateDepartment,
                  disabled: departments == null,
                ),
                SizedBox(height: 24),
                RoundedPicker<CitiesResponse>(
                  label: 'Seleccione la Ciudad',
                  hintText: 'Seleccione la Ciudad',
                  buildItems:
                      cities
                          ?.map(
                            (city) => DropdownMenuItem<CitiesResponse>(
                              value: city,
                              child: Text(city.name),
                            ),
                          )
                          .toList() ??
                      [],
                  onChanged: setCityController,
                  selectedValue: cityController,
                  validator: validateCity,
                  disabled: cities == null,
                ),
                SizedBox(height: 24),
                if (errorMessage != null) ...[
                  Text(
                    errorMessage ?? '',
                    style: TextStyle(color: FomagColors.error),
                  ),
                  SizedBox(height: 24),
                ],
                PrimaryButton(text: 'Aplicar filtros', onPressed: onSearch),
                SizedBox(height: 24),
                if (isLoading != null) ...[
                  Skeletonizer(
                    enabled: isLoading == true,
                    child: Column(
                      children: [
                        Text(
                          'Centros Administrativos de Salud ${cityController?.name ?? ''}',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                            color: FomagColors.neutralBlueText,
                          ),
                        ),
                        SizedBox(height: 24),
                        if (healthCenters?.isEmpty == true &&
                            isLoading != true) ...[
                          Skeleton.ignore(
                            child: Text(
                              'No hay centros administrativos de salud',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: FomagColors.neutralTitleText,
                              ),
                            ),
                          ),
                        ],
                        Skeleton.replace(
                          replacement: ListView.builder(
                            shrinkWrap: true,
                            itemCount: 2,
                            physics: PageScrollPhysics(),
                            itemBuilder:
                                (context, index) => CardEntity(
                                  title: '',
                                  address: '',
                                  phone: '',
                                  phone2: '',
                                  onTap: () {},
                                ),
                          ),
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: healthCenters?.length ?? 0,
                            physics: PageScrollPhysics(),
                            itemBuilder:
                                (context, index) => CardEntity(
                                  title: healthCenters?[index].name ?? '',
                                  address: healthCenters?[index].address ?? '',
                                  phone: healthCenters?[index].phone1 ?? '',
                                  phone2: healthCenters?[index].phone2 ?? '',
                                  onTap: () {},
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
