import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/repositories/cities_repository.dart';

class GetCitiesUsecase {
  final CitiesRepository _repository;

  GetCitiesUsecase({required CitiesRepository repository})
    : _repository = repository;

  Future<Either<Failure<DioExceptionType>, List<CitiesResponse>>> call(
    int request,
  ) async {
    return _repository(request);
  }
}
