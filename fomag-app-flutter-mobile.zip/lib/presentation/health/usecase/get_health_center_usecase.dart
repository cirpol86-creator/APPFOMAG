import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/data/repositories/health_center_repository.dart';

class GetHealthCenterUsecase {
  final HealthCenterRepository _healthCenterRepository;

  GetHealthCenterUsecase({
    required HealthCenterRepository healthCenterRepository,
  }) : _healthCenterRepository = healthCenterRepository;

  Future<Either<Failure<DioExceptionType>, List<HealthCenterResponse>>>
  getHealthCenters(int request) async {
    return _healthCenterRepository.getHealthCenters(request);
  }
}
