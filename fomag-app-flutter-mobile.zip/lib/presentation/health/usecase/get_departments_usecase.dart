import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/repositories/departments_health_center_repository.dart';

class GetDepartmentsUsecase {
  final DepartmentsHealthCenterRepository _repository;

  GetDepartmentsUsecase({required DepartmentsHealthCenterRepository repository})
    : _repository = repository;

  Future<
    Either<Failure<DioExceptionType>, List<DepartmentsHealthCenterResponse>>
  >
  call() async {
    return _repository();
  }
}
