part of 'new_info_page.dart';

mixin NewInfoPageMixin<T extends StatefulWidget> on State<T> {
  NewsByIdContent? news;
  bool isLoading = true;
  String? errorMessage;

  void setNews(NewsByIdContent? value) {
    setState(() {
      news = value;
    });
  }

  void setIsLoading(bool value) {
    setState(() {
      isLoading = value;
    });
  }

  void setErrorMessage(String? value) {
    setState(() {
      errorMessage = value;
    });
  }

  void newsByIdSuccess(NewsByIdSuccess state) {
    setNews(state.response.content);
    setIsLoading(false);
  }

  void newsByIdLoading(NewsByIdLoading state) {
    setIsLoading(true);
  }

  void newsByIdFailure(NewsByIdFailure state) {
    setErrorMessage(state.message);
    setIsLoading(false);
  }

  void onRetry() {
    setErrorMessage(null);
    initNews();
  }

  void initNews() {
    context.read<NewsByIdBloc>().add(
      NewByIdSubmitted((widget as NewInfoPage).id),
    );
  }
}
