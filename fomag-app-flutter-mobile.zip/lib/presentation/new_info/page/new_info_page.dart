import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/presentation/new_info/bloc/news_by_id_bloc.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/copyright_widget.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';
import 'package:skeletonizer/skeletonizer.dart';

part 'new_info_page_mixin.dart';

class NewInfoPage extends StatefulWidget {
  const NewInfoPage({super.key, required this.id});

  final int id;

  @override
  State<NewInfoPage> createState() => _NewInfoPageState();
}

class _NewInfoPageState extends State<NewInfoPage> with NewInfoPageMixin {
  @override
  initState() {
    super.initState();
    initNews();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<NewsByIdBloc, NewInfoBloc>(
      listener: (context, state) {
        if (state is NewsByIdLoading) {
          newsByIdLoading(state);
        }
        if (state is NewsByIdSuccess) {
          newsByIdSuccess(state);
        }
        if (state is NewsByIdFailure) {
          newsByIdFailure(state);
        }
      },
      child: ScaffoldMain(
        errorMessage: errorMessage,
        onRetry: onRetry,
        body: Skeletonizer(
          enabled: isLoading,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Skeleton.replace(
                  replacement: Bone.multiText(style: TextStyle(fontSize: 24)),
                  child: Text(
                    news?.title ?? 'No hay titulo',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  news?.date ?? 'No hay fecha',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: FomagColors.black,
                    fontFamily: 'NunitoSans',
                  ),
                ),
                const SizedBox(height: 24),
                Skeleton.replace(
                  replacement: Column(
                    children: [
                      Skeleton.leaf(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          height: 180,
                          width: double.infinity,
                        ),
                      ),
                      const SizedBox(height: 24),
                      ...List.generate(5, (index) {
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Bone.multiText(),
                            const SizedBox(height: 8),
                          ],
                        );
                      }),
                    ],
                  ),
                  child: Html(
                    data: news?.body ?? 'Sin contenido',
                    style: {
                      'body': Style(
                        color: FomagColors.black,
                        fontFamily: 'NunitoSans',
                      ),
                    },
                  ),
                ),
                const SizedBox(height: 24),
                CopyrightWidget(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
