import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/data/repositories/news_by_id_repository.dart';

class NewsByIdUseCase {
  final NewsByIdRepository _repository;

  NewsByIdUseCase({required NewsByIdRepository repository})
    : _repository = repository;

  Future<Either<Failure<DioExceptionType>, NewsByIdResponse>> call(
    int uuid,
  ) async {
    return _repository.newsById(uuid);
  }
}
