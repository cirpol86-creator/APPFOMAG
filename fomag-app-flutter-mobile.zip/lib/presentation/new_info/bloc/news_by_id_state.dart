part of 'news_by_id_bloc.dart';

class NewInfoBloc extends Equatable {
  @override
  List<Object> get props => [];
}

class NewsByIdLoading extends NewInfoBloc {}

class NewsByIdSuccess extends NewInfoBloc {
  final NewsByIdResponse response;
  NewsByIdSuccess({required this.response});

  @override
  List<Object> get props => [response];
}

class NewsByIdFailure extends NewInfoBloc {
  final String message;
  NewsByIdFailure({required this.message});

  @override
  List<Object> get props => [message];
}