part of 'news_by_id_bloc.dart';

abstract class NewsByIdEvent extends Equatable {
  const NewsByIdEvent();

  @override
  List<Object> get props => [];
}

class NewByIdSubmitted extends NewsByIdEvent {
  final int uuid;

  const NewByIdSubmitted(this.uuid);

  @override
  List<Object> get props => [uuid];
}
