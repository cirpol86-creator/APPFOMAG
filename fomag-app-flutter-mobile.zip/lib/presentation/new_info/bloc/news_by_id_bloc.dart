import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/presentation/new_info/usecase/news_by_id_usecase.dart';

part 'news_by_id_event.dart';
part 'news_by_id_state.dart';

class NewsByIdBloc extends Bloc<NewsByIdEvent, NewInfoBloc> {
  final NewsByIdUseCase _newsByIdUseCase;


  NewsByIdBloc({required NewsByIdUseCase newsByIdUseCase})
      : _newsByIdUseCase = newsByIdUseCase,
        super(NewsByIdLoading()) {
    on<NewByIdSubmitted>(_onNewByIdSubmitted);
  }

  Future<void> _onNewByIdSubmitted(
      NewByIdSubmitted event,
      Emitter<NewInfoBloc> emit,
      ) async {
    emit(NewsByIdLoading());

    final result = await _newsByIdUseCase(event.uuid);

    result.fold(
          (Failure failure) {
        emit(NewsByIdFailure(message: mapFailureToMessage(failure)));
      },
          (NewsByIdResponse response) {
        emit(NewsByIdSuccess(response: response));
      },
    );
  }
}
