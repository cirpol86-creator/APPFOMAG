import 'package:fomagapp/data/model/request/register/register_request.dart';

abstract class RegisterEvent {}

class TrackerEvent extends RegisterEvent {}

class RegisterSubmitted extends RegisterEvent {
  final RegisterRequest request;

  RegisterSubmitted({required this.request});
}
