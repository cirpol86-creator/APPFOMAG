import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/register/bloc/register_event.dart';
import 'package:fomagapp/presentation/register/bloc/register_state.dart';
import 'package:fomagapp/presentation/register/usecase/register_usecase.dart';

class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
  final RegisterUseCase _registerUseCase;
  final TrackUserEventUseCase _trackUserEventUseCase;

  RegisterBloc({
    required RegisterUseCase registerUseCase,
    required TrackUserEventUseCase trackUserEventUseCase,
  }) : _registerUseCase = registerUseCase,
       _trackUserEventUseCase = trackUserEventUseCase,
       super(RegisterLoading()) {
    on<RegisterSubmitted>(_onRegister);
    on<TrackerEvent>(_onTrackerEvent);
  }

  Future<void> _onRegister(
    RegisterSubmitted event,
    Emitter<RegisterState> emit,
  ) async {
    emit(RegisterLoading());
    final result = await _registerUseCase.callRegister(event.request);

    result.fold(
      (Failure failure) {
        emit(RegisterFailure(message: mapFailureToMessage(failure)));
      },
      (RegisterResponse response) {
        emit(RegisterSuccess(response: response.message ?? ''));
      },
    );
  }

  void _onTrackerEvent(TrackerEvent event, Emitter<RegisterState> emit) {
    _trackUserEventUseCase.call(
      UserEventModel(UserEventType.register, {'screen_name': 'RegisterPage'}),
    );
  }
}

String mapFailureToMessage(Failure failure) {
  if (failure is ServerFailure) {
    return failure.message;
  } else if (failure is NoConnectionFailure) {
    return failure.message;
  } else {
    return failure.message;
  }
}
