import 'package:equatable/equatable.dart';
import 'package:fomagapp/data/model/response/department/department_response.dart';

abstract class RegisterState extends Equatable {
  @override
  List<Object?> get props => [];
}

class RegisterLoading extends RegisterState {}

class DeparmentsLoading extends RegisterState {}

class DeparmentsLoaded extends RegisterState {
  final List<DepartmentResponse> departmentResponse;
  final String? selectedDepartment;
  final List<String> selectedMunicipios;

  DeparmentsLoaded({
    required this.departmentResponse,
    this.selectedDepartment,
    this.selectedMunicipios = const [],
  });

  DeparmentsLoaded copyWith({
    String? selectedDepartment,
    List<String>? selectedMunicipios,
  }) {
    return DeparmentsLoaded(
      departmentResponse: departmentResponse,
      selectedDepartment: selectedDepartment ?? this.selectedDepartment,
      selectedMunicipios: selectedMunicipios ?? this.selectedMunicipios,
    );
  }
}

class DepartmentsError extends RegisterState {
  final String message;
  DepartmentsError({required this.message});

  @override
  List<Object?> get props => [message];
}

class CitiesSuccess extends RegisterState {
  final List<String> cities;

  CitiesSuccess({required this.cities});

  @override
  List<Object?> get props => [cities];
}

class RegisterSuccess extends RegisterState {
  final String response;
  RegisterSuccess({required this.response});

  @override
  List<Object?> get props => [response];
}

class RegisterFailure extends RegisterState {
  final String message;
  RegisterFailure({required this.message});

  @override
  List<Object?> get props => [message];
}
