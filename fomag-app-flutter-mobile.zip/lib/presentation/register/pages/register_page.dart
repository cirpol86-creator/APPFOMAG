// import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/types_documents.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_bloc.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_event.dart';
import 'package:fomagapp/presentation/terms_conditions/pages/terms_conditions_page.dart';
// import 'package:fomagapp/data/model/response/department/department_response.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/register/bloc/register_bloc.dart';
import 'package:fomagapp/presentation/register/bloc/register_event.dart';
import 'package:fomagapp/presentation/register/bloc/register_state.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_picker.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_text.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/screens/progress_loader_screen.dart';
import 'package:fomagapp/presentation/widgets/text_label.dart';
import 'package:url_launcher/url_launcher.dart';

part 'register_page_mixin.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> with RegisterPageMixin {
  @override
  void initState() {
    super.initState();
    // context.read<RegisterBloc>().add(DepartamentsLoad());
    _trackerEvent();
  }

  final List<String> requirements = const [
    '8 caracteres.',
    'Una mayúscula.',
    'Una minúscula.',
    'Un número.',
    'Un carácter especial (@, #, \$).',
    'Sin espacios',
  ];

  @override
  Widget build(BuildContext context) {
    return BlocListener<RegisterBloc, RegisterState>(
      listener: (context, state) {
        if (state is RegisterLoading) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (_) => ProgressLoaderScreen(
                    message:
                        'Estamos verificando tu información en Fomag... Esto tomará solo unos segundos.',
                    duration: Duration(seconds: 6),
                    onFinish: () {
                      // Navigator.of(context).pop();
                    },
                    forceEnableButton: false,
                  ),
            ),
          );
        }
        if (state is RegisterSuccess) {
          Navigator.of(context).pop();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (_) => ProgressLoaderScreen(
                    message: '✔ Hemos confirmado tu relación con el Fomag.',
                    duration: Duration(seconds: 0),
                    onFinish: () {
                      InformativeModal.show(
                        context: context,
                        title: 'Cuenta creada con éxito',
                        message: '',
                        buttonText: 'Continuar',
                        onButtonPressed: () {
                          NavigationController.push(Routes.login.routePath);
                        },
                        topIcon: Icons.check_circle_outline_rounded,
                        iconColor: FomagColors.greenButton,
                      );
                    },
                    forceEnableButton: true,
                  ),
            ),
          );
        }

        if (state is RegisterFailure) {
          RegExp regex = RegExp(r"^No ha sido posible completar su registro");
          if (state.message == 'Usuario ya existe') {
            InformativeModal.show(
              context: context,
              title: state.message,
              message: '',
              buttonText: 'Continuar',
              onButtonPressed: () {
                NavigationController.push(Routes.splashScreen.routePath);
              },
              topIcon: Icons.error_outline,
              iconColor: FomagColors.error,
            );
          }
          if (regex.hasMatch(state.message)) {
            final whatsappUrl = Uri.parse(
              'https://api.whatsapp.com/send/?phone=5719170628&text&type=phone_number&app_absent=0',
            );
            final chatWebUrl = Uri.parse(
              'https://fidu.ucontactcloud.com/WebChat/fiduprevisora/',
            );
            Navigator.push(
              context,
              MaterialPageRoute(
                builder:
                    (_) => ProgressLoaderScreen(
                      isError: true,
                      color: FomagColors.redButton,
                      messageLink: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: TextStyle(
                            fontFamily: 'NunitoSans',
                            color: FomagColors.black,
                          ),
                          children: [
                            const TextSpan(
                              text:
                                  '❌ No ha sido posible completar su registro en la aplicación, por favor comuníquese por whatsapp al número ',
                            ),
                            TextSpan(
                              text: '+57 19170628',
                              style: TextStyle(
                                fontFamily: 'NunitoSans',
                                color: FomagColors.black,
                                decoration: TextDecoration.underline,
                              ),
                              recognizer:
                                  TapGestureRecognizer()
                                    ..onTap = () {
                                      launchUrl(
                                        whatsappUrl,
                                        mode: LaunchMode.externalApplication,
                                      );
                                    },
                            ),
                            const TextSpan(text: ' o por medio del Chat Web '),
                            TextSpan(
                              text: 'Ingresa aquí para atención directa',
                              style: TextStyle(
                                fontFamily: 'NunitoSans',
                                color: FomagColors.black,
                                decoration: TextDecoration.underline,
                              ),
                              recognizer:
                                  TapGestureRecognizer()
                                    ..onTap = () {
                                      launchUrl(
                                        chatWebUrl,
                                        mode: LaunchMode.externalApplication,
                                      );
                                    },
                            ),
                          ],
                        ),
                      ),
                      duration: Duration(seconds: 0),
                      onFinish: () {
                        NavigationController.push(
                          Routes.splashScreen.routePath,
                        );
                      },
                      forceEnableButton: true,
                    ),
              ),
            );
          } else {
            // Navigator.of(context).pop();
            Navigator.push(
              context,
              MaterialPageRoute(
                builder:
                    (_) => ProgressLoaderScreen(
                      isError: true,
                      color: FomagColors.redButton,
                      message: '❌ ${state.message}',
                      duration: Duration(seconds: 0),
                      onFinish: () {
                        NavigationController.push(
                          Routes.splashScreen.routePath,
                        );
                      },
                      forceEnableButton: true,
                    ),
              ),
            );
          }
        }
        // if (state is DepartmentsError) {
        //   AwesomeDialog(
        //     context: context,
        //     dialogType: DialogType.error,
        //     animType: AnimType.rightSlide,
        //     title: 'Error',
        //     desc: state.message,
        //     btnOkOnPress: () {},
        //   ).show();
        // }
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: FomagColors.black),
            onPressed: () => NavigationController.pop(),
          ),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Crear una cuenta',
                  style: TextStyle(
                    fontSize: 35,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'NunitoSans',
                    foreground:
                        Paint()
                          ..style = PaintingStyle.stroke
                          ..strokeWidth = 0.7
                          ..color = FomagColors.neutralBlueTitle,
                  ),
                  textAlign: TextAlign.center,
                ),

                SizedBox(height: 40),
                RoundedPicker(
                  label: 'Tipo de documento',
                  hintText: '',
                  options: _typesDocumentName,
                  selectedValue:
                      _documentTypeController.text.isNotEmpty &&
                              _typesDocumentName.contains(
                                _documentTypeController.text,
                              )
                          ? _documentTypeController.text
                          : null,
                  onChanged:
                      (value) => setState(
                        () => _documentTypeController.text = value ?? '',
                      ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Selecciona un tipo de documento';
                    }
                    return null;
                  },
                ),

                SizedBox(height: 16),
                RoundedEntry(
                  label: 'Número de documento',
                  controller: _documentnumberController,
                  validator: _validateGenericDocument,
                ),
                SizedBox(height: 16),
                RoundedEntry(
                  label: 'Nombre Completo',
                  controller: _fullNameController,
                  validator: _validateGenericText,
                ),
                SizedBox(height: 16),
                RoundedEntry(
                  label: 'Correo electrónico',
                  controller: _emailController,
                  validator: _validateEmail,
                ),
                SizedBox(height: 16),
                RoundedEntry(
                  label: 'Celular',
                  keyboardType: TextInputType.number,
                  controller: _mobileController,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Campo obligatorio';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 16),
                RoundedEntry(
                  label: 'Contraseña',
                  isPassword: true,
                  controller: _passwordController,
                  validator: _validarPassword,
                ),

                SizedBox(height: 16),
                RoundedEntry(
                  label: 'Confirmar contraseña',
                  isPassword: true,
                  controller: _confirmPasswordController,
                  validator: _validarConfirmPassword,
                ),
                SizedBox(height: 16),
                const Text(
                  'La contraseña debe tener:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: FomagColors.black,
                    fontFamily: 'NunitoSans',
                  ),
                ),
                const SizedBox(height: 8),
                ...requirements.map(
                  (req) => Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '• ',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: FomagColors.black,
                          fontFamily: 'NunitoSans',
                        ),
                      ),
                      Expanded(
                        child: Text(
                          req,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: FomagColors.black,
                            fontFamily: 'NunitoSans',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 16),
                FormField<bool>(
                  initialValue: _aceptaDatos,
                  validator: (value) {
                    if (value != true) {
                      return 'Por favor acepta los términos y condiciones';
                    }
                    return null;
                  },
                  builder: (state) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Transform.scale(
                              scale: 1.5,
                              child: Checkbox(
                                value: state.value ?? false,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                  side: BorderSide(width: 0.7),
                                ),
                                side: BorderSide(
                                  width: 0.7,
                                  color:
                                      state.hasError
                                          ? FomagColors.redButton
                                          : FomagColors.black,
                                ),
                                onChanged: (value) {
                                  setState(() {
                                    _aceptaDatos = value ?? false;
                                    state.didChange(value);
                                  });
                                },
                              ),
                            ),
                            Expanded(
                              child: InkWell(
                                onTap: () {
                                  context.read<TermsConditionsBloc>().add(
                                    TermsConditionsSubmitted(),
                                  );
                                  TermsConditionsModal.show(
                                    context: context,
                                    onButtonPressed: () {
                                      setState(() {
                                        _aceptaDatos = true;
                                        state.didChange(true);
                                      });
                                      Navigator.of(context).pop();
                                    },
                                  );
                                },
                                child: Row(
                                  children: [
                                    CustomText(
                                      text: 'Acepto ',
                                      fontSize: 16.0,
                                      color:
                                          state.hasError
                                              ? FomagColors.redButton
                                              : FomagColors.black,
                                      fontWeight: FontWeight.normal,
                                    ),
                                    CustomText(
                                      text: 'términos y condiciones',
                                      fontSize: 16.0,
                                      color:
                                          state.hasError
                                              ? FomagColors.redButton
                                              : FomagColors.buttonPrimary,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (state.hasError)
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0, top: 4.0),
                            child: Text(
                              state.errorText!,
                              style: TextStyle(
                                color: FomagColors.redButton,
                                fontSize: 12,
                              ),
                            ),
                          ),
                      ],
                    );
                  },
                ),
                SizedBox(height: 16),
                PrimaryButton(text: 'Continuar', onPressed: _registrarse),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
