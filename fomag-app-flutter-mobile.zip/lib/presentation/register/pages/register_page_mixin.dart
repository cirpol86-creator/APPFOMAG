part of 'register_page.dart';

mixin RegisterPageMixin<T extends StatefulWidget> on State<T> {
  final _formKey = GlobalKey<FormState>();
  // List<DepartmentResponse> _states = [];
  // final TextEditingController _stateController = TextEditingController();
  // final TextEditingController _cityController = TextEditingController();
  final TextEditingController _documentTypeController = TextEditingController();
  // final TextEditingController _typeAffiliateController =
  // TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _documentnumberController =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  bool _aceptaDatos = false;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();

  // Nombres documentos
  List<String> get _typesDocumentName =>
      TypesDocuments.typesDocuments.map((e) => e.name).toList();

  // final List<String> _tiposAfiliado = ['Docente', 'Pensionado', 'Beneficiario'];

  String? _validarPassword(String? value) {
    print('-->> a $value-');
    if (value == null || value.trim().isEmpty) return 'Campo obligatorio';
    final passwordRegExp = RegExp(
      r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_])[^\s]{8,15}$',
    );
    if (!passwordRegExp.hasMatch(value)) {
      return 'La contraseña no cumple con los requisitos';
    }
    return null;
  }

  String? _validarConfirmPassword(String? value) {
    if (value == null || value.trim().isEmpty) return 'Campo obligatorio';
    if (value.trim() != _passwordController.text.trim()) {
      return 'La contraseña no coincide';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) return 'Campo obligatorio';
    final emailRegExp = RegExp(
      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
    );
    if (!emailRegExp.hasMatch(value.trim())) return 'Correo inválido';
    return null;
  }

  String? _validateGenericDocument(String? value) {
    if (value == null || value.isEmpty) {
      return 'Documento inválido';
    }

    final regex = RegExp(r'^[A-Za-z0-9]{5,15}$');
    if (!regex.hasMatch(value)) {
      return 'Debe tener entre 5 y 15 caracteres, solo letras y números';
    }

    return null; // válido
  }

  String? _validateGenericText(String? value) {
    if (value == null || value.isEmpty) {
      return 'Campo obligatorio';
    }
    final regex = RegExp(r'^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ\s]+$');
    if (!regex.hasMatch(value)) {
      return 'Solo se permiten letras, números y espacios';
    }
    return null;
  }

  void _registrarse() {
    if (_formKey.currentState!.validate()) {
      final selectedDocument = TypesDocuments.typesDocuments.firstWhere(
        (element) => element.name == _documentTypeController.text,
        orElse: () => TypesDocuments(id: '', name: ''),
      );
      final String documentTypeId = selectedDocument.id;
      RegisterRequest request = RegisterRequest(
        // userName: _userNameController.text.trim(),
        documentType: documentTypeId,
        documentNumber: _documentnumberController.text.trim(),
        fullName: _fullNameController.text,
        mobile: _mobileController.text.trim(),
        // state: _stateController.text,
        // city: _cityController.text,
        // typeAffiliate: _typeAffiliateController.text,
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
        acceptanceTerms: _aceptaDatos,
      );
      context.read<RegisterBloc>().add(RegisterSubmitted(request: request));
    }
  }

  @override
  void dispose() {
    _documentTypeController.dispose();
    _fullNameController.dispose();
    _documentnumberController.dispose();
    _confirmPasswordController.dispose();
    _passwordController.dispose();
    _emailController.dispose();
    _mobileController.dispose();
    super.dispose();
  }

  void _trackerEvent() {
    context.read<RegisterBloc>().add(TrackerEvent());
  }
}
