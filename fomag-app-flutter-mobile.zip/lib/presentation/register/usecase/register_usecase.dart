import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/data/repositories/register_repository.dart';

class RegisterUseCase {
  final RegisterRepository _register;

  RegisterUseCase({required RegisterRepository register})
    : _register = register;

  Future<Either<Failure<DioExceptionType>, RegisterResponse>> callRegister(
    RegisterRequest registerRequest,
  ) async {
    return _register.register(registerRequest);
  }
}
