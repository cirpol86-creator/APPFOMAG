import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';
import 'package:fomagapp/presentation/certificates/certificate_generator.dart';

class GetParamsCertificateByIdUsecase {
  final CertificateGenerator generator;

  GetParamsCertificateByIdUsecase({CertificateGenerator? generator})
    : generator = generator ?? CertificateGenerator();

  List<CertificateParam> getParams({required CertificateType certificate}) {
    final GetCertificate instance = generator.generate(
      certificate.id,
      certificate.path,
    );

    return instance.paramsIn();
  }
}
