import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';
import 'package:fomagapp/presentation/certificates/logic/certificate_factory.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';

class GenerateCertificateUsecase {
  final CertificatesRepository _certificateRepository;

  GenerateCertificateUsecase({
    required CertificatesRepository certificateRepository,
  }) : _certificateRepository = certificateRepository;

  Future<Either<Failure<DioExceptionType>, CertificateResponse>>
  generateCertificate({
    required CertificateType certificate,
    required Map<String, dynamic> formEntries,
  }) async {
    try {
      // 1. Crear instancia concreta de certificado
      final GetCertificate instance = CertificateFactory.generate(
        certificate.id,
        certificate.path,
      );

      // 2. Obtener body transformado
      final requestBody = await instance.paramsOut(formEntries);

      // 3. Llamar al repositorio
      final result = await _certificateRepository.generateCertificate(
        certificate.path,
        requestBody,
      );

      // 4. Manejar el resultado (si devuelve un Either, este paso puede variar)
      return result.fold((failure) => Left(failure), (response) {
        return Right(response);
      });
    } on DioException catch (e) {
      return Left(FailureUtils.fromDioError(e));
    } catch (e) {
      return Left(Failure(message: e.toString()));
    }
  }
}
