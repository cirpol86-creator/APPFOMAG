import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';

class GetTypesCertificatesUsecase {
  final CertificatesRepository _certificateRepository;

  GetTypesCertificatesUsecase({
    required CertificatesRepository certificateRepository,
  }) : _certificateRepository = certificateRepository;

  Future<Either<Failure<DioExceptionType>, CertificateTypeResponse>>
  getCertificates() async {
    final result = await _certificateRepository.getCertificatesType();

    return result.map((response) {
      response.content.sort((a, b) => a.name.compareTo(b.name));
      return response;
    });
  }
}
