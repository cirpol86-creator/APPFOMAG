import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/jwt_model.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';

class PaymentInterestUsecase {
  final CertificatesRepository _certificatesRepository;
  final Future<JwtUser?> Function()? decodeJwtUserFn;

  PaymentInterestUsecase({
    required CertificatesRepository certificatesRepository,
    this.decodeJwtUserFn,
  }) : _certificatesRepository = certificatesRepository;

  Future<Either<Failure<DioExceptionType>, List<String?>>>
  getPayInterestCertificate({String? vinculationType = ''}) async {
    final decode = decodeJwtUserFn ?? SecureStorageManager.decodeJwtUser;
    final jwtUser = await decode();

    final request = PayInterestCertificateRequest(
      documentNumber: jwtUser?.documentNumber ?? '',
      vinculacionType: vinculationType ?? '',
    );
    return _certificatesRepository.getPayInterestCertificate(request);
  }
}
