import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/data/repositories/garnishments_repository.dart';

class GarnishmentsListUsecase {
  final GarnishmentsRepository _garnishmentsRepository;

  GarnishmentsListUsecase({
    required GarnishmentsRepository garnishmentsRepository,
  }) : _garnishmentsRepository = garnishmentsRepository;

  Future<
    Either<Failure<DioExceptionType>, List<GarnishmentsCertificateResponse>>
  >
  getGarnishments() async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();
    final request = GarnishmentRequest(
      documentType: jwtUser?.documentTypeId ?? '',
      documentNumber: jwtUser?.documentNumber ?? '',
    );
    return _garnishmentsRepository.garnishmentslist(request);
  }
}
