import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/Interest_statement_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/affiliation_pension_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/discount_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/faculty_affiliation_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/garnishments_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/health_affiliation_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/income_with_holding_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/monthly_pension_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/not_affiliation_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/pay_interest_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/pay_sub_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/payment_state_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/severance_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/statement_pension_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/list_certificates/substitution_certificate.dart';

class CertificateFactory {
  static GetCertificate Function(int type, String url)? override;

  static GetCertificate generate(int type, String url) {
    if (override != null) return override!(type, url);
    switch (type) {
      case 1:
        return IncomeWithholdingCertificate();
      case 5:
        return MonthlyPensionCertificate();
      case 11:
        return FacultyAffiliationCertificate();
      case 13:
        return StatementPensionCertificate();
      case 9:
        return DiscountCertificate();
      case 4:
        return SubstitutionCertificate();
      case 7:
        return PayInterestCertificate();
      case 3:
        return NotAffiliationCertificate();
      case 6:
        return HealthAffiliationCertificate();
      case 2:
        return AffiliationPensionCertificate();
      case 12:
        return CertificateGarnishments();
      case 10:
        return SeveranceCertificate();
      case 14:
        return PaySubCertificate();
      case 15:
        return InterestStatementCertificate();
      case 16:
        return PaymentStateCertificate();

      default:
        throw UnsupportedError('Tipo de certificado no soportado');
    }
  }
}
