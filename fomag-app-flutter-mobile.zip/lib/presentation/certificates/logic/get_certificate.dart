import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

abstract class GetCertificate {
  List<CertificateParam> paramsIn();
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries);
}
