import 'package:fomagapp/core/network/util/const.dart';

class DateException implements Exception {
  final String message;
  DateException([this.message = Const.dateValidationMessageError]);

  @override
  String toString() => message;
}
