import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

class DiscountCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    final currentYear = DateTime.now().year;
    final years = List.generate(currentYear - 1990 + 1, (i) => 1990 + i);
    return [
      CertificateParam(
        name: 'vigenciaGeneracion',
        label: 'Seleccione el Año',
        type: 'select',
        options:
            years
                .map((e) => {"id": e.toString(), "label": e.toString()})
                .toList(),
      ),
    ];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();
    final year = entries['vigenciaGeneracion'];
    return {
      "tipoIdentificacion": jwtUser?.documentTypeId,
      "numeroIdentificacion": jwtUser?.documentNumber,
      "vigenciaGeneracion": year,
    };
  }

  static int getId() {
    return 9;
  }
}
