import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

class HealthAffiliationCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    return [];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();

    return {
      "UserCode": "Fiduprevisora",
      "Subject": "Certificado de afiliación",
      "CompanyId": "102",
      "ProcessId": "13002",
      "IdDocumentType": jwtUser?.documentTypeId,
      "DocumentNumber": jwtUser?.documentNumber,
      "Email": jwtUser?.email,
    };
  }

  static int getId() {
    return 6;
  }
}
