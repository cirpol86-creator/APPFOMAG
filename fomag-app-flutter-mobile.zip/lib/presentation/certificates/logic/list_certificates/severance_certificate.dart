import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/exception/date_exception.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';
import 'package:fomagapp/presentation/common/functions/common_functions.dart';

class SeveranceCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    return [
      CertificateParam(
        name: 'fechaInicial',
        label: 'Fecha Inicial',
        type: 'date',
      ),
      CertificateParam(name: 'fechaFinal', label: 'Fecha Final', type: 'date'),
    ];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();

    // Parseo de fechas como DateTime para validación
    final rawDateStart = entries['fechaInicial'];
    final rawDateEnd = entries['fechaFinal'];

    if (rawDateStart != null && rawDateEnd != null) {
      final start = DateTime.parse(rawDateStart); // formato ISO: yyyy-MM-dd
      final end = DateTime.parse(rawDateEnd);

      if (end.isBefore(start)) {
        throw DateException(Const.dateValidationMessageError);
      }
    }

    // Si pasa la validación, se formatean para el backend
    final dateStart = CommonFunctions().formatDateString(
      rawDateStart,
      'dd/MM/yyyy',
    );
    final dateEnd = CommonFunctions().formatDateString(
      rawDateEnd,
      'dd/MM/yyyy',
    );

    return {
      "tipoIdentificacion": jwtUser?.documentTypeId,
      "numeroIdentificacion": jwtUser?.documentNumber,
      "fechaInicial": dateStart,
      "fechaFinal": dateEnd,
    };
  }

  static int getId() {
    return 10;
  }
}
