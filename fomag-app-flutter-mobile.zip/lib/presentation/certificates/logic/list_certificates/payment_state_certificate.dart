import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/exception/date_exception.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

class PaymentStateCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    return [
      CertificateParam(name: 'fecIni', label: 'Fecha Inicial', type: 'date'),
      CertificateParam(name: 'fecFin', label: 'Fecha Final', type: 'date'),
    ];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();
    final dateStart = entries['fecIni'];
    final dateEnd = entries['fecFin'];

    // Validación de fechas
    if (dateStart != null && dateEnd != null) {
      final start = DateTime.parse(dateStart);
      final end = DateTime.parse(dateEnd);

      if (end.isBefore(start)) {
        throw DateException(Const.dateValidationMessageError);
      }
    }

    return {
      "numeroIdentificacion": jwtUser?.documentNumber,
      "tipoDocumento": jwtUser?.documentTypeId,
      "fecIni": dateStart,
      "fecFin": dateEnd,
    };
  }

  static int getId() {
    return 16;
  }
}
