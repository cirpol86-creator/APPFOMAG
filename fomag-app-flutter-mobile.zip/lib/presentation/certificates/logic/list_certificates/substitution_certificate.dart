import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

class SubstitutionCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    return [];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();

    return {
      "tipoIdentificacion": jwtUser?.documentTypeId,
      "numeroIdentificacion": jwtUser?.documentNumber,
    };
  }

  static int getId() {
    return 4;
  }
}
