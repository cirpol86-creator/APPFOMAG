import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

class IncomeWithholdingCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    final currentYear = DateTime.now().year;
    final years = List.generate(currentYear - 1990 + 1, (i) => 1990 + i);

    return [
      CertificateParam(
        name: 'vigenciaGravable',
        label: 'Seleccione el Año',
        type: 'select',
        options:
            years
                .map((e) => {"id": e.toString(), "label": e.toString()})
                .toList(),
      ),
    ];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final year = entries['vigenciaGravable'];
    final jwtUser = await SecureStorageManager.decodeJwtUser();

    return {
      "tipoIdentificacion": jwtUser?.documentTypeId,
      "vigenciaGravable": year,
      "numeroIdentificacion": jwtUser?.documentNumber,
    };
  }
}
