import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

class InterestStatementCertificate implements GetCertificate {
  @override
  List<CertificateParam> paramsIn() {
    final currentYear = DateTime.now().year;
    final years = List.generate(currentYear - 1990 + 1, (i) => 1990 + i);
    final months = [
      {"id": "01", "label": "Enero"},
      {"id": "02", "label": "Febrero"},
      {"id": "03", "label": "Marzo"},
      {"id": "04", "label": "Abril"},
      {"id": "05", "label": "Mayo"},
      {"id": "06", "label": "Junio"},
      {"id": "07", "label": "Julio"},
      {"id": "08", "label": "Agosto"},
      {"id": "09", "label": "Septiembre"},
      {"id": "10", "label": "Octubre"},
      {"id": "11", "label": "Noviembre"},
      {"id": "12", "label": "Diciembre"},
    ];

    return [
      CertificateParam(
        name: 'vigenciaGeneracion',
        label: 'Seleccione el Año',
        type: 'select',
        options:
            years
                .map((e) => {"id": e.toString(), "label": e.toString()})
                .toList(),
      ),
      CertificateParam(
        name: 'mesGeneracion',
        label: 'Seleccione el Mes',
        type: 'select',
        options: months.toList(),
      ),
    ];
  }

  @override
  Future<Map<String, dynamic>> paramsOut(Map<String, dynamic> entries) async {
    final year = entries['vigenciaGeneracion'];
    final month = entries['mesGeneracion'];
    final jwtUser = await SecureStorageManager.decodeJwtUser();

    return {
      "tipoIdentificacion": jwtUser?.documentTypeId,
      "vigenciaGeneracion": year,
      "mesGeneracion": month,
      "numeroIdentificacion": jwtUser?.documentNumber,
    };
  }

  static int getId() {
    return 15;
  }
}
