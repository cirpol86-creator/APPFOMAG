class CertificateParam {
  final String name; // nombre del parámetro (clave)
  final String label; // etiqueta legible para el usuario
  final String type; // 'year', 'month', 'text', etc.
  final List<dynamic>? options; // para dropdowns
  final bool required;

  CertificateParam({
    required this.name,
    required this.label,
    required this.type,
    this.options,
    this.required = true,
  });
}
