import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/certificate_factory.dart';

/// Clase wrapper para que `CertificateFactory.generate(...)` pueda ser mockeada en tests.
class CertificateGenerator {
  GetCertificate generate(int id, String path) {
    return CertificateFactory.generate(id, path);
  }
}
