import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/widgets/dynamic_dropdown_certificate.dart';

class YearGarnishmentsForm extends StatefulWidget {
  final Function(String?) onSelectedChanged;

  const YearGarnishmentsForm({super.key, required this.onSelectedChanged});

  @override
  State<YearGarnishmentsForm> createState() => YearGarnishmentsFormState();
}

class YearGarnishmentsFormState extends State<YearGarnishmentsForm> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedYear;

  bool validate() {
    return _formKey.currentState?.validate() ?? false;
  }

  String? get selectedYear => _selectedYear;

  @override
  Widget build(BuildContext context) {
    final currentYear = DateTime.now().year;
    final years = List.generate(currentYear - 1990 + 1, (i) => 1990 + i);

    return Form(
      key: _formKey,
      child: DynamicDropdownField(
        label: 'Seleccione el año de embargo para descargar',
        hintText: '',
        options:
            years
                .map((e) => {"id": e.toString(), "label": e.toString()})
                .toList(),
        value: _selectedYear,
        onChanged: (value) {
          setState(() {
            _selectedYear = value;
          });
          widget.onSelectedChanged(value);
        },
        validator:
            (value) =>
                value == null || value.isEmpty
                    ? 'Este campo es obligatorio'
                    : null,
      ),
    );
  }
}
