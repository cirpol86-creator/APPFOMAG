import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/presentation/account/pages/account_page.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/widgets/year_garnishments.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/modals/custom_modal_dialog.dart';

class CardEmbargos extends StatefulWidget {
  final GarnishmentsCertificateResponse garnishments;
  final CertificateType? selected;

  const CardEmbargos({super.key, required this.garnishments, this.selected});

  @override
  State<CardEmbargos> createState() => _CardEmbargosState();
}

class _CardEmbargosState extends State<CardEmbargos> {
  Future<void> _sendData(
    BuildContext context,
    Map<String, dynamic> data,
  ) async {
    context.read<CertificateGenerateBloc>().add(
      GenerateCertificate(data, widget.selected!),
    );
    Navigator.of(context).pop();
  }

  TextStyle _labelStyle() => const TextStyle(
    color: FomagColors.black,
    fontSize: 14,
    fontFamily: 'NunitoSans',
    fontWeight: FontWeight.bold,
  );

  TextStyle _valueStyle() => const TextStyle(
    color: FomagColors.black,
    fontSize: 14,
    fontFamily: 'NunitoSans',
    fontWeight: FontWeight.w400,
  );

  Widget _buildRichText(String label, String value, {bool isHeader = false}) {
    return RichText(
      text: TextSpan(
        text: '$label:',
        style: _labelStyle().copyWith(fontSize: 16),
        children: [
          TextSpan(
            text: ' $value',
            style: _valueStyle().copyWith(fontSize: 16),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final yearFormKey = GlobalKey<YearGarnishmentsFormState>();
    String? selectedYear;

    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(width: 1.0, color: FomagColors.buttonOutline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildRichText(
            'Documento Demandante',
            widget.garnishments.claimantDocumentNumber ?? '-',
            isHeader: true,
          ),
          _buildRichText(
            'Demandante',
            '${widget.garnishments.fullNameClaimant ?? '-'} ${widget.garnishments.surnameClaimant ?? '-'}',
          ),
          _buildRichText('Juzgado', widget.garnishments.officialEmbargo ?? '-'),
          _buildRichText('Proceso', widget.garnishments.processNumber ?? '-'),
          _buildRichText(
            'Naturaleza del Proceso',
            widget.garnishments.natureProcess ?? '-',
          ),
          _buildRichText(
            'Prestación Embargada',
            widget.garnishments.descriptionOfServices ?? '-',
          ),
          _buildRichText('Estado', widget.garnishments.state ?? '-'),
          const SizedBox(height: 6.0),
          PrimaryButton(
            text: 'Generar',
            onPressed: () {
              CustomModalDialog.show(
                cancelText: 'Cancelar',
                context: context,
                title: 'Generar Certificado de Detalle de Embargos',
                content: YearGarnishmentsForm(
                  key: yearFormKey,
                  onSelectedChanged: (value) {
                    selectedYear = value;
                  },
                ),
                onConfirm: () {
                  final formState = yearFormKey.currentState;
                  if (formState != null && formState.validate()) {
                    final data = {
                      "year": formState.selectedYear,
                      "consecutivoEmbargo":
                          widget.garnishments.consecutiveGarnishment,
                      "numeroProceso": widget.garnishments.processNumber,
                    };
                    _sendData(context, data);
                  }
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

class CardCertificates extends StatelessWidget {
  final String garnishments;
  final CertificateType? selected;

  const CardCertificates({
    super.key,
    required this.garnishments,
    this.selected,
  });

  Future<void> _sendData(
    BuildContext context,
    Map<String, dynamic> data,
  ) async {
    context.read<CertificateGenerateBloc>().add(
      GenerateCertificate(data, selected!),
    );
  }

  TextStyle _labelStyle() => const TextStyle(
    color: FomagColors.black,
    fontSize: 20,
    fontFamily: 'Poppins',
    fontWeight: FontWeight.bold,
  );

  TextStyle _valueStyle() => const TextStyle(
    color: FomagColors.black,
    fontSize: 18,
    fontFamily: 'NunitoSans',
    fontWeight: FontWeight.w600,
  );

  Widget _buildRichText(String label, String value, {bool isHeader = false}) {
    return RichText(
      text: TextSpan(
        text: '$label:',
        style: isHeader ? _labelStyle().copyWith(fontSize: 16) : _labelStyle(),
        children: [
          TextSpan(
            text: ' $value',
            style:
                isHeader ? _valueStyle().copyWith(fontSize: 16) : _valueStyle(),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(width: 1.0, color: FomagColors.buttonOutline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildRichText('Vinculación', garnishments.capitalize() ?? ''),
          const SizedBox(height: 6.0),
          Align(
            alignment: Alignment.centerRight,
            child: SizedBox(
              width: 100.0,
              child: PrimaryButton(
                text: 'Generar',
                onPressed: () {
                  final data = {"vinculacion": garnishments};
                  _sendData(context, data);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
