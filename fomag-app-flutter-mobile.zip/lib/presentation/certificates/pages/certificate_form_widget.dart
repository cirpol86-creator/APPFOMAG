import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_state.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/date_picker_field.dart';
import 'package:fomagapp/presentation/widgets/dynamic_dropdown_certificate.dart';

class CertificateFormWidget extends StatefulWidget {
  final CertificateType selected;
  final List<CertificateParam> params;

  const CertificateFormWidget({
    super.key,
    required this.selected,
    required this.params,
  });

  @override
  State<CertificateFormWidget> createState() => _CertificateFormWidgetState();
}

class _CertificateFormWidgetState extends State<CertificateFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, dynamic> _formValues = {};
  final Map<String, TextEditingController> _controllers = {};

  @override
  void dispose() {
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CertificateGenerateBloc, CertificateGenerateState>(
      builder: (context, state) {
        return Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ...widget.params.map((CertificateParam param) {
                  if (param.type == 'year' ||
                      param.type == 'month' ||
                      param.type == 'select') {
                    return Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: DynamicDropdownField(
                        label: param.label,
                        hintText: param.label,
                        options: param.options ?? [],
                        value: _formValues[param.name],
                        onChanged: (value) {
                          setState(() {
                            _formValues[param.name] = value;
                          });
                        },
                        validator:
                            (value) =>
                                value == null
                                    ? 'Este campo es obligatorio'
                                    : null,
                      ),
                    );
                  } else if (param.type == 'date') {
                    _controllers[param.name] ??= TextEditingController(
                      text: _formValues[param.name] ?? '',
                    );
                    return Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: DatePickerField(
                        label: param.label,
                        controller: _controllers[param.name]!,
                        onChanged: (value) {
                          setState(() {
                            _formValues[param.name] = value;
                          });
                        },
                        validator:
                            (value) =>
                                value == null || value.isEmpty
                                    ? 'Este campo es obligatorio'
                                    : null,
                      ),
                    );
                  } else {
                    return Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: param.label,
                          border: const OutlineInputBorder(),
                        ),
                        keyboardType:
                            param.type == 'number'
                                ? TextInputType.number
                                : TextInputType.text,
                        onChanged: (value) {
                          _formValues[param.name] = value;
                        },
                        validator:
                            (value) =>
                                value == null || value.isEmpty
                                    ? 'Este campo es obligatorio'
                                    : null,
                      ),
                    );
                  }
                }),
                const SizedBox(height: 24),
                PrimaryButton(
                  text: 'Enviar',
                  visible:
                      !widget.selected.isGarnishment &&
                      !widget.selected.isPayInterest,
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      context.read<CertificateGenerateBloc>().add(
                        GenerateCertificate(_formValues, widget.selected),
                      );
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
