// part of 'search_certificates_page.dart';

// mixin SearchCertificatesMixin<T extends StatefulWidget> on State<T>{
//   final _formKey = GlobalKey<FormState>();
//   final Map<AdditionalFieldCertificateTypeModel, TextEditingController> _controllers = {};
// }
