import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_state.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/widgets/card_embargos.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';

class EmbargoListWidget extends StatelessWidget {
  final CertificateType selected;

  const EmbargoListWidget({super.key, required this.selected});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CertificateGenerateBloc, CertificateGenerateState>(
      builder: (context, state) {
        final garnishments = state.garnishments;

        if (garnishments.isEmpty) {
          return const Text('');
        }

        return Padding(
          padding: const EdgeInsets.only(top: 0),
          child: ListView.separated(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: garnishments.length,
            itemBuilder: (context, index) {
              return CardEmbargos(
                garnishments: garnishments[index],
                selected: selected,
              );
            },
            separatorBuilder: (_, __) => const SizedBox(height: 10),
          ),
        );
      },
    );
  }
}

class PayInterestCertificateListWidget extends StatelessWidget {
  final CertificateType selected;

  const PayInterestCertificateListWidget({super.key, required this.selected});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CertificateGenerateBloc, CertificateGenerateState>(
      builder: (context, state) {
        final garnishments = state.certificateTypes;

        if (garnishments.isEmpty) {
          return const Text('');
        }

        return Padding(
          padding: const EdgeInsets.only(top: 0),
          child: ListView.separated(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: garnishments.length,
            itemBuilder: (context, index) {
              return CardCertificates(
                garnishments: garnishments[index],
                selected: selected,
              );
            },
            separatorBuilder: (_, __) => const SizedBox(height: 10),
          ),
        );
      },
    );
  }
}
