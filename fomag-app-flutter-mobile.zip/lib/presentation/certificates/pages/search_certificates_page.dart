import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_state.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_state.dart';
import 'package:fomagapp/presentation/certificates/pages/certificate_type_selector_widget.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class SearchCertificatesPage extends StatefulWidget {
  const SearchCertificatesPage({super.key});

  @override
  State<SearchCertificatesPage> createState() => _SearchCertificatesPageState();
}

class _SearchCertificatesPageState extends State<SearchCertificatesPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final bloc = context.read<CertificatesTypeBloc>();
      bloc.add(ResetCertificates());
      bloc.add(GetCertificates());
    });
    _trackerEvent();
  }

  @override
  void dispose() {
    super.dispose();
    //context.read<CertificatesTypeBloc>().add(ResetCertificates());
  }

  void _trackerEvent() {
    context.read<CertificateGenerateBloc>().add(TrackerEvent());
  }

  @override
  Widget build(BuildContext context) {
    final generateState = context.watch<CertificateGenerateBloc>().state;
    final typeState = context.watch<CertificatesTypeBloc>().state;

    final isLoading =
        generateState.status == CertificateGenerateStatus.loading ||
        typeState is CertificatesTypeLoading;

    return MultiBlocListener(
      listeners: [
        BlocListener<CertificateGenerateBloc, CertificateGenerateState>(
          listener: (context, state) {
            switch (state.status) {
              case CertificateGenerateStatus.failure:
                InformativeModal.show(
                  context: context,
                  title: 'No podemos generar el certificado',
                  message: state.message ?? 'Ha ocurrido un error',
                  buttonText: 'Continuar',
                  topIcon: Icons.sentiment_dissatisfied_rounded,
                  iconColor: FomagColors.neutralTitleText,
                  buttonColor: FomagColors.buttonPrincipal,
                  dismissible: false,
                  onButtonPressed: () => Navigator.pop(context),
                );
                break;

              case CertificateGenerateStatus.showHealthDialog:
                InformativeModal.show(
                  context: context,
                  title: 'Certificado generado con éxito',
                  message: state.message ?? '',
                  buttonText: 'Continuar',
                  topIcon: Icons.check_circle_outline_rounded,
                  iconColor: FomagColors.greenButton,
                  buttonColor: FomagColors.buttonPrincipal,
                  dismissible: false,
                  onButtonPressed: () => Navigator.pop(context),
                );
                break;

              default:
                break;
            }
          },
        ),
      ],
      child: ScaffoldSimple(
        isLoading: isLoading,
        body: const CertificateTypeSelectorWidget(),
      ),
    );
  }
}
