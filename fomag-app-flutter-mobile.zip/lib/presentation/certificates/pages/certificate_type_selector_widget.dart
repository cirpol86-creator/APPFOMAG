// certificate_type_selector_widget.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_state.dart';
import 'package:fomagapp/presentation/certificates/pages/embargo_list_widget.dart';
import 'package:fomagapp/presentation/widgets/dropdown_certificate_type.dart';
import 'package:fomagapp/presentation/widgets/buttons/secondary_button.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';
import 'certificate_form_widget.dart';

class CertificateTypeSelectorWidget extends StatelessWidget {
  const CertificateTypeSelectorWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      child: BlocBuilder<CertificatesTypeBloc, CertificatesTypeState>(
        builder: (context, state) {
          List<CertificateType> options = [];
          CertificateType? selected;
          List<CertificateParam> params = [];

          if (state is CertificatesTypeSuccess) {
            options = state.response;
            selected = state.selected;
            params = state.params;
          }

          if (state is CertificatesTypeFailure) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Ocurrió un error al cargar los datos. Por favor, intente nuevamente.',
                  style: TextStyle(
                    color: FomagColors.errorOtp,
                    fontSize: 16,
                    fontFamily: 'NunitoSans',
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 16),
                SecondaryButton(
                  text: 'Reintentar',
                  onPressed: () {
                    context.read<CertificatesTypeBloc>().add(
                      const GetCertificates(force: true),
                    );
                  },
                ),
              ],
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Descargar Certificados',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'NunitoSans',
                  foreground:
                      Paint()
                        ..style = PaintingStyle.stroke
                        ..strokeWidth = 0.7
                        ..color = FomagColors.neutralBlueTitle,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Elija el tipo de certificado que quiere descargar.',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: FomagColors.black,
                  fontFamily: 'NunitoSans',
                ),
              ),
              const SizedBox(height: 24),
              DropdownCertificateType(
                label: 'Tipo de certificado',
                hintText: 'Tipo de certificado',
                options: options,
                value: selected,
                onChanged: (CertificateType? value) {
                  if (value != null) {
                    context.read<CertificatesTypeBloc>().add(
                      CertificateTypeSelectedChanged(value),
                    );

                    if (value.isGarnishment) {
                      context.read<CertificateGenerateBloc>().add(
                        GetGarnishments(),
                      );
                    }

                    if (value.isPayInterest) {
                      context.read<CertificateGenerateBloc>().add(
                        GetCertificateInterest(),
                      );
                    }
                  }
                },
                validator:
                    (value) =>
                        value == null
                            ? 'Selecciona un tipo de certificado'
                            : null,
              ),

              if (selected != null)
                CertificateFormWidget(selected: selected, params: params),
              if (selected != null && selected.isGarnishment)
                EmbargoListWidget(selected: selected),
              if (selected != null && selected.isPayInterest)
                PayInterestCertificateListWidget(selected: selected),
            ],
          );
        },
      ),
    );
  }
}
