import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_state.dart';
import 'package:fomagapp/presentation/certificates/logic/exception/date_exception.dart';
import 'package:fomagapp/presentation/certificates/usecase/garnishments_list_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/generate_certificate_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/payment_interest_usecase.dart';
import 'package:fomagapp/presentation/widgets/download_pdf/download_pdf.dart';
import 'package:open_filex/open_filex.dart';

class CertificateGenerateBloc
    extends Bloc<CertificateGenerateEvent, CertificateGenerateState> {
  final GenerateCertificateUsecase _generateCertificateUseCase;
  final DownloadPdfUseCase _downloadPdfUseCase;
  final GarnishmentsListUsecase _garnishmentsListUsecase;
  final PaymentInterestUsecase _paymentInterestUsecase;
  final TrackUserEventUseCase _trackUserEventUseCase;

  CertificateGenerateBloc({
    required GenerateCertificateUsecase generateCertificateUseCase,
    required DownloadPdfUseCase downloadPdfUseCase,
    required GarnishmentsListUsecase garnishmentsListUsecase,
    required PaymentInterestUsecase paymentInterestUsecase,
    required TrackUserEventUseCase trackUserEventUseCase,
  }) : _generateCertificateUseCase = generateCertificateUseCase,
       _downloadPdfUseCase = downloadPdfUseCase,
       _garnishmentsListUsecase = garnishmentsListUsecase,
       _paymentInterestUsecase = paymentInterestUsecase,
       _trackUserEventUseCase = trackUserEventUseCase,
       super(const CertificateGenerateState()) {
    on<GenerateCertificate>(_onGenerateCertificate);
    on<GetGarnishments>(_onGetGarnishment);
    on<GetCertificateInterest>(_onGetPaymentCertificateInterest);
    on<TrackerEvent>(_onTrackerEvent);
  }

  Future<void> _onGenerateCertificate(
    GenerateCertificate event,
    Emitter<CertificateGenerateState> emit,
  ) async {
    try {
      emit(state.copyWith(status: CertificateGenerateStatus.loading));

      final result = await _generateCertificateUseCase.generateCertificate(
        certificate: event.selectedCertificate,
        formEntries: event.values,
      );

      await result.fold(
        (failure) async {
          emit(
            state.copyWith(
              status: CertificateGenerateStatus.failure,
              message: mapFailureToMessage(failure),
            ),
          );
        },
        (response) async {
          if (event.selectedCertificate.isHealthCertificate) {
            if (response.isSuccess == true) {
              emit(
                state.copyWith(
                  status: CertificateGenerateStatus.showHealthDialog,
                  message:
                      'El certificado de afiliación a salud será enviado al correo electrónico registrado.',
                ),
              );
            } else {
              emit(
                state.copyWith(
                  status: CertificateGenerateStatus.failure,
                  message:
                      'El certificado no está disponible en este momento. Estamos trabajando para restablecer el servicio. Por favor, intente nuevamente en unos minutos.',
                ),
              );
            }
            return;
          }

          // Para certificados normales
          final jwtUser = await SecureStorageManager.decodeJwtUser();
          final today = DateTime.now();
          final date = '${today.year}-${today.month}-${today.day}';
          final fileName =
              '${date}_${jwtUser?.username ?? ''}_${event.selectedCertificate.name}.pdf';

          if (response.url?.isNotEmpty == true) {
            final savedPath = await _downloadPdfUseCase.execute(
              url: response.url!,
              filename: fileName,
            );

            emit(state.copyWith(status: CertificateGenerateStatus.success));
            await OpenFilex.open(savedPath);
          } else {
            emit(
              state.copyWith(
                status: CertificateGenerateStatus.failure,
                message: 'No hay certificados generados.',
              ),
            );
          }
          _trackUserEventUseCase(
            UserEventModel(UserEventType.downloadCertificate, {
              'downloaded_certificate': event.selectedCertificate.name,
            }),
          );
        },
      );
    } catch (exception) {
      if (exception is DateException) {
        emit(
          state.copyWith(
            status: CertificateGenerateStatus.failure,
            message: exception.message,
          ),
        );
      }
    }
  }

  Future<void> _onGetGarnishment(
    GetGarnishments event,
    Emitter<CertificateGenerateState> emit,
  ) async {
    emit(
      state.copyWith(
        status: CertificateGenerateStatus.loading,
        garnishments: state.garnishments, // <- preservar
      ),
    );

    final result = await _garnishmentsListUsecase.getGarnishments();

    result.fold(
      (failure) {
        emit(
          state.copyWith(
            status: CertificateGenerateStatus.failure,
            message: mapFailureToMessage(failure),
          ),
        );
      },
      (garnishments) {
        emit(
          state.copyWith(
            status: CertificateGenerateStatus.success,
            garnishments: garnishments,
          ),
        );
      },
    );
  }

  Future<void> _onGetPaymentCertificateInterest(
    GetCertificateInterest event,
    Emitter<CertificateGenerateState> emit,
  ) async {
    emit(
      state.copyWith(
        status: CertificateGenerateStatus.loading,
        garnishments: state.garnishments,
      ),
    );

    final result = await _paymentInterestUsecase.getPayInterestCertificate();

    result.fold(
      (failure) {
        emit(
          state.copyWith(
            status: CertificateGenerateStatus.failure,
            message: mapFailureToMessage(failure),
          ),
        );
      },
      (list) {
        if (list.isEmpty == true) {
          emit(
            state.copyWith(
              status: CertificateGenerateStatus.failure,
              message:
                  "No se encontraron datos registrados para generar este certificado. Actualmente no tiene información asociada para este tipo de solicitud.",
            ),
          );
        } else {
          emit(
            state.copyWith(
              status: CertificateGenerateStatus.success,
              certificateTypes: list.whereType<String>().toList(),
            ),
          );
        }
      },
    );
  }

  void _onTrackerEvent(
    TrackerEvent event,
    Emitter<CertificateGenerateState> emit,
  ) {
    _trackUserEventUseCase.call(
      UserEventModel(UserEventType.certificates, {
        'screen_name': 'SearchCertificatesPage',
      }),
    );
  }
}
