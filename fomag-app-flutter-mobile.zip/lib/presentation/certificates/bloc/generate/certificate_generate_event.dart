// certificate_generate_event.dart
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';

abstract class CertificateGenerateEvent {}

class GenerateCertificate extends CertificateGenerateEvent {
  final Map<String, dynamic> values;
  final CertificateType selectedCertificate;

  GenerateCertificate(this.values, this.selectedCertificate);
}

class GetGarnishments extends CertificateGenerateEvent {}

class GetCertificateInterest extends CertificateGenerateEvent {}

class TrackerEvent extends CertificateGenerateEvent {}
