// certificate_generate_state.dart
import 'package:equatable/equatable.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';

enum CertificateGenerateStatus {
  initial,
  loading,
  success,
  failure,
  showHealthDialog,
}

class CertificateGenerateState extends Equatable {
  final CertificateGenerateStatus status;
  final String? message;
  final List<GarnishmentsCertificateResponse> garnishments;
  final List<String> certificateTypes;

  const CertificateGenerateState({
    this.status = CertificateGenerateStatus.initial,
    this.message,
    this.garnishments = const [],
    this.certificateTypes = const [],
  });

  CertificateGenerateState copyWith({
    CertificateGenerateStatus? status,
    String? message,
    List<GarnishmentsCertificateResponse>? garnishments,
    List<String>? certificateTypes,
  }) {
    return CertificateGenerateState(
      status: status ?? this.status,
      message: message,
      garnishments: garnishments ?? this.garnishments,
      certificateTypes: certificateTypes ?? this.certificateTypes,
    );
  }

  @override
  List<Object?> get props => [status, message, garnishments, certificateTypes];
}
