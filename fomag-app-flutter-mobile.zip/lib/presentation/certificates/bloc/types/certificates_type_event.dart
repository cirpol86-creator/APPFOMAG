import 'package:equatable/equatable.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';

abstract class CertificatesTypeEvent extends Equatable {
  const CertificatesTypeEvent();

  @override
  List<Object?> get props => [];
}

class GetCertificates extends CertificatesTypeEvent {
  final bool force;

  const GetCertificates({this.force = false});

  @override
  List<Object?> get props => [force];
}

class CertificateTypeSelectedChanged extends CertificatesTypeEvent {
  final CertificateType selectedCertificate;

  const CertificateTypeSelectedChanged(this.selectedCertificate);

  @override
  List<Object?> get props => [selectedCertificate];
}

class ResetCertificates extends CertificatesTypeEvent {}