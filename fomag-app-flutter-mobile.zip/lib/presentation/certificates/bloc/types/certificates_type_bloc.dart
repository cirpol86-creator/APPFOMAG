import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_state.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_params_certificate_by_id.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_types_certificates_usecase.dart';

class CertificatesTypeBloc
    extends Bloc<CertificatesTypeEvent, CertificatesTypeState> {
  final GetTypesCertificatesUsecase _certificatesUsecase;
  final GetParamsCertificateByIdUsecase _getParamsCertificateByIdUsecase;

  CertificatesTypeBloc({
    required GetTypesCertificatesUsecase certificatesUsecase,
    required GetParamsCertificateByIdUsecase getParamsCertificateByIdUsecase,
  }) : _certificatesUsecase = certificatesUsecase,
       _getParamsCertificateByIdUsecase = getParamsCertificateByIdUsecase,
       super(CertificatesTypeInitial()) {
    on<GetCertificates>(_onGetCertificates);
    on<CertificateTypeSelectedChanged>(_onCertificateTypeChanged);
    on<ResetCertificates>((event, emit) {
    emit(CertificatesTypeInitial());
  });
  }

  Future<void> _onGetCertificates(
    GetCertificates event,
    Emitter<CertificatesTypeState> emit,
  ) async {
    // evita recargar si ya está en memoria y no se fuerza
    if (state is CertificatesTypeSuccess && !event.force) return;

    emit(CertificatesTypeLoading());

    final result = await _certificatesUsecase.getCertificates();

    result.fold(
      (failure) =>
          emit(CertificatesTypeFailure(message: mapFailureToMessage(failure))),
      (response) {
        final types = response.content;
        if (types.isNotEmpty) {
          emit(
            CertificatesTypeSuccess(
              response: types,
              selected: null,
              params: [],
            ),
          );
        } else {
          emit(
            CertificatesTypeFailure(
              message: 'No hay certificados disponibles.',
            ),
          );
        }
      },
    );
  }

  Future<void> _onCertificateTypeChanged(
    CertificateTypeSelectedChanged event,
    Emitter<CertificatesTypeState> emit,
  ) async {
    final currentState = state;
    if (currentState is CertificatesTypeSuccess) {
      final params = _getParamsCertificateByIdUsecase.getParams(
        certificate: event.selectedCertificate,
      );

      emit(
        currentState.copyWith(
          selected: event.selectedCertificate,
          params: params,
        ),
      );
    }
  }
}
