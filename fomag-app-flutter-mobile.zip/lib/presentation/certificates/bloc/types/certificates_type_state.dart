import 'package:equatable/equatable.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';

abstract class CertificatesTypeState extends Equatable {
  const CertificatesTypeState();

  @override
  List<Object?> get props => [];
}

class CertificatesTypeInitial extends CertificatesTypeState {}

class CertificatesTypeLoading extends CertificatesTypeState {}

class CertificatesTypeFailure extends CertificatesTypeState {
  final String message;

  const CertificatesTypeFailure({required this.message});

  @override
  List<Object?> get props => [message];
}

class CertificatesTypeSuccess extends CertificatesTypeState {
  final List<CertificateType> response;
  final CertificateType? selected;
  final List<CertificateParam> params;

  const CertificatesTypeSuccess({
    required this.response,
    required this.selected,
    required this.params,
  });

  CertificatesTypeSuccess copyWith({
    List<CertificateType>? response,
    CertificateType? selected,
    List<CertificateParam>? params,
    List<GarnishmentsCertificateResponse>? garnishments,
  }) {
    return CertificatesTypeSuccess(
      response: response ?? this.response,
      selected: selected ?? this.selected,
      params: params ?? this.params,
    );
  }

  @override
  List<Object?> get props => [response, selected, params];
}
