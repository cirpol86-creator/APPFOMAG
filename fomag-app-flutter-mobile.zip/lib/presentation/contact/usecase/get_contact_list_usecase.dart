import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/data/repositories/contact_info_repository.dart';

class GetContactListUseCase {
  final ContactRepository _contactRepository;

  GetContactListUseCase({required ContactRepository contactRepository})
    : _contactRepository = contactRepository;

  Future<Either<Failure<DioExceptionType>, List<ContentResponse>>>
  call() async {
    return _contactRepository.getContactList();
  }
}
