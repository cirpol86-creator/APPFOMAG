import 'package:equatable/equatable.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';

abstract class ContactState extends Equatable {
  const ContactState();

  @override
  List<Object?> get props => [];
}

class ContactInitial extends ContactState {}

class ContactLoading extends ContactState {}

class ContactLoaded extends ContactState {
  final List<ContentResponse> contactList;

  const ContactLoaded(this.contactList);

  @override
  List<Object?> get props => [contactList];
}

class ContactError extends ContactState {
  final String message;

  const ContactError({required this.message});

  @override
  List<Object?> get props => [message];
}
