import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/presentation/contact/usecase/get_contact_list_usecase.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';

import 'contact_event.dart';
import 'contact_state.dart';

class ContactBloc extends Bloc<ContactEvent, ContactState> {
  final GetContactListUseCase _getContactListUseCase;

  ContactBloc({required GetContactListUseCase getContactListUseCase})
    : _getContactListUseCase = getContactListUseCase,
      super(ContactInitial()) {
    on<LoadContactData>(_onLoadContactData);
  }

  Future<void> _onLoadContactData(
    LoadContactData event,
    Emitter<ContactState> emit,
  ) async {
    emit(ContactLoading());

    final result = await _getContactListUseCase();

    result.fold(
      (Failure failure) {
        emit(ContactError(message: mapFailureToMessage(failure)));
      },
      (List<ContentResponse> contacts) {
        final hasInvalidCoordinates = contacts.any(
          (c) => c.latitud == 0.0 || c.longitud == 0.0,
        );

        if (hasInvalidCoordinates) {
          final context =
              NavigationController.globalNavigatorKey.currentContext;

          if (context != null) {
            InformativeModal.show(
              context: context,
              title: 'Error',
              message:
                  'Coordenadas inválidas en uno de los centros de atención. Serás redirigido al inicio.',
              buttonText: 'Aceptar',
              onButtonPressed: () {
                NavigationController.push(Routes.home.routePath, clean: true);
              },
            );
          }
          emit(
            ContactError(
              message:
                  'Coordenadas inválidas en uno de los centros de atención. Serás redirigido al inicio.',
            ),
          );
        } else {
          emit(ContactLoaded(contacts));
        }
      },
    );
  }
}
