import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_bloc.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_event.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_state.dart';
import 'package:fomagapp/presentation/contact/widgets/contact_chanels_widget.dart';
import 'package:fomagapp/presentation/contact/widgets/contact_list.dart';
import 'package:fomagapp/presentation/contact/widgets/contact_map.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  @override
  void initState() {
    super.initState();
    context.read<ContactBloc>().add(LoadContactData());
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldMain(
      body: BlocListener<ContactBloc, ContactState>(
        listener: (context, state) {
          if (state is ContactError) {
            InformativeModal.show(
              context: context,
              title: 'Error',
              message: state.message,
              buttonText: 'Aceptar',
              onButtonPressed: () {
                NavigationController.push(Routes.home.routePath, clean: true);
              },
            );
          }
        },
        child: BlocBuilder<ContactBloc, ContactState>(
          builder: (context, state) {
            if (state is ContactLoading) {
              return const Center(
                child: Column(
                  children: [
                    SizedBox(height: 200),
                    CircularProgressIndicator(),
                  ],
                ),
              );
            }

            if (state is ContactLoaded) {
              final contacts = state.contactList;

              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 14),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ContactChannelsWidget(),
                          SizedBox(height: 20),
                          Text(
                            'Centros de Atención al Usuario',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              fontFamily: 'NunitoSans',
                              foreground:
                                  Paint()
                                    ..style = PaintingStyle.stroke
                                    ..strokeWidth = 0.7
                                    ..color = FomagColors.neutralBlueTitle,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      height: 500,
                      width: double.infinity,
                      margin: const EdgeInsets.all(16),
                      child: ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                        ),
                        child: ContactMapWidget(contactPoints: contacts),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: ContactListWidget(contacts: contacts),
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              );
            }

            return const Center(child: Text('No se encontraron datos.'));
          },
        ),
      ),
    );
  }
}
