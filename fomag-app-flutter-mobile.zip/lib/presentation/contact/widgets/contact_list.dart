import 'package:flutter/material.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/presentation/contact/widgets/contact_card.dart';

class ContactListWidget extends StatelessWidget {
  final List<ContentResponse> contacts;
  const ContactListWidget({super.key, required this.contacts});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: contacts.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        final item = contacts[index];
        return ContactCardWidget(
          name: item.nombreCentroAtencion,
          city: item.ciudad,
          address: item.direccion,
          phone: item.telefonoContacto,
          schedule: item.horarioAtencionPublico,
        );
      },
    );
  }
}
