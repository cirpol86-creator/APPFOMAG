import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class ContactCardWidget extends StatelessWidget {
  final String city;
  final String address;
  final String phone;
  final String schedule;
  final String name;

  const ContactCardWidget({
    super.key,
    required this.city,
    required this.address,
    required this.phone,
    required this.schedule,
    required this.name,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade300),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    city,
                    style: TextStyle(
                      color: FomagColors.neutralBlueTitle,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                  Text(
                    name,
                    style: const TextStyle(
                      color: FomagColors.neutralBlueTitle,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    address,
                    style: const TextStyle(
                      color: FomagColors.black,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    phone,
                    style: const TextStyle(
                      color: FomagColors.black,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    schedule,
                    style: const TextStyle(
                      color: FomagColors.black,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 90,
              child: Align(
                alignment: Alignment.bottomRight,
                child: SvgPicture.asset(SvgManager.mapPinned),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
