double convertDmsToDecimal(String dms) {
  final regex = RegExp(
    r'''(\d+)[°:\s]+(\d+)[\'’:\s]+(\d+(?:\.\d+)?)[\"”]?\s*([NSEW])''',
  );
  final match = regex.firstMatch(dms);

  if (match == null)
    throw FormatException('Formato de coordenada inválido: $dms');

  final degrees = double.parse(match.group(1)!);
  final minutes = double.parse(match.group(2)!);
  final seconds = double.parse(match.group(3)!);
  final direction = match.group(4)!;

  double decimal = degrees + (minutes / 60) + (seconds / 3600);

  if (direction == 'S' || direction == 'W') {
    decimal *= -1;
  }

  return decimal;
}
