import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactChannelsWidget extends StatelessWidget {
  const ContactChannelsWidget({super.key});

  void _openWhatsApp() {
    final uri = Uri.parse('https://wa.me/5719170628');
    launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _openChatWeb() {
    final uri = Uri.parse(
      'https://fidu.ucontactcloud.com/WebChat/fiduprevisora/',
    );
    launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Conéctate por WhatsApp o Chat Web',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.7
                  ..color = FomagColors.neutralBlueTitle,
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'Ahora puedes comunicarte fácilmente con nosotros a través de nuestros canales digitales:',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            fontFamily: 'NunitoSans',
            color: FomagColors.black,
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'WhatsApp',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.7
                  ..color = FomagColors.neutralBlueTitle,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          children: [
            const Text(
              'Escríbenos al número ',
              style: TextStyle(
                color: FomagColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'NunitoSans',
              ),
            ),
            GestureDetector(
              onTap: _openWhatsApp,
              child: const Text(
                '+57 1 9170628',
                style: TextStyle(
                  color: FomagColors.lightBlue,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'NunitoSans',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Text(
          'Chat Web',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.7
                  ..color = FomagColors.neutralBlueTitle,
          ),
        ),
        const SizedBox(height: 5),
        GestureDetector(
          onTap: _openChatWeb,
          child: const Text(
            'Ingresa aquí para atención directa',
            style: TextStyle(
              color: Colors.lightBlue,
              fontSize: 16,
              fontWeight: FontWeight.w600,
              fontFamily: 'NunitoSans',
            ),
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'Le invitamos a hacer uso de este servicio para mantener su información al día.',
          style: TextStyle(
            color: FomagColors.black,
            fontSize: 16,
            fontWeight: FontWeight.w600,
            fontFamily: 'NunitoSans',
          ),
        ),
      ],
    );
  }
}
