import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';

class ContactMapWidget extends StatefulWidget {
  final List<ContentResponse> contactPoints;

  const ContactMapWidget({super.key, required this.contactPoints});

  @override
  State<ContactMapWidget> createState() => _ContactMapWidgetState();
}

class _ContactMapWidgetState extends State<ContactMapWidget> {
  ContentResponse? _selectedContact;
  Set<Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    _tryBuildMarkers();
  }

  void _tryBuildMarkers() {
    try {
      _markers =
          widget.contactPoints.map((contact) {
            return Marker(
              markerId: MarkerId(
                '${contact.nombreCentroAtencion}-${contact.ciudad}',
              ),
              position: LatLng(contact.latitud, contact.longitud),
              onTap: () {
                setState(() {
                  _selectedContact = contact;
                });
              },
            );
          }).toSet();
    } catch (e) {
      _showInvalidCoordinatesModal();
    }
  }

  void _showInvalidCoordinatesModal() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      InformativeModal.show(
        context: context,
        title: 'Error',
        message:
            'Coordenadas inválidas en uno de los centros de atención. Serás redirigido al inicio.',
        buttonText: 'Aceptar',
        onButtonPressed: () {
          NavigationController.push(Routes.home.routePath, clean: true);
        },
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(
          initialCameraPosition: const CameraPosition(
            target: LatLng(4.5709, -74.2973),
            zoom: 5.2,
          ),
          markers: _markers,
          zoomControlsEnabled: false,
          myLocationButtonEnabled: false,
          gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
            Factory<OneSequenceGestureRecognizer>(
              () => EagerGestureRecognizer(),
            ),
          },
        ),
        if (_selectedContact != null)
          Positioned(
            left: 16,
            right: 16,
            top: 80,
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Text(
                            _selectedContact!.ciudad,
                            style: const TextStyle(
                              color: FomagColors.neutralBlueTitle,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'NunitoSans',
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            setState(() => _selectedContact = null);
                          },
                        ),
                      ],
                    ),
                    Text(
                      _selectedContact!.horarioAtencionPublico,
                      style: const TextStyle(
                        color: FomagColors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'NunitoSans',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
