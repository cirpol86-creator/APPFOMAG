part of 'list_news_page.dart';

mixin NewsWidgetMixin<T extends StatefulWidget> on State<T> {
  List<NewsContent>? newsList;
  bool isLoading = true;
  List<CarouselCardData>? carouselItems;
  String? errorMessage;

  void setNewsList(List<NewsContent>? value) {
    setState(() {
      newsList = value;
    });
  }

  void setIsLoading(bool value) {
    setState(() {
      isLoading = value;
    });
  }

  void setCarouselItems(List<CarouselCardData>? value) {
    setState(() {
      carouselItems = value;
    });
  }

  void setErrorMessage(String? value) {
    setState(() {
      errorMessage = value;
    });
  }

  void newsSuccess(NewsSuccess state) {
    final newsList = state.response.content;
    final length = newsList.length;
    final moreNews = length >= 3;
    final itemsToShowCarousel = moreNews ? 3 : length;
    final carouselItems = CarouselCardData.getCarouselCardDataByNewsContent(
      newsList.sublist(0, itemsToShowCarousel),
    );

    if (moreNews) {
      setNewsList(newsList.sublist(3));
    }

    setCarouselItems(carouselItems);
    setIsLoading(false);
  }

  void newsFailure(NewsFailure state) {
    setErrorMessage(state.message);
    setIsLoading(false);
  }

  void onRetry() {
    setErrorMessage(null);
    initializeContent();
  }

  void initializeContent() async {
    context.read<HomeBloc>().add(NewsSubmitted());
  }

  void newsLoading(NewsLoading state) {
    setIsLoading(true);
  }
}
