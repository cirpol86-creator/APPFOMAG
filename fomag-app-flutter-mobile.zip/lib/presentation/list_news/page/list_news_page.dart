import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:fomagapp/data/model/image_carousel_model.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/presentation/home/bloc/home_bloc.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/cards/card_new.dart';
import 'package:fomagapp/presentation/widgets/copyright_widget.dart';
import 'package:fomagapp/presentation/widgets/image_carousel_card.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';
import 'package:skeletonizer/skeletonizer.dart';

part 'list_news_mixin.dart';

class ListNewsPage extends StatefulWidget {
  const ListNewsPage({super.key});

  @override
  State<ListNewsPage> createState() => _ListNewsPageState();
}

class _ListNewsPageState extends State<ListNewsPage> with NewsWidgetMixin {
  @override
  void initState() {
    super.initState();
    initializeContent();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<HomeBloc, HomeState>(
      listener: (context, state) {
        if (state is NewsLoading) newsLoading(state);
        if (state is NewsSuccess) newsSuccess(state);
        if (state is NewsFailure) newsFailure(state);
      },
      child: ScaffoldMain(
        errorMessage: errorMessage,
        onRetry: onRetry,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Skeletonizer(
              enabled: isLoading,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ImageCarouselCard(items: carouselItems ?? []),
                    const SizedBox(height: 16),
                    if (newsList == null || newsList?.isEmpty == true)
                      Skeleton.leaf(
                        child: Container(
                          height: 136,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: FomagColors.grayLight,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Skeleton.ignore(child: SvgManager.happyFace),
                              const SizedBox(height: 8),
                              Text(
                                'No hay novedades',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  color: FomagColors.black,
                                  fontFamily: 'NunitoSans',
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      ...List.generate(newsList?.length ?? 0, (index) {
                        final news = newsList?[index] ?? NewsContent();
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: CardNew(
                            title: news.title,
                            imageUrl: news.imageBanner,
                            category: news.body,
                            date: news.date,
                            onTap: () {
                              NavigationController.push(
                                Routes.newInfo.routePath,
                                arguments: news.id,
                              );
                            },
                          ),
                        );
                      }),
                    const SizedBox(height: 16),
                    CopyrightWidget(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
