import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/presentation/password_reset/bloc/password_reset_bloc.dart';
import 'package:fomagapp/presentation/password_reset/widgets/code_sent_step.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';

class PasswordHomeResetPage extends StatefulWidget {
  const PasswordHomeResetPage({super.key});

  @override
  State<PasswordHomeResetPage> createState() => _PasswordHomeResetPageState();
}

class _PasswordHomeResetPageState extends State<PasswordHomeResetPage> {
  final _formKeyPasswordInputStep = GlobalKey<FormState>();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  late String _documentNumberStorage = '';
  late String _typeDocumentStorage = '';
  bool dataDocumentEmpty = true;
  bool isLoading = false;
  String? _messageToSendCode;
  String? _messageError;

  Ticker? _ticker;
  int _remainingSeconds = 180;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadDocument();
      _trackerEvent();
    });
  }

  @override
  void dispose() {
    _ticker?.dispose();
    _codeController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _loadDocument() async {
    final jwtUser = await SecureStorageManager.decodeJwtUser();

    setState(() {
      _documentNumberStorage = jwtUser!.documentNumber!;
      _typeDocumentStorage = jwtUser.documentTypeId!;
      dataDocumentEmpty = false;
    });

    log(
      'Document Number: $_documentNumberStorage, Type Document: $_typeDocumentStorage',
    );
    _passwordResetHome();
  }

  void _startTimer() {
    _remainingSeconds = 180;

    _ticker?.dispose();

    _ticker = Ticker((elapsed) {
      setState(() {
        _remainingSeconds = 180 - elapsed.inSeconds;
        if (_remainingSeconds <= 0) {
          InformativeModal.show(
            context: context,
            title: 'El Código ha expirado, por favor solicite uno nuevo.',
            buttonText: 'Continuar',
            iconColor: FomagColors.blue450,
            buttonColor: FomagColors.buttonPrincipal,
            dismissible: false,
            onButtonPressed: () {
              NavigationController.pop();
              NavigationController.pop();
            },
          );
          _ticker?.dispose();
        }
      });
    })..start();
  }

  void _setMessageError(String? value) {
    setState(() {
      _messageError = value;
    });
  }

  void _setIsLoading(bool? value) {
    setState(() {
      isLoading = value ?? false;
    });
  }

  void _setMessageToSendCode(String? value) {
    setState(() {
      _messageToSendCode = value;
    });
  }

  void _onSendCodeSuccess(SendCodeSuccess state) {
    _setMessageToSendCode(state.message);
    setState(() {
      _startTimer();
    });
  }

  void _onSendCodeFailure(SendCodeFailure state) {
    _setMessageError(state.message);
  }

  void _changePasswordSuccess(ChangePasswordSuccess state) {
    InformativeModal.show(
      context: context,
      title: 'Su contraseña ha sido actualizada exitosamente.',
      buttonText: 'Continuar',
      onButtonPressed: () {
        NavigationController.push(Routes.login.routePath, clean: true);
      },
      topIcon: Icons.check_circle_outline_rounded,
      iconColor: FomagColors.greenButton,
    );
  }

  void _changePasswordFailure(ChangePasswordFailure state) {
    _setMessageError(state.message);
  }

  void _passwordResetHome() {
    setState(() {
      _startTimer();
    });
    FocusScope.of(context).unfocus();
    _setMessageError(null);

    if (dataDocumentEmpty == false) {
      context.read<PasswordResetBloc>().add(
        SendCodeSubmitted(
          request: EmailCodeRequest(
            typeDocument: _typeDocumentStorage,
            documentNumber: _documentNumberStorage,
          ),
        ),
      );
    }
  }

  void _codeSentHome() {
    FocusScope.of(context).unfocus();

    final isFormValid = _formKeyPasswordInputStep.currentState!.validate();

    if (!isFormValid || _messageError != null) return;

    final request = ConfirmForgotPasswordRequest(
      code: _codeController.text,
      documentType: _typeDocumentStorage,
      documentNumber: _documentNumberStorage,
      password: _passwordController.text,
    );

    context.read<PasswordResetBloc>().add(
      OtpCodePasswordSubmitted(request: request),
    );
  }

  void _trackerEvent() {
    context.read<PasswordResetBloc>().add(TrackerEvent());
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<PasswordResetBloc, PasswordResetState>(
      listener: (context, state) {
        if (state is PasswordResetLoading) _setIsLoading(true);
        if (state is! PasswordResetLoading) _setIsLoading(false);
        if (state is SendCodeSuccess) _onSendCodeSuccess(state);
        if (state is SendCodeFailure) _onSendCodeFailure(state);
        if (state is ChangePasswordSuccess) _changePasswordSuccess(state);
        if (state is ChangePasswordFailure) _changePasswordFailure(state);
      },
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: ScaffoldSimple(
          body: CodeSentStep(
            formKey: _formKeyPasswordInputStep,
            onSubmit: _codeSentHome,
            message: _messageToSendCode,
            errorMessage: _messageError,
            codeController: _codeController,
            passwordController: _passwordController,
            confirmPasswordController: _confirmPasswordController,
            setErrorMessage: _setMessageError,
            remainingSeconds: _remainingSeconds,
          ),
        ),
      ),
    );
  }
}
