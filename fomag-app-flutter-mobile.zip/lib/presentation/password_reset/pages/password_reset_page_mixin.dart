part of 'password_reset_page.dart';

enum PasswordResetStep { form, codeSent }

mixin PasswordResetPageMixin<T extends StatefulWidget> on State<T> {
  final _formKeyFormStep = GlobalKey<FormState>();
  final _formKeyPasswordInputStep = GlobalKey<FormState>();

  final TextEditingController _documentNumberController =
      TextEditingController();
  final TextEditingController _typeDocumentController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool isLoading = false;
  PasswordResetStep _step = PasswordResetStep.form;
  String? _messageToSendCode;
  String? _messageError;

  Ticker? _ticker;
  int _remainingSeconds = 180;

  void _startTimer() {
    _remainingSeconds = 180;

    _ticker?.dispose();

    _ticker = Ticker((elapsed) {
      setState(() {
        _remainingSeconds = 180 - elapsed.inSeconds;
        if (_remainingSeconds <= 0) {
          InformativeModal.show(
            context: context,
            title: 'El Código ha expirado, por favor solicite uno nuevo.',
            buttonText: 'Continuar',
            iconColor: FomagColors.blue450,
            buttonColor: FomagColors.buttonPrincipal,
            dismissible: false,
            onButtonPressed: () {
              NavigationController.pop();
              _navigateToForm();
            },
          );
          _ticker?.dispose();
        }
      });
    })..start();
  }

  void _setMessageError(String? value) {
    setState(() {
      _messageError = value;
    });
  }

  void _setIsLoading(bool? value) {
    setState(() {
      isLoading = value ?? false;
    });
  }

  void _setMessageToSendCode(String? value) {
    setState(() {
      _messageToSendCode = value;
    });
  }

  void _navigateToCodeSent() {
    setState(() {
      _step = PasswordResetStep.codeSent;
    });
  }

  void _navigateToForm() {
    setState(() {
      _step = PasswordResetStep.form;
    });
  }

  void _onSendCodeSuccess(SendCodeSuccess state) {
    _setMessageToSendCode(state.message);
    _navigateToCodeSent();
    setState(() {
      _startTimer();
    });
  }

  void _onSendCodeFailure(SendCodeFailure state) {
    _setMessageError(state.message);
  }

  void _changePasswordSuccess(ChangePasswordSuccess state) {
    InformativeModal.show(
      context: context,
      title: 'Su contraseña ha sido actualizada exitosamente.',
      buttonText: 'Continuar',
      onButtonPressed: () {
        NavigationController.pop();
        NavigationController.pop();
      },
      topIcon: Icons.check_circle_outline_rounded,
      iconColor: FomagColors.greenButton,
    );
  }

  void _changePasswordFailure(ChangePasswordFailure state) {
    _navigateToCodeSent();
    _setMessageError(state.message);
  }

  void _passwordReset() {
    FocusScope.of(context).unfocus();
    _setMessageError(null);

    final isFormValid = _formKeyFormStep.currentState!.validate();
    final typeDoc = _typeDocumentController.text.trim();
    final docNum = _documentNumberController.text.trim();

    if (isFormValid && typeDoc.isNotEmpty && docNum.isNotEmpty) {
      context.read<PasswordResetBloc>().add(
        SendCodeSubmitted(
          request: EmailCodeRequest(
            typeDocument: TypesDocuments.getByName(typeDoc)?.id ?? '',
            documentNumber: docNum,
          ),
        ),
      );
    }
  }

  void _codeSent() {
    FocusScope.of(context).unfocus();

    final isFormValid = _formKeyPasswordInputStep.currentState!.validate();

    if (!isFormValid || _messageError != null) return;

    final request = ConfirmForgotPasswordRequest(
      code: _codeController.text,
      documentType:
          TypesDocuments.getByName(_typeDocumentController.text)?.id ?? '',
      documentNumber: _documentNumberController.text,
      password: _passwordController.text,
    );

    context.read<PasswordResetBloc>().add(
      OtpCodePasswordSubmitted(request: request),
    );
  }

  void _trackerEvent() {
    context.read<PasswordResetBloc>().add(TrackerEvent());
  }

  Widget formStep() => FormStep(
    formKey: _formKeyFormStep,
    typeDocumentController: _typeDocumentController,
    documentNumberController: _documentNumberController,
    onSubmit: _passwordReset,
    messageError: _messageError,
  );

  Widget codeSentStep() {
    return CodeSentStep(
      formKey: _formKeyPasswordInputStep,
      onSubmit: _codeSent,
      message: _messageToSendCode,
      errorMessage: _messageError,
      codeController: _codeController,
      passwordController: _passwordController,
      confirmPasswordController: _confirmPasswordController,
      setErrorMessage: _setMessageError,
      remainingSeconds: _remainingSeconds,
    );
  }

  @override
  void dispose() {
    _documentNumberController.dispose();
    _typeDocumentController.dispose();
    _codeController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _ticker?.dispose(); // ← Solo si está inicializado
    super.dispose();
  }
}
