import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/types_documents.dart';
import 'package:fomagapp/presentation/password_reset/bloc/password_reset_bloc.dart';
import 'package:fomagapp/presentation/password_reset/widgets/code_sent_step.dart';
import 'package:fomagapp/presentation/password_reset/widgets/form_step.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';

part 'password_reset_page_mixin.dart';

class PasswordResetPage extends StatefulWidget {
  const PasswordResetPage({super.key});

  @override
  State<PasswordResetPage> createState() => _PasswordResetPageState();
}

class _PasswordResetPageState extends State<PasswordResetPage>
    with PasswordResetPageMixin {
  @override
  void initState() {
    super.initState();
    _trackerEvent();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<PasswordResetBloc, PasswordResetState>(
      listener: (context, state) {
        if (state is PasswordResetLoading) _setIsLoading(true);
        if (state is! PasswordResetLoading) _setIsLoading(false);
        if (state is SendCodeSuccess) _onSendCodeSuccess(state);
        if (state is SendCodeFailure) _onSendCodeFailure(state);
        if (state is ChangePasswordSuccess) _changePasswordSuccess(state);
        if (state is ChangePasswordFailure) _changePasswordFailure(state);
      },
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: ScaffoldSimple(
          isLoading: isLoading,
          body: switch (_step) {
            PasswordResetStep.form => formStep(),
            PasswordResetStep.codeSent => codeSentStep(),
          },
        ),
      ),
    );
  }
}
