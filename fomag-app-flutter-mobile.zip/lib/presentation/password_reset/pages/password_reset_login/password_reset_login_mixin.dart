part of 'password_reset_login.dart';

class PasswordResetLoginPageParams {
  final String userName;
  final String session;
  final String challengeType;
  final String message;

  const PasswordResetLoginPageParams({
    required this.userName,
    required this.session,
    required this.challengeType,
    required this.message,
  });
}

mixin PasswordResetLoginMixin on State<PasswordResetLoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  bool isLoading = false;
  String? _messageError;

  Ticker? _ticker;
  int _remainingSeconds = 180;
  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _ticker?.dispose();
    _codeController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _startTimer() {
    _remainingSeconds = 180;

    _ticker?.dispose();

    _ticker = Ticker((elapsed) {
      setState(() {
        _remainingSeconds = 180 - elapsed.inSeconds;
        if (_remainingSeconds <= 0) {
          InformativeModal.show(
            context: context,
            title: 'El Código ha expirado, por favor solicite uno nuevo.',
            buttonText: 'Continuar',
            iconColor: FomagColors.blue450,
            buttonColor: FomagColors.buttonPrincipal,
            dismissible: false,
            onButtonPressed: () {
              NavigationController.pop();
              NavigationController.pop();
            },
          );
          _ticker?.dispose();
        }
      });
    })..start();
  }

  void _setMessageError(String? value) {
    setState(() {
      _messageError = value;
    });
  }

  void _setIsLoading(bool? value) {
    setState(() {
      isLoading = value ?? false;
    });
  }

  void _changePasswordSuccess(OtpVerificationSuccess state) {
    SecureStorageManager.setAccessToken(state.response.accessToken);
    SecureStorageManager.setRefreshToken(state.response.refreshToken);
    SecureStorageManager.setIdToken(state.response.idToken);

    InformativeModal.show(
      context: context,
      title: 'Su contraseña ha sido actualizada exitosamente.',
      buttonText: 'Continuar',
      onButtonPressed: () {
        NavigationController.push(Routes.home.routePath, clean: true);
      },
      topIcon: Icons.check_circle_outline_rounded,
      iconColor: FomagColors.greenButton,
    );
  }

  void _changePasswordFailure(OtpVerificationFailure state) {
    _setMessageError(state.message);
  }

  void _codeSentHome() {
    FocusScope.of(context).unfocus();

    final isFormValid = _formKey.currentState!.validate();

    if (!isFormValid || _messageError != null) return;

    final request = OtpValidateRequest(
      code: _codeController.text,
      userName: widget.params.userName,
      session: widget.params.session,
      challengeType: widget.params.challengeType,
      newPassword: _passwordController.text,
    );

    context.read<OtpVerificationBloc>().add(
      OtpVerificationSubmitted(request: request),
    );
  }
}
