import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/presentation/otp_verification/bloc/otp_verification_bloc.dart';
import 'package:fomagapp/presentation/password_reset/widgets/code_sent_step.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';

part 'password_reset_login_mixin.dart';

class PasswordResetLoginPage extends StatefulWidget {
  const PasswordResetLoginPage({super.key, required this.params});

  final PasswordResetLoginPageParams params;

  @override
  State<PasswordResetLoginPage> createState() => _PasswordResetLoginPageState();
}

class _PasswordResetLoginPageState extends State<PasswordResetLoginPage>
    with PasswordResetLoginMixin {
  @override
  Widget build(BuildContext context) {
    return BlocListener<OtpVerificationBloc, OtpVerificationState>(
      listener: (context, state) {
        if (state is OtpVerificationLoading) _setIsLoading(true);
        if (state is! OtpVerificationLoading) _setIsLoading(false);
        if (state is OtpVerificationSuccess) _changePasswordSuccess(state);
        if (state is OtpVerificationFailure) _changePasswordFailure(state);
      },
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: ScaffoldSimple(
          isLoading: isLoading,
          body: CodeSentStep(
            formKey: _formKey,
            onSubmit: _codeSentHome,
            message: widget.params.message,
            errorMessage: _messageError,
            codeController: _codeController,
            passwordController: _passwordController,
            confirmPasswordController: _confirmPasswordController,
            setErrorMessage: _setMessageError,
            remainingSeconds: _remainingSeconds,
          ),
        ),
      ),
    );
  }
}
