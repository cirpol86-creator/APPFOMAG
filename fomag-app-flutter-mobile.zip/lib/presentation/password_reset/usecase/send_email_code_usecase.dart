import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:fomagapp/data/repositories/send_email_code_repository.dart';

class SendCodeUseCase {
  final SendEmailCodeRepository _sendEmailCode;

  SendCodeUseCase({required SendEmailCodeRepository sendEmailCode})
    : _sendEmailCode = sendEmailCode;

  Future<Either<Failure<DioExceptionType>, ForgotPasswordResponse>> call(
    EmailCodeRequest sendEmailCodeRequest,
  ) async {
    return _sendEmailCode.sendEmailCode(sendEmailCodeRequest);
  }
}
