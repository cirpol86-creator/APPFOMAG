import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:fomagapp/data/repositories/confirm_forgot_password_repository.dart';

class ChangePasswordUseCase {
  final ConfirmForgotPasswordRepository _repository;

  ChangePasswordUseCase({required ConfirmForgotPasswordRepository repository})
    : _repository = repository;

  Future<Either<Failure<DioExceptionType>, ConfirmForgotPasswordResponse>> call(
    ConfirmForgotPasswordRequest request,
  ) async {
    return _repository.confirmForgotPassword(request);
  }
}
