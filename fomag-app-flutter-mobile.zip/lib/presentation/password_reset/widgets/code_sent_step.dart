import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_text.dart';
import 'package:pinput/pinput.dart';
import 'package:url_launcher/url_launcher.dart';

typedef SetErrorMessage = void Function(String?);

class CodeSentStep extends StatelessWidget {
  const CodeSentStep({
    super.key,
    required this.onSubmit,
    required this.errorMessage,
    required this.formKey,
    required this.codeController,
    required this.passwordController,
    required this.confirmPasswordController,
    required this.setErrorMessage,
    required this.message,
    required this.remainingSeconds,
  });

  final VoidCallback onSubmit;
  final String? errorMessage;
  final GlobalKey<FormState> formKey;
  final TextEditingController codeController;
  final TextEditingController passwordController;
  final TextEditingController confirmPasswordController;
  final SetErrorMessage setErrorMessage;
  final String? message;
  final int remainingSeconds;

  String? isValidOtp(String? value, SetErrorMessage setErrorMessage) {
    if (value == null || value.isEmpty) {
      setErrorMessage('Por favor ingrese el código');
    } else if (value.length != 6) {
      setErrorMessage('El código debe tener 6 dígitos');
    }

    return null;
  }

  void onChanged(String? value, SetErrorMessage setErrorMessage) {
    if (value == null || value.isEmpty) return;

    if (value.length != 6) return;

    setErrorMessage(null);
  }

  String? _validatePassword(String? value) {
    if (value == null || value.trim().isEmpty) return 'Ingrese su contraseña.';

    final passwordRegExp = RegExp(
      r'^(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};:"\\|,.<>\/?]).{8,15}$',
    );

    if (!passwordRegExp.hasMatch(value.trim())) {
      return 'La contraseña no cumple los requisitos de seguridad.';
    }

    return null;
  }

  String? _validarConfirmPassword(String? value) {
    if (value == null || value.trim().isEmpty) return 'Confirme su contraseña.';

    if (value.trim() != passwordController.text.trim()) {
      return 'Las contraseñas no coinciden.';
    }

    return null;
  }

  final List<String> requirements = const [
    '8 caracteres.',
    'Una mayúscula.',
    'Una minúscula.',
    'Un número.',
    'Un carácter especial (@, #, \$).',
    'Sin espacios',
  ];

  @override
  Widget build(BuildContext context) {
    final minutes = (remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (remainingSeconds % 60).toString().padLeft(2, '0');
    return Form(
      key: formKey,
      child: Column(
        children: [
          Text(
            'Cambiar contraseña',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w600,
              fontFamily: 'NunitoSans',
              foreground:
                  Paint()
                    ..style = PaintingStyle.stroke
                    ..strokeWidth = 0.7
                    ..color = FomagColors.neutralBlueTitle,
            ),
          ),
          if (message != null) ...[
            SizedBox(height: 40),
            Text(
              message!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: FomagColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                fontFamily: 'NunitoSans',
              ),
            ),
          ],
          SizedBox(height: 24),
          Text(
            'Inserte el código enviado:',
            style: TextStyle(
              color: FomagColors.black,
              fontSize: 16,
              fontFamily: 'NunitoSans',
            ),
          ),
          SizedBox(height: 12),
          Pinput(
            controller: codeController,
            length: 6,
            defaultPinTheme: PinTheme(
              height: 56,
              width: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: FomagColors.backgroundInputOtp,
              ),
              textStyle: TextStyle(
                color: FomagColors.neutralBlueTitle,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'NunitoSans',
              ),
            ),
            errorPinTheme: PinTheme(
              height: 56,
              width: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: FomagColors.backgroundInputOtp,
                border: Border.all(color: FomagColors.errorOtp, width: 1.5),
              ),
              textStyle: TextStyle(
                color: FomagColors.neutralBlueTitle,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'NunitoSans',
              ),
            ),
            validator: (value) => isValidOtp(value, setErrorMessage),
            forceErrorState: errorMessage != null,
            errorBuilder: (error, value) {
              return error != null
                  ? Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(
                        error,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: FomagColors.errorOtp,
                          fontSize: 16,
                          fontFamily: 'NunitoSans',
                        ),
                      ),
                    ),
                  )
                  : SizedBox();
            },
            onChanged: (value) => onChanged(value, setErrorMessage),
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            keyboardType: TextInputType.number,
          ),
          if (errorMessage != null) ...[
            Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(
                  errorMessage!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: FomagColors.errorOtp,
                    fontSize: 16,
                    fontFamily: 'NunitoSans',
                  ),
                ),
              ),
            ),
          ],
          SizedBox(height: 20),
          Text(
            '$minutes:$seconds',
            style: const TextStyle(
              color: FomagColors.neutralBlueTitle,
              fontWeight: FontWeight.w700,
              fontSize: 16,
              fontFamily: 'NunitoSans',
            ),
          ),
          SizedBox(height: 20),
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              style: const TextStyle(
                fontSize: 16,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
              children: [
                const TextSpan(
                  text:
                      '¿Tiene problemas con el correo?\nCree una PQR haciendo clic ',
                ),
                TextSpan(
                  text: 'aquí',
                  style: const TextStyle(
                    color: FomagColors.neutralBlueTitle,
                    decoration: TextDecoration.underline,
                  ),
                  recognizer:
                      TapGestureRecognizer()
                        ..onTap = () async {
                          final Uri url = Uri.parse(
                            'https://fiduprevisorafidugestorpqrsd.digitalwaresaas.com.co:8082/DMSWebFormExit/#/index',
                          );
                          if (await canLaunchUrl(url)) {
                            await launchUrl(
                              url,
                              mode: LaunchMode.externalApplication,
                            );
                          } else {
                            debugPrint('No se pudo abrir el enlace');
                          }
                        },
                ),
                const TextSpan(text: ' para resolver su inconveniente.'),
              ],
            ),
          ),
          const SizedBox(height: 24),
          RoundedEntry(
            controller: passwordController,
            hintText: 'Nueva contraseña',
            label: 'Nueva contraseña',
            validator: _validatePassword,
            isPassword: true,
            inputFormatters: [FilteringTextInputFormatter.deny(RegExp(r'\s'))],
          ),
          const SizedBox(height: 16),
          RoundedEntry(
            controller: confirmPasswordController,
            hintText: 'Confirmar nueva contraseña',
            label: 'Confirmar nueva contraseña',
            validator: _validarConfirmPassword,
            isPassword: true,
            inputFormatters: [FilteringTextInputFormatter.deny(RegExp(r'\s'))],
          ),
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerLeft,
            child: const Text(
              'La contraseña debe tener:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
                color: FomagColors.black,
                fontFamily: 'NunitoSans',
              ),
            ),
          ),
          const SizedBox(height: 8),
          ...requirements.map(
            (req) => Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '• ',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: FomagColors.black,
                    fontFamily: 'NunitoSans',
                  ),
                ),
                Expanded(
                  child: Text(
                    req,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 40),
          PrimaryButton(text: 'Cambiar contraseña', onPressed: onSubmit),
        ],
      ),
    );
  }
}
