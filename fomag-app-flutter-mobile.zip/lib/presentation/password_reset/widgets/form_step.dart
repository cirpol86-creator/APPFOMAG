import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:fomagapp/data/model/types_documents.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/error_text.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_picker.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_text.dart';

class FormStep extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController typeDocumentController;
  final TextEditingController documentNumberController;
  final VoidCallback onSubmit;
  final String? messageError;

  const FormStep({
    super.key,
    required this.formKey,
    required this.typeDocumentController,
    required this.documentNumberController,
    required this.onSubmit,
    required this.messageError,
  });

  @override
  State<FormStep> createState() => _FormStepState();
}

class _FormStepState extends State<FormStep> {
  final List<TypesDocuments> _typesDocumentNumber =
      TypesDocuments.typesDocuments;

  String? _isValidDocument(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Ingrese su número de documento';
    }

    return null;
  }

  void _onChangeTypeDocument(String? value) {
    setState(() {
      widget.typeDocumentController.text = value ?? '';
    });
  }

  String? _validateTypeDocument(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Seleccione un tipo de documento';
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    final List<String> options =
        _typesDocumentNumber.map((value) => value.name).toList();

    return Form(
      key: widget.formKey,
      child: Column(
        children: [
          const SizedBox(height: 32),
          Text(
            'Cambiar contraseña',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,

              foreground:
                  Paint()
                    ..style = PaintingStyle.stroke
                    ..strokeWidth = 0.8
                    ..color = FomagColors.neutralBlueTitle,
            ),
          ),
          const SizedBox(height: 48),
          RoundedPicker(
            label: 'Tipo de Documento',
            hintText: 'Tipo de Documento',
            options: options,
            selectedValue:
                widget.typeDocumentController.text.isNotEmpty &&
                        options.contains(widget.typeDocumentController.text)
                    ? widget.typeDocumentController.text
                    : null,
            onChanged: _onChangeTypeDocument,
            validator: _validateTypeDocument,
          ),
          const SizedBox(height: 16),
          RoundedEntry(
            controller: widget.documentNumberController,
            hintText: 'Número de Documento',
            label: 'Número de Documento',
            keyboardType: TextInputType.text,
            validator: _isValidDocument,
          ),
          if (widget.messageError != null) ...[
            ErrorText(message: widget.messageError!),
          ],
          const SizedBox(height: 32),
          PrimaryButton(
            text: 'Cambiar contraseña',
            onPressed: widget.onSubmit,
            enabled: true,
          ),
        ],
      ),
    );
  }
}
