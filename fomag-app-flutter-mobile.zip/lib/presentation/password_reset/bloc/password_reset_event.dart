part of 'password_reset_bloc.dart';

abstract class PasswordResetEvent {}

class SendCodeSubmitted extends PasswordResetEvent {
  final EmailCodeRequest request;

  SendCodeSubmitted({required this.request});
}

class OtpCodePasswordSubmitted extends PasswordResetEvent {
  final ConfirmForgotPasswordRequest request;

  OtpCodePasswordSubmitted({required this.request});
}

class ChangePasswordSubmitted extends PasswordResetEvent {
  final NewPasswordRequest request;

  ChangePasswordSubmitted({required this.request});
}

class TrackerEvent extends PasswordResetEvent {}
