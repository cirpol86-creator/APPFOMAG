part of 'password_reset_bloc.dart';

abstract class PasswordResetState extends Equatable {
  @override
  List<Object?> get props => [];
}

class PasswordResetLoading extends PasswordResetState {}

class SendCodeSuccess extends PasswordResetState {
  final String message;
  SendCodeSuccess({required this.message});

  @override
  List<Object?> get props => [message];
}

class SendCodeFailure extends PasswordResetState {
  final String message;
  SendCodeFailure({required this.message});

  @override
  List<Object?> get props => [message];
}

class ChangePasswordSuccess extends PasswordResetState {
  final String message;
  ChangePasswordSuccess({required this.message});

  @override
  List<Object?> get props => [message];
}

class ChangePasswordFailure extends PasswordResetState {
  final String message;
  ChangePasswordFailure({required this.message});

  @override
  List<Object?> get props => [message];
}
