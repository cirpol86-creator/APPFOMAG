import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/request/new_password/new_password_request.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/password_reset/usecase/change_password_usecase.dart';
import 'package:fomagapp/presentation/password_reset/usecase/send_email_code_usecase.dart';

part 'password_reset_event.dart';
part 'password_reset_state.dart';

class PasswordResetBloc extends Bloc<PasswordResetEvent, PasswordResetState> {
  final SendCodeUseCase _sendCodeUseCase;
  final ChangePasswordUseCase _changePasswordUseCase;
  final TrackUserEventUseCase _trackUserEventUseCase;

  PasswordResetBloc({
    required SendCodeUseCase sendCodeUseCase,
    required ChangePasswordUseCase changePasswordUseCase,
    required TrackUserEventUseCase trackUserEventUseCase,
  }) : _sendCodeUseCase = sendCodeUseCase,
       _changePasswordUseCase = changePasswordUseCase,
       _trackUserEventUseCase = trackUserEventUseCase,
       super(PasswordResetLoading()) {
    on<SendCodeSubmitted>(_onSendCode);
    on<OtpCodePasswordSubmitted>(_onChangePassword);
    on<TrackerEvent>(_onTrackerEvent);
  }

  Future<void> _onSendCode(
    SendCodeSubmitted event,
    Emitter<PasswordResetState> emit,
  ) async {
    emit(PasswordResetLoading());

    final result = await _sendCodeUseCase(event.request);

    result.fold(
      (failure) {
        emit(SendCodeFailure(message: mapFailureToMessage(failure)));
      },
      (response) {
        emit(SendCodeSuccess(message: response.message));
      },
    );
  }

  Future<void> _onChangePassword(
    OtpCodePasswordSubmitted event,
    Emitter<PasswordResetState> emit,
  ) async {
    emit(PasswordResetLoading());

    final result = await _changePasswordUseCase(event.request);

    result.fold(
      (failure) {
        emit(ChangePasswordFailure(message: mapFailureToMessage(failure)));
      },
      (response) {
        emit(ChangePasswordSuccess(message: response.message));
      },
    );
  }

  void _onTrackerEvent(TrackerEvent event, Emitter<PasswordResetState> emit) {
    _trackUserEventUseCase.call(
      UserEventModel(UserEventType.passwordReset, {
        'screen_name': 'AccountPage',
      }),
    );
  }
}
