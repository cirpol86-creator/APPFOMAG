import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

class SurveyPage extends StatefulWidget {
  const SurveyPage({super.key});

  @override
  State<SurveyPage> createState() => _SurveyPageState();
}

class _SurveyPageState extends State<SurveyPage> {
  int selectedOption = 2;
  final List<String> options = [
    'Opción #1',
    'Opción #2',
    'Opción #3',
    'Opción #4',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            const Text(
              'Vamos a comenzar...',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: FomagColors.black,
                fontFamily: 'NunitoSans',
              ),
            ),
            const SizedBox(height: 12),
            // Progress bar
            Row(
              children: [
                Expanded(
                  flex: 1,
                  child: Container(
                    height: 6,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2196F3),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Container(
                    height: 6,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text(
              'Pregunta de la encuesta',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: FomagColors.black,
                fontFamily: 'NunitoSans',
              ),
            ),
            const SizedBox(height: 16),
            // Opciones
            ...List.generate(options.length, (index) {
              final isSelected = selectedOption == index;
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedOption = index;
                    });
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      vertical: 16,
                      horizontal: 16,
                    ),
                    decoration: BoxDecoration(
                      color:
                          isSelected ? const Color(0xFF4CAF50) : Colors.white,
                      border: Border.all(
                        color:
                            isSelected
                                ? const Color(0xFF4CAF50)
                                : Colors.grey.shade400,
                        width: 1.5,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          options[index],
                          style: TextStyle(
                            color:
                                isSelected
                                    ? FomagColors.white
                                    : FomagColors.black,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            fontFamily: 'NunitoSans',
                          ),
                        ),
                        if (isSelected)
                          const Icon(Icons.check_circle, color: Colors.white),
                      ],
                    ),
                  ),
                ),
              );
            }),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.arrow_back, color: FomagColors.black),
                  label: const Text(
                    'Anterior',
                    style: TextStyle(
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.grey.shade400),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Text(
                    'Siguiente',
                    style: TextStyle(
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                  label: const Icon(
                    Icons.arrow_forward,
                    color: FomagColors.black,
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.grey.shade400),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
