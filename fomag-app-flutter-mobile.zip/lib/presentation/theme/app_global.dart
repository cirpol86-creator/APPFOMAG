import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

RouteObserver<ModalRoute<void>> navigationObserver =
    RouteObserver<ModalRoute<void>>();

ThemeData themeData = ThemeData(
  useMaterial3: false,
  primaryColor: FomagColors.darkBlue,
  scaffoldBackgroundColor: FomagColors.white,
  fontFamily: 'NunitoSans', // Fuente personalizada
  brightness: Brightness.light,
  pageTransitionsTheme: _buildPageTransitionsTheme(),
  appBarTheme: AppBarTheme(
    backgroundColor: FomagColors.primaryColor,
    titleTextStyle: TextStyle(
      fontFamily: 'NunitoSans',
      color: FomagColors.neutralTitleText,
      fontSize: 20,
      fontWeight: FontWeight.bold,
    ),
    iconTheme: IconThemeData(color: FomagColors.white),
  ),

  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: FomagColors.darkBlue,
      foregroundColor: FomagColors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      textStyle: TextStyle(
        fontFamily: 'NunitoSans',
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
    ),
  ),

  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: FomagColors.lightGray,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide.none,
    ),
    hintStyle: TextStyle(
      fontFamily: 'NunitoSans',
      color: FomagColors.mediumGray,
      fontSize: 14,
    ),
  ),

  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: FomagColors.lightBlue,
      textStyle: TextStyle(
        fontFamily: 'NunitoSans',
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
    ),
  ),

  textTheme: TextTheme(
    bodyLarge: TextStyle(
      fontFamily: 'NunitoSans',
      color: FomagColors.darkBlue,
      fontSize: 18,
    ),
    bodyMedium: TextStyle(
      fontFamily: 'NunitoSans',
      color: FomagColors.mediumGray,
      fontSize: 16,
    ),
    titleLarge: TextStyle(
      fontFamily: 'NunitoSans',
      color: FomagColors.darkBlue,
      fontSize: 22,
      fontWeight: FontWeight.bold,
    ),
  ),
);

PageTransitionsTheme _buildPageTransitionsTheme() {
  return const PageTransitionsTheme(
    builders: <TargetPlatform, PageTransitionsBuilder>{
      TargetPlatform.android: ZoomPageTransitionsBuilder(),
      TargetPlatform.iOS: ZoomPageTransitionsBuilder(),
    },
  );
}
