import 'dart:ui';
import 'package:equatable/equatable.dart';

class FomagColors extends Equatable {
  static const Color primaryColor = Color(0xFF259FD9);
  static const Color secondaryColor = Color(0xFF114964);
  static const Color white = Color(0xFFFFFFFF);
  static const Color lightGray = Color(0xFFE0E0E0);
  static const Color mediumGray = Color(0xFFDFDFDF);
  static const Color darkBlue = Color(0xFF0082B3);
  static const Color lightBlue = Color(0xFF00ACEC);
  static const Color black = Color(0xFF000000);
  static const Color error = Color(0xFFC51D34);
  static const Color gray = Color(0xFF616161);
  static const Color fogGray = Color(0xFFEEEEEE);
  static const Color greenButton = Color(0xFF4CAF50);
  static const Color redButton = Color(0xFFE53935);
  static const Color magenta650 = Color(0xFFC70971);
  static const Color blue450 = Color(0xFF4CB0E0);
  static const Color neutralTitleText = Color(0xFF2A2A2A);
  static const Color buttonPrimary = Color(0xFF259FD9);
  static const Color neutralText = Color(0xFF5F5F5F);
  static const Color neutralRojo = Color(0xFFE53935);
  static const Color neutralBlueTitle = Color(0xFF114964);
  static const Color neutralBlueText = Color(0xFF0077A3);
  static const Color backgroundInputOtp = Color(0xFFD9D9D9);
  static const Color buttonOutline = Color(0xFFC1C1C1);
  static const Color azul750 = Color(0xFF17668B);
  static const Color buttonPrincipal = Color(0xFF1E83B2);
  static const Color success = Color(0xFF4CAF50);
  static const Color buttonSecondary = Color(0xFF114964);
  static const Color errorOtp = Color(0xFFFF5C5C);
  static const Color grayLight = Color(0xFFF2F2F2);

  @override
  List<Object?> get props => [];
}
