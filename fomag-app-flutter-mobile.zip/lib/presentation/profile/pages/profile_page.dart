import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/response/account/account_response.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/text_label.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  // Función para obtener los datos del perfil desde SecureStorage
  Future<AccountData?> getProfile() async {
    final profileMap = await SecureStorageManager.getProfileMap();
    if (profileMap == null) return null;
    return AccountData.fromJson(profileMap);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
          onTap: () {
            NavigationController.pop();
          },
          child: Icon(Icons.arrow_back, color: FomagColors.white),
        ),
        title: CustomText(
          text: 'Mi perfil',
          fontSize: 20,
          color: FomagColors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder<AccountData?>(
          future: getProfile(), // Llamamos a la función asincrónica
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(child: Text('Error al cargar los datos'));
            }

            final account = snapshot.data;
            if (account == null) {
              return Center(child: Text('No se encontraron datos de perfil'));
            }

            return ListView(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white,
                      child: Icon(
                        Icons.person,
                        size: 40,
                        color: FomagColors.primaryColor,
                      ),
                    ),
                    SizedBox(height: 16),
                    _buildProfileInfo('Nombre', account.name, Icons.person),
                    SizedBox(height: 6),
                    _buildProfileInfo(
                      'Tipo de Usuario',
                      account.typeAffiliate,
                      Icons.person,
                    ),
                    SizedBox(height: 6),
                    _buildProfileInfo('Teléfono', '3004291911', Icons.phone),
                    SizedBox(height: 6),
                    _buildProfileInfo('Correo', account.email, Icons.email),
                    SizedBox(height: 6),
                    _buildProfileInfo(
                      'Departamento',
                      account.state,
                      Icons.pin_drop,
                    ),
                    SizedBox(height: 6),
                    _buildProfileInfo(
                      'Ciudad',
                      account.city,
                      Icons.location_city,
                    ),
                  ],
                ),
                SizedBox(height: 30.0),
                PrimaryButton(
                  text: 'Datos básicos',
                  icon: Icons.edit,
                  iconAfterText: true,
                  onPressed: () {},
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildProfileInfo(String label, String value, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          text: label,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: FomagColors.darkBlue,
        ),
        SizedBox(height: 6.0),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: FomagColors.fogGray, width: 1.0),
            borderRadius: BorderRadius.circular(6.0),
          ),
          padding: EdgeInsets.all(10.0),
          child: Row(
            children: [
              Icon(icon, color: FomagColors.gray),
              SizedBox(width: 10.0),
              CustomText(
                text: value,
                fontSize: 16,
                fontWeight: FontWeight.normal,
                color: FomagColors.gray,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
