import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/dependencies/bloc_module.dart';
import 'package:fomagapp/core/dependencies/client_module.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';
import 'package:fomagapp/core/dependencies/repository_module.dart';
import 'package:fomagapp/core/dependencies/services_module.dart';
import 'package:fomagapp/core/dependencies/usecase_module.dart';
import 'package:fomagapp/core/routes/generated_route.dart';

import 'package:fomagapp/presentation/theme/app_global.dart';
import 'package:fomagapp/presentation/widgets/modals/inactivity_widget.dart';

void app() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then((value) => runApp(const MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp>
    with
        ConfigModule,
        ClientModule,
        ServiceModule,
        RepositoryModule,
        UseCaseModule,
        BlocModule {
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: blocProviders,
      child: MaterialApp.router(
        routerConfig: RouterManager.router,
        title: 'Fomag',
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        supportedLocales: const [Locale('es', '')],
        debugShowCheckedModeBanner: false,
        theme: themeData,
        builder: (context, child) {
          return InactivityHandler(
            timeoutDuration: const Duration(
              minutes: 5,
            ), //configurar cuanto tiempo de inactividad debe ser para cerrar sesion

            child: child!,
          );
        },
      ),
    );
  }
}
