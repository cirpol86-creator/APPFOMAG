part of 'login_bloc.dart';

abstract class LoginEvent {}

class TrackerEvent extends LoginEvent {}

class LoginSubmitted extends LoginEvent {
  final LoginRequest request;

  LoginSubmitted({required this.request});
}
