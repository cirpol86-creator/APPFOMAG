import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/login/usecase/login_usecase.dart';

part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final LoginUseCase _loginUseCase;
  final TrackUserEventUseCase _trackUserEventUseCase;

  LoginBloc({
    required LoginUseCase loginUseCase,
    required TrackUserEventUseCase trackUserEventUseCase,
  }) : _trackUserEventUseCase = trackUserEventUseCase,
       _loginUseCase = loginUseCase,
       super(LoginLoading()) {
    on<LoginSubmitted>(_onLogin);
    on<TrackerEvent>(_onTrackerEvent);
  }

  Future<void> _onLogin(LoginSubmitted event, Emitter<LoginState> emit) async {
    emit(LoginLoading());

    final result = await _loginUseCase.callLogin(event.request);

    result.fold(
      (Failure failure) {
        emit(LoginFailure(message: mapFailureToMessage(failure)));
      },
      (AuthResponse response) {
        emit(LoginSuccess(response: response));
      },
    );
  }

  void _onTrackerEvent(TrackerEvent event, Emitter<LoginState> emit) {
    _trackUserEventUseCase.call(
      UserEventModel(UserEventType.login, {'screen_name': 'LoginPage'}),
    );
  }
}
