part of 'login_page.dart';

mixin LoginPageMixin<T extends StatefulWidget> on State<T> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _typeDocumentController = TextEditingController();
  final TextEditingController _documentNumberController =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _rememberMe = false;
  bool _isLoading = false;
  String? _errorMessage;

  void setIsRememberMe(bool? value) {
    setState(() {
      _rememberMe = value ?? false;
    });
  }

  void setIsLoading(bool? value) {
    setState(() {
      _isLoading = value ?? false;
    });
  }

  void setDocumentType(String? value) {
    setState(() {
      _typeDocumentController.text = value ?? '';
    });
  }

  void setErrorMessage(String? value) {
    setState(() {
      _errorMessage = value;
    });
  }

  List<String> get _typesDocumentNumber =>
      TypesDocuments.typesDocuments.map((e) => e.name).toList();

  String? isValidPassword(String? value) {
    if (value == null || value.trim().isEmpty) return 'Ingrese su contraseña';

    return null;
  }

  String? _isValidDocumentNumber(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Ingrese el número de documento';
    }
    final numericRegExp = RegExp(r'^\d+$');
    if (!numericRegExp.hasMatch(value.trim())) {
      return 'Solo se permiten números';
    }
    return null;
  }

  void _trackerEvent() {
    context.read<LoginBloc>().add(TrackerEvent());
  }

  void _isRememberMe() async {
    final password = await SecureStorageManager.getPassword();
    final documentNumber = await SecureStorageManager.getDocumentNumber();
    final typeDocument = await SecureStorageManager.getTypeDocument();

    if ((password != null && password.isNotEmpty) ||
        (documentNumber != null && documentNumber.isNotEmpty)) {
      setIsRememberMe(true);
      if (password != null && password.isNotEmpty) {
        _passwordController.text = password;
      }
      if (documentNumber != null && documentNumber.isNotEmpty) {
        _documentNumberController.text = documentNumber;
      }
      if (typeDocument != null && typeDocument.isNotEmpty) {
        setState(() {
          _typeDocumentController.text = typeDocument;
        });
      }
    }
  }

  void login() {
    setErrorMessage(null);
    if (_formKey.currentState!.validate()) {
      final selectedType = TypesDocuments.typesDocuments.firstWhere(
        (element) => element.name == _typeDocumentController.text,
      );
      final String documentTypeId = selectedType.id;

      LoginRequest request = LoginRequest(
        documentType: documentTypeId,
        documentNumber: _documentNumberController.text.trim(),
        password: _passwordController.text.trim(),
      );

      if (!mounted) return;

      context.read<LoginBloc>().add(LoginSubmitted(request: request));
    }
  }

  Future<void> onLoginSuccess(LoginSuccess state) async {
    final response = state.response;

    if (_rememberMe) {
      await SecureStorageManager.setPassword(_passwordController.text.trim());
      await SecureStorageManager.setDocumentNumber(
        _documentNumberController.text.trim(),
      );
      await SecureStorageManager.setTypeDocument(
        _typeDocumentController.text.trim(),
      );
    } else {
      await SecureStorageManager.clearAll();
    }

    if (response.accessToken != null && response.refreshToken != null) {
      await SecureStorageManager.setAccessToken(response.accessToken ?? '');
      await SecureStorageManager.setRefreshToken(response.refreshToken ?? '');
      await SecureStorageManager.setIdToken(response.idToken ?? '');

      await NavigationController.push(Routes.home.routePath, clean: true);
      return;
    }

    if (response.challenge == Challenge.mfaRequired) {
      await NavigationController.push(
        Routes.otpVerification.routePath,
        arguments: OtpVerificationPageParams(
          title: 'Autorizar ingreso',
          text: 'Inserte el código enviado:',
          userName: response.userName ?? '',
          session: response.session ?? '',
          challengeType: response.challenge?.value ?? '',
          message: response.message ?? '',
        ),
      );
    } else if (response.challenge == Challenge.resetPasswordRequired) {
      await NavigationController.push(
        Routes.passwordResetLogin.routePath,
        arguments: PasswordResetLoginPageParams(
          userName: response.userName ?? '',
          session: response.session ?? '',
          challengeType: response.challenge?.value ?? '',
          message: response.message ?? '',
        ),
      );
    }
  }

  void onLoginFailure(LoginFailure state) {
    setErrorMessage(state.message);
  }

  @override
  void dispose() {
    _documentNumberController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
