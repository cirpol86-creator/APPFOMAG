import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/data/model/types_documents.dart';
import 'package:fomagapp/presentation/otp_verification/pages/otp_verification_page.dart';
import 'package:fomagapp/presentation/password_reset/pages/password_reset_login/password_reset_login.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/login/bloc/login_bloc.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/common/buttons/link_button.dart';
import 'package:fomagapp/presentation/widgets/error_text.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_picker.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_text.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';

part 'login_page_mixin.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with LoginPageMixin {
  @override
  void initState() {
    super.initState();
    _isRememberMe();
    _trackerEvent();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<LoginBloc, LoginState>(
      listener: (context, state) async {
        if (state is LoginLoading) {
          setIsLoading(true);
        }

        if (state is LoginSuccess) {
          await onLoginSuccess(state);
        }

        if (state is LoginFailure) {
          onLoginFailure(state);
        }

        if (state is! LoginLoading) {
          setIsLoading(false);
        }
      },
      child: ScaffoldSimple(
        isLoading: _isLoading,
        body: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Iniciar sesión',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,

                  fontFamily: 'NunitoSans',
                  foreground:
                      Paint()
                        ..style = PaintingStyle.stroke
                        ..strokeWidth = 0.7
                        ..color = FomagColors.neutralBlueTitle,
                ),
              ),
              const SizedBox(height: 24),
              RoundedPicker(
                label: 'Tipo de Documento',
                hintText: 'Tipo de Documento',
                options: _typesDocumentNumber,
                selectedValue:
                    _typeDocumentController.text.isNotEmpty &&
                            _typesDocumentNumber.contains(
                              _typeDocumentController.text,
                            )
                        ? _typeDocumentController.text
                        : null,
                onChanged: (value) {
                  setState(() {
                    _typeDocumentController.text = value ?? '';
                  });
                },
                validator:
                    (value) =>
                        value == null || value.isEmpty
                            ? 'Selecciona un tipo de documento'
                            : null,
              ),
              const SizedBox(height: 16),
              RoundedEntry(
                controller: _documentNumberController,
                hintText: 'Número de Documento',
                label: 'Número de Documento',
                validator: _isValidDocumentNumber,
              ),
              const SizedBox(height: 16),
              RoundedEntry(
                controller: _passwordController,
                hintText: 'Contraseña',
                isPassword: true,
                label: 'Contraseña',
                validator: isValidPassword,
              ),
              if (_errorMessage != null) ...[
                ErrorText(message: _errorMessage!),
              ],
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Transform.scale(
                    scale: 1.3,
                    child: Checkbox(
                      value: _rememberMe,
                      onChanged: setIsRememberMe,
                      activeColor: FomagColors.buttonPrimary,
                      checkColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                        side: BorderSide(
                          color: FomagColors.neutralText,
                          width: 1,
                          style: BorderStyle.solid,
                          strokeAlign: 2,
                        ),
                      ),
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                  Text(
                    'Recordarme',
                    style: TextStyle(
                      color: FomagColors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              PrimaryButton(
                text: 'Iniciar Sesión',
                onPressed: login,
                enabled: !_isLoading,
              ),
              const SizedBox(height: 24),
              Center(
                child: LinkButtonWidget(
                  text: "¿Olvido su contraseña?",
                  onPressed: () {
                    NavigationController.push(Routes.passwordReset.routePath);
                  },
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: Divider(
                      thickness: 1,
                      color: FomagColors.neutralText,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 25),
                    child: Text(
                      'ó',
                      style: TextStyle(
                        color: FomagColors.neutralText,
                        fontFamily: 'NunitoSans',
                      ),
                    ),
                  ),
                  Expanded(
                    child: Divider(
                      thickness: 1,
                      color: FomagColors.neutralText,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Center(
                child: LinkButtonWidget(
                  text: "Crear una cuenta",
                  onPressed: () {
                    NavigationController.push(Routes.register.routePath);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
