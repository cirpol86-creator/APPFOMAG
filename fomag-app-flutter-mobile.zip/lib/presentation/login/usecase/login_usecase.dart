import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/data/repositories/login_repository.dart';

class LoginUseCase {
  final LoginRepository _login;

  LoginUseCase({required LoginRepository login}) : _login = login;

  Future<Either<Failure<DioExceptionType>, AuthResponse>> callLogin(
    LoginRequest loginRequest,
  ) async {
    return _login.login(loginRequest);
  }
}
