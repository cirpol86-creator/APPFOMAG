import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/data/repositories/news_repository.dart';

class NewsUseCase {
  final NewsRepository _repository;

  NewsUseCase({required NewsRepository repository})
    : _repository = repository;

  Future<Either<Failure<DioExceptionType>, NewsResponse>> call() async {
    return _repository.news();
  }
}
