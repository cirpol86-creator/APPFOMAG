import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';
import 'package:fomagapp/data/repositories/banner_repository.dart';

class GetBannerUseCase {
  final BannerRepository _bannerRepository;

  GetBannerUseCase({required BannerRepository bannerRepository})
    : _bannerRepository = bannerRepository;

  Future<Either<Failure<DioExceptionType>, BannerResponse>> call() {
    return _bannerRepository.getBanner();
  }
}
