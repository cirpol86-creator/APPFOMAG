part of 'home_page.dart';

mixin HomePageMixin<T extends StatefulWidget> on State<T> {
  final bool _hasSurveys = false;
  String? url;
  // ignore: unused_field, prefer_final_fields
  bool _isVideo = false;
  bool _isYoutubeVideo(String url) {
    return url.contains('youtube.com') || url.contains('youtu.be');
  }

  final videoManager = VideoManager();

  /* void _initializeContent() async {
    _isVideo =
        url.toLowerCase().endsWith('.mp4') ||
        url.toLowerCase().endsWith('.mov') ||
        url.toLowerCase().endsWith('.webm');

    if (_isVideo) {
      await videoManager.initializeVideo(url);
    }

    if (mounted) setState(() {});
  } */

  void _trackerEvent() {
    context.read<HomeBloc>().add(TrackerEvent());
  }

  @override
  void dispose() {
    videoManager.dispose();
    super.dispose();
  }
}
