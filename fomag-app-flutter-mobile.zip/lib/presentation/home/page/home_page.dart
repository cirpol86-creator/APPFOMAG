import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/utils/video_manager.dart';
import 'package:fomagapp/presentation/home/bloc/home_bloc.dart';
import 'package:fomagapp/presentation/home/widgets/banner.dart';
import 'package:fomagapp/presentation/home/widgets/news/news.dart';
import 'package:fomagapp/presentation/home/widgets/pending_survey_card.dart';
import 'package:fomagapp/presentation/widgets/copyright_widget.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';

part 'home_page_mixin.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with HomePageMixin {
  @override
  void initState() {
    super.initState();
    _trackerEvent();
    context.read<HomeBloc>().add(LoadBannerEvent());
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldMain(
      body: SingleChildScrollView(
        child: Column(
          children: [
            BlocBuilder<HomeBloc, HomeState>(
              builder: (context, state) {
                if (state is BannerLoading) {
                  return const CircularProgressIndicator();
                } else if (state is BannerLoaded) {
                  final banner = state.banner;
                  final isVideo = banner.type.toLowerCase() == 'video';
                  final url = banner.url;
                  final isYoutube = _isYoutubeVideo(url);
                  if (url.trim().isEmpty) return const SizedBox.shrink();

                  if (isVideo && !isYoutube) {
                    videoManager.initializeVideo(url);
                  }

                  return BannerWidget(
                    isYoutube: isYoutube,
                    isVideo: isVideo,
                    url: url,
                    videoManager: videoManager,
                  );
                } else if (state is BannerError) {
                  return const Text('Error al cargar el banner');
                }

                return const SizedBox.shrink();
              },
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  if (_hasSurveys) ...[
                    PendingSurveyCard(
                      onPressed: () {
                        NavigationController.push(Routes.survey.routePath);
                      },
                    ),
                    const SizedBox(height: 40),
                  ],
                  NewsWidget(),
                  const SizedBox(height: 40),
                  // HealthCenterWidget(),
                  // const SizedBox(height: 16),
                  CopyrightWidget(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
