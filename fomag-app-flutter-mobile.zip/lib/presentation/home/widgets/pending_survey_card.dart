import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';

class PendingSurveyCard extends StatelessWidget {
  final VoidCallback onPressed;

  const PendingSurveyCard({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'Tiene una encuesta pendiente',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w500,
            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.7
                  ..color = FomagColors.neutralBlueTitle,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: FomagColors.buttonOutline),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              Text(
                'Encuesta Satisfacción en los\nservicios de salud',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: FomagColors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'NunitoSans',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Complete la encuesta, su opinión\nes importante para nosotros.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: FomagColors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'NunitoSans',
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: PrimaryButton(
                  text: 'Completar encuesta',
                  onPressed: onPressed,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
