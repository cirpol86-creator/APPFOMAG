import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/cards/card_entity.dart';
import 'package:fomagapp/data/model/health_center_model.dart';

class HealthCenterWidget extends StatelessWidget {
  const HealthCenterWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final itemsToShow =
        HealthCenterModel.healthCenterList.length > 4
            ? 4
            : HealthCenterModel.healthCenterList.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Centro de Salud',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,

            fontFamily: 'NunitoSans',
            foreground:
                Paint()
                  ..style = PaintingStyle.stroke
                  ..strokeWidth = 0.7
                  ..color = FomagColors.neutralBlueTitle,
          ),
        ),
        const SizedBox(height: 16),
        ...List.generate(itemsToShow, (index) {
          final center = HealthCenterModel.healthCenterList[index];
          return CardEntity(
            title: center.title,
            address: center.address,
            onTap: center.onTap,
            imageUrl: center.imageUrl,
          );
        }),
        const SizedBox(height: 16),
        PrimaryButton(text: 'Ver todos los Centros de Salud', onPressed: () {}),
      ],
    );
  }
}
