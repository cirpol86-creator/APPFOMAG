import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:fomagapp/core/utils/video_manager.dart';

import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class BannerWidget extends StatefulWidget {
  const BannerWidget({
    super.key,
    required this.isVideo,
    required this.isYoutube,
    required this.url,
    required this.videoManager,
  });

  final bool isVideo;
  final bool isYoutube;
  final String url;
  final VideoManager videoManager;

  @override
  State<BannerWidget> createState() => _BannerWidgetState();
}

class _BannerWidgetState extends State<BannerWidget> {
  YoutubePlayerController? _youtubeController;
  late final String _url;

  @override
  void initState() {
    super.initState();

    _url = widget.url;

    if (widget.isYoutube && _url.isNotEmpty) {
      final videoId = YoutubePlayer.convertUrlToId(_url);
      if (videoId != null && videoId.isNotEmpty) {
        _youtubeController = YoutubePlayerController(
          initialVideoId: videoId,
          flags: const YoutubePlayerFlags(autoPlay: false),
        );
      }
    }
  }

  @override
  void dispose() {
    _youtubeController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_url.isEmpty) return const SizedBox.shrink();

    return AspectRatio(
      aspectRatio: 16 / 9,
      child: SizedBox(
        width: 390,
        height: 219,
        child:
            widget.isVideo
                ? (widget.isYoutube
                    ? (_youtubeController != null
                        ? YoutubePlayer(
                          controller: _youtubeController!,
                          showVideoProgressIndicator: true,
                        )
                        : const Center(child: CircularProgressIndicator()))
                    : (widget.videoManager.chewieController != null
                        ? Chewie(
                          controller: widget.videoManager.chewieController!,
                        )
                        : const Center(child: CircularProgressIndicator())))
                : CachedNetworkImage(
                  imageUrl: _url,
                  fit: BoxFit.cover,
                  placeholder:
                      (_, __) =>
                          const Center(child: CircularProgressIndicator()),
                  errorWidget:
                      (_, __, ___) => const Center(child: Icon(Icons.error)),
                ),
      ),
    );
  }
}
