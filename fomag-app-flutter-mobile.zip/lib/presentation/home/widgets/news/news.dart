import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/presentation/home/bloc/home_bloc.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/cards/card_new.dart';
import 'package:fomagapp/presentation/widgets/retry_widget.dart';
import 'package:skeletonizer/skeletonizer.dart';

part 'news_mixin.dart';

class NewsWidget extends StatefulWidget {
  const NewsWidget({super.key});

  @override
  State<NewsWidget> createState() => _NewsWidgetState();
}

class _NewsWidgetState extends State<NewsWidget> with NewsWidgetMixin {
  @override
  initState() {
    super.initState();
    initializeContent();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<HomeBloc, HomeState>(
      listener: (context, state) {
        if (state is NewsLoading) {
          newsLoading(state);
        }
        if (state is NewsSuccess) {
          newsSuccess(state);
        }
        if (state is NewsFailure) {
          newsFailure(state);
        }
      },
      child: SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              'Noticias',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                fontFamily: 'NunitoSans',
                foreground:
                    Paint()
                      ..style = PaintingStyle.stroke
                      ..strokeWidth = 0.7
                      ..color = FomagColors.neutralBlueTitle,
              ),
            ),
            const SizedBox(height: 16),
            errorMessage != null
                ? RetryWidget(errorMessage: errorMessage, onPressed: onRetry)
                : Skeletonizer(
                  enabled: isLoading,
                  child: Column(
                    children: List.generate(itemsToShow ?? 3, (index) {
                      final news = newsList?[index] ?? NewsContent();
                      return CardNew(
                        title: news.title,
                        imageUrl: news.imageBanner,
                        category: news.body,
                        date: news.date,
                        onTap: () {
                          NavigationController.push(
                            Routes.newInfo.routePath,
                            arguments: news.id,
                          );
                        },
                      );
                    }),
                  ),
                ),
            if (errorMessage == null) ...[
              const SizedBox(height: 16),
              PrimaryButton(
                text: 'Ver más Noticias',
                onPressed: () {
                  NavigationController.push(Routes.listNews.routePath);
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}
