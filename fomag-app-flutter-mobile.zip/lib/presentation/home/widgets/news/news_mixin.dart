part of 'news.dart';

mixin NewsWidgetMixin<T extends StatefulWidget> on State<T> {
  List<NewsContent>? newsList;
  int? itemsToShow;
  bool isLoading = true;
  String? errorMessage;

  void setNewsList(List<NewsContent>? value) {
    setState(() {
      newsList = value;
    });
  }

  void setItemsToShow(int? value) {
    setState(() {
      itemsToShow = value;
    });
  }

  void setIsLoading(bool value) {
    setState(() {
      isLoading = value;
    });
  }

  void setErrorMessage(String? value) {
    setState(() {
      errorMessage = value;
    });
  }

  void newsSuccess(NewsSuccess state) {
    final news = state.response.content;
    final countNews = news.length;
    final itemsToShow = countNews > 5 ? 5 : countNews;
    setItemsToShow(itemsToShow);
    setNewsList(state.response.content);
    setIsLoading(false);
  }

  void newsFailure(NewsFailure state) {
    setErrorMessage(state.message);
    setIsLoading(false);
  }

  void initializeContent() async {
    context.read<HomeBloc>().add(NewsSubmitted());
  }

  void onRetry() {
    setErrorMessage(null);
    initializeContent();
  }

  void newsLoading(NewsLoading state) {
    setIsLoading(true);
  }
}
