import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/home/usecases/get_banner_use_case.dart';
import 'package:fomagapp/presentation/home/usecases/news_usecase.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final NewsUseCase _newsUseCase;
  final TrackUserEventUseCase _trackUserEventUseCase;
  final GetBannerUseCase _getBannerUseCase;

  HomeBloc({
    required NewsUseCase newsUseCase,
    required TrackUserEventUseCase trackUserEventUseCase,
    required GetBannerUseCase getBannerUseCase,
  }) : _newsUseCase = newsUseCase,
       _trackUserEventUseCase = trackUserEventUseCase,
       _getBannerUseCase = getBannerUseCase,

       super(HomeInitial()) {
    on<NewsSubmitted>(_onNewsSubmitted);
    on<TrackerEvent>(_onTrackerEvent);
    on<LoadBannerEvent>(_onLoadBanner);
  }

  Future<void> _onNewsSubmitted(
    NewsSubmitted event,
    Emitter<HomeState> emit,
  ) async {
    emit(NewsLoading());

    final result = await _newsUseCase();

    result.fold(
      (Failure failure) {
        emit(NewsFailure(message: mapFailureToMessage(failure)));
      },
      (NewsResponse response) {
        emit(NewsSuccess(response: response));
      },
    );
  }

  void _onTrackerEvent(TrackerEvent event, Emitter<HomeState> emit) {
    _trackUserEventUseCase.call(
      UserEventModel(UserEventType.home, {'screen_name': 'HomePage'}),
    );
  }

  Future<void> _onLoadBanner(
    LoadBannerEvent event,
    Emitter<HomeState> emit,
  ) async {
    emit(BannerLoading());
    final result = await _getBannerUseCase();

    result.fold(
      (failure) => emit(BannerError(failure.message)),
      (banner) => emit(BannerLoaded(banner)),
    );
  }
}
