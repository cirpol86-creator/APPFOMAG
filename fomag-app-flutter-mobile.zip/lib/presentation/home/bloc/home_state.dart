part of 'home_bloc.dart';

class HomeState extends Equatable {
  @override
  List<Object> get props => [];
}

class HomeInitial extends HomeState {}

class NewsLoading extends HomeState {}

class NewsSuccess extends HomeState {
  final NewsResponse response;
  NewsSuccess({required this.response});

  @override
  List<Object> get props => [response];
}

class NewsFailure extends HomeState {
  final String message;
  NewsFailure({required this.message});

  @override
  List<Object> get props => [message];
}

class BannerLoading extends HomeState {}

class BannerLoaded extends HomeState {
  final BannerResponse banner;

  BannerLoaded(this.banner);

  @override
  List<Object> get props => [banner];
}

class BannerError extends HomeState {
  final String message;

  BannerError(this.message);

  @override
  List<Object> get props => [message];
}
