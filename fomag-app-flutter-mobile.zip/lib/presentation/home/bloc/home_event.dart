part of 'home_bloc.dart';

abstract class HomeEvent extends Equatable {
  const HomeEvent();

  @override
  List<Object> get props => [];
}

class NewsSubmitted extends HomeEvent {
  @override
  List<Object> get props => [];
}

class LoadBannerEvent extends HomeEvent {}

class TrackerEvent extends HomeEvent {}
