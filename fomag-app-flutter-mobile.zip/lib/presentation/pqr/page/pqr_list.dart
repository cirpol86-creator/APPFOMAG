import 'package:flutter/material.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/green_button.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';

import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_main/scaffold_main.dart';
import 'package:url_launcher/url_launcher.dart';

class PqrList extends StatelessWidget {
  const PqrList({super.key});

  void showCustomLoadingModal(BuildContext context, String tipo) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (_) => Dialog(
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: FomagColors.gray),
                  SizedBox(height: 20),
                  Text(
                    'Redireccionando...',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.black87,
                      fontFamily: 'NunitoSans',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Será redirigido al sitio oficial de Fomag para completar el proceso de $tipo de tu PQR',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black54,
                      fontFamily: 'NunitoSans',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
    );
  }

  void showLoadingAndLaunchUrl(
    BuildContext context,
    Uri url,
    String tipo,
  ) async {
    showCustomLoadingModal(context, tipo);

    await Future.delayed(const Duration(seconds: 3));

    // ignore: use_build_context_synchronously
    Navigator.of(context).pop();

    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      ScaffoldMessenger.of(
        // ignore: use_build_context_synchronously
        context,
      ).showSnackBar(const SnackBar(content: Text('No se pudo abrir la URL')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldMain(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                SizedBox(
                  height: 160,
                  width: double.infinity,
                  child: Image.asset(
                    'assets/images/imagen_pqrs.jpg',
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  left: 16,
                  top: 25,
                  child: Text(
                    'Peticiones\nQuejas y\nReclamos',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'NunitoSans',
                      foreground:
                          Paint()
                            ..style = PaintingStyle.stroke
                            ..strokeWidth = 1.1
                            ..color = Colors.white,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'PQR',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'NunitoSans',
                    foreground:
                        Paint()
                          ..style = PaintingStyle.stroke
                          ..strokeWidth = 1.1
                          ..color = FomagColors.azul750,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),

            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '¿Tienes una petición, queja o reclamo?',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                    ),
                    textAlign: TextAlign.start,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'En nuestro compromiso por brindarte un servicio de calidad, ponemos a tu disposición este espacio para que puedas radicar cualquier solicitud, expresar tus inquietudes o compartir sugerencias. Tu opinión es muy importante para nosotros y nos ayuda a mejorar continuamente.',
                    style: TextStyle(
                      fontSize: 16,
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                    ),
                    textAlign: TextAlign.start,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Haz clic para consultar o radicar tu PQR y recibe una respuesta oportuna por parte de nuestro equipo.',
                    style: TextStyle(
                      fontSize: 16,
                      color: FomagColors.black,
                      fontFamily: 'NunitoSans',
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                  SizedBox(height: 24),
                  PrimaryButton(
                    text: 'Radicar PQR',
                    onPressed: () {
                      final url = Uri.parse(
                        'https://fiduprevisorafidugestorpqrsd.digitalwaresaas.com.co:8082/DMSWebFormExit/#/index',
                      );
                      showLoadingAndLaunchUrl(context, url, 'radicación');
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Expanded(
                        child: Divider(color: FomagColors.gray, thickness: 1.2),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Text(
                          'ó',
                          style: TextStyle(
                            color: FomagColors.gray,
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                            fontFamily: 'NunitoSans',
                          ),
                        ),
                      ),
                      Expanded(
                        child: Divider(color: FomagColors.gray, thickness: 1.2),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  GreenButton(
                    text: 'Consultar PQR',
                    onPressed: () {
                      final url = Uri.parse(
                        'https://fiduprevisorafidugestorpqrsd.digitalwaresaas.com.co:8082/DMSWebFormExit/#/search',
                      );
                      showLoadingAndLaunchUrl(context, url, 'consulta');
                    },
                    buttonTextAlignment: MainAxisAlignment.center,
                  ),
                  const SizedBox(height: 50),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
