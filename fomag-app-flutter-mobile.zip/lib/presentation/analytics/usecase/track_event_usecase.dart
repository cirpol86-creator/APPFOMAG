import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/data/repositories/analytics_repository.dart';

class TrackUserEventUseCase {
  final AnalyticsRepository _analyticsRepository;

  TrackUserEventUseCase({required AnalyticsRepository analyticsRepository})
    : _analyticsRepository = analyticsRepository;

  Future<void> call(UserEventModel event) async {
    await _analyticsRepository.logEvent(event);
  }
}
