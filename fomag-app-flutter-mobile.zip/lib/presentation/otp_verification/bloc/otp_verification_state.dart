part of 'otp_verification_bloc.dart';

abstract class OtpVerificationState extends Equatable {
  @override
  List<Object?> get props => [];
}

class OtpVerificationLoading extends OtpVerificationState {}

class OtpVerificationSuccess extends OtpVerificationState {
  final OtpValidateResponse response;
  OtpVerificationSuccess({required this.response});

  @override
  List<Object?> get props => [response];
}

class OtpVerificationFailure extends OtpVerificationState {
  final String message;
  OtpVerificationFailure({required this.message});

  @override
  List<Object?> get props => [message];
}
