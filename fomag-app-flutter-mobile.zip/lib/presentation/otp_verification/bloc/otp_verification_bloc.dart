import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/presentation/otp_verification/usecase/otp_verification_usecase.dart';

part 'otp_verification_event.dart';
part 'otp_verification_state.dart';

class OtpVerificationBloc
    extends Bloc<OtpVerificationEvent, OtpVerificationState> {
  final OtpVerificationUseCase _otpVerificationUseCase;

  OtpVerificationBloc({required OtpVerificationUseCase otpVerificationUseCase})
    : _otpVerificationUseCase = otpVerificationUseCase,
      super(OtpVerificationLoading()) {
    on<OtpVerificationSubmitted>(_onOtpVerification);
  }

  Future<void> _onOtpVerification(
    OtpVerificationSubmitted event,
    Emitter<OtpVerificationState> emit,
  ) async {
    emit(OtpVerificationLoading());
    final result = await _otpVerificationUseCase.callOtpVerification(
      event.request,
    );

    result.fold(
      (failure) {
        emit(OtpVerificationFailure(message: mapFailureToMessage(failure)));
      },
      (response) {
        emit(OtpVerificationSuccess(response: response));
      },
    );
  }
}
