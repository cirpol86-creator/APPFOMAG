part of 'otp_verification_bloc.dart';

abstract class OtpVerificationEvent {}

class OtpVerificationSubmitted extends OtpVerificationEvent {
  final OtpValidateRequest request;

  OtpVerificationSubmitted({required this.request});
}
