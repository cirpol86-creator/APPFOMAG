import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/data/repositories/otp_verification_repository.dart';

class OtpVerificationUseCase {
  final OtpVerificationRepository _repository;

  OtpVerificationUseCase({required OtpVerificationRepository repository}) : _repository = repository;

  Future<Either<Failure<DioExceptionType>, OtpValidateResponse>> callOtpVerification(
    OtpValidateRequest request,
  ) async {
    return _repository.otpVerification(request);
  }
}
