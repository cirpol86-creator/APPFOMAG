part of 'otp_verification_page.dart';

mixin OtpVerificationPageMixin<T extends StatefulWidget> on State<T> {
  final TextEditingController code = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  String? _errorMessage;
  int _remainingSeconds = 180;
  Ticker? _ticker;

  late final OtpVerificationPageParams params =
      (widget as OtpVerificationPage).params;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void setIsLoading(bool? value) {
    setState(() {
      _isLoading = value ?? false;
    });
  }

  void setErrorMessage(String? value) {
    setState(() {
      _errorMessage = value;
    });
  }

  Future<void> onOtpVerificationSuccess(OtpVerificationSuccess state) async {
    await SecureStorageManager.setAccessToken(state.response.accessToken);
    await SecureStorageManager.setRefreshToken(state.response.refreshToken);
    await SecureStorageManager.setIdToken(state.response.idToken);
    await NavigationController.push(Routes.home.routePath, clean: true);
  }

  void onOtpVerificationFailure(OtpVerificationFailure state) {
    setErrorMessage(state.message);
  }

  void _startTimer() {
    _remainingSeconds = 180;

    _ticker?.dispose();

    _ticker = Ticker((elapsed) {
      setState(() {
        _remainingSeconds = 180 - elapsed.inSeconds;
        if (_remainingSeconds <= 0) {
          InformativeModal.show(
            context: context,
            title: 'Advertencia',
            message: 'El Código ha expirado, por favor solicite uno nuevo.',
            buttonText: 'Volver al inicio',
            topIcon: Icons.error_outline_rounded,
            iconColor: FomagColors.blue450,
            buttonColor: FomagColors.blue450,
            dismissible: false,
            onButtonPressed: () {
              NavigationController.pop();
              NavigationController.pop();
            },
          );
          _ticker?.dispose();
        }
      });
    })..start();
  }

  void onSubmit() {
    setErrorMessage(null);
    _formKey.currentState!.validate();

    if (_errorMessage != null) return;

    final request = OtpValidateRequest(
      userName: params.userName,
      code: code.text,
      session: params.session,
      challengeType: params.challengeType,
    );

    context.read<OtpVerificationBloc>().add(
      OtpVerificationSubmitted(request: request),
    );
  }

  String? isValidOtp(String? value) {
    if (value == null || value.isEmpty) {
      setErrorMessage('Por favor ingrese el código');
    } else if (value.length != 6) {
      setErrorMessage('El código debe tener 6 dígitos');
    }

    return null;
  }

  void onChanged(String? value) {
    if (value == null || value.isEmpty) return;

    if (value.length != 6) return;

    setErrorMessage(null);
  }

  @override
  void dispose() {
    code.dispose();
    super.dispose();
  }
}
