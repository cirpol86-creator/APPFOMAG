import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/presentation/otp_verification/bloc/otp_verification_bloc.dart';
import 'package:fomagapp/presentation/theme/colors.dart';
import 'package:fomagapp/presentation/widgets/buttons/primary_button.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:pinput/pinput.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';
import 'package:url_launcher/url_launcher.dart';

part 'otp_veritication_page_mixin.dart';

class OtpVerificationPageParams {
  final String userName;
  final String title;
  final String text;
  final String message;
  final String session;
  final String challengeType;

  const OtpVerificationPageParams({
    required this.userName,
    required this.title,
    required this.text,
    required this.message,
    required this.session,
    required this.challengeType,
  });
}

class OtpVerificationPage extends StatefulWidget {
  const OtpVerificationPage({super.key, required this.params});

  final OtpVerificationPageParams params;

  @override
  State<OtpVerificationPage> createState() => _OtpVerificationPageState();
}

class _OtpVerificationPageState extends State<OtpVerificationPage>
    with OtpVerificationPageMixin {
  @override
  Widget build(BuildContext context) {
    final minutes = (_remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (_remainingSeconds % 60).toString().padLeft(2, '0');
    return BlocListener<OtpVerificationBloc, OtpVerificationState>(
      listener: (context, state) async {
        if (state is OtpVerificationLoading) {
          setIsLoading(true);
        }

        if (state is OtpVerificationSuccess) {
          await onOtpVerificationSuccess(state);
        }

        if (state is OtpVerificationFailure) {
          onOtpVerificationFailure(state);
        }

        if (state is! OtpVerificationLoading) {
          setIsLoading(false);
        }
      },
      child: ScaffoldSimple(
        isLoading: _isLoading,
        body: Column(
          children: [
            Text(
              params.title,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                fontFamily: 'NunitoSans',
                foreground:
                    Paint()
                      ..style = PaintingStyle.stroke
                      ..strokeWidth = 0.7
                      ..color = FomagColors.neutralBlueTitle,
              ),
            ),
            SizedBox(height: 12),
            Text(
              params.message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: FomagColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                fontFamily: 'NunitoSans',
              ),
            ),
            SizedBox(height: 12),
            Text(
              params.text,
              style: TextStyle(
                color: FomagColors.black,
                fontSize: 18,
                fontFamily: 'NunitoSans',
              ),
            ),
            SizedBox(height: 12),
            Form(
              key: _formKey,
              child: Pinput(
                controller: code,
                length: 6,
                defaultPinTheme: PinTheme(
                  height: 56,
                  width: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: FomagColors.backgroundInputOtp,
                  ),
                  textStyle: TextStyle(
                    color: FomagColors.neutralBlueTitle,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'NunitoSans',
                  ),
                ),
                errorPinTheme: PinTheme(
                  height: 56,
                  width: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: FomagColors.backgroundInputOtp,
                    border: Border.all(color: FomagColors.errorOtp, width: 1.5),
                  ),
                  textStyle: TextStyle(
                    color: FomagColors.neutralBlueTitle,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'NunitoSans',
                  ),
                ),
                validator: isValidOtp,
                forceErrorState: _errorMessage != null,
                errorBuilder: (error, value) {
                  return error != null
                      ? Center(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: Text(
                            error,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: FomagColors.errorOtp,
                              fontSize: 16,
                              fontFamily: 'NunitoSans',
                            ),
                          ),
                        ),
                      )
                      : SizedBox();
                },
                onChanged: onChanged,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                keyboardType: TextInputType.number,
              ),
            ),
            if (_errorMessage != null) ...[
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    _errorMessage!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: FomagColors.errorOtp,
                      fontSize: 16,
                      fontFamily: 'NunitoSans',
                    ),
                  ),
                ),
              ),
            ],
            SizedBox(height: 40),
            PrimaryButton(
              text: 'Autorizar',
              onPressed: onSubmit,
              isLoading: _isLoading,
              enabled: !_isLoading,
            ),
            SizedBox(height: 20),
            Text(
              '$minutes:$seconds',
              style: const TextStyle(color: FomagColors.neutralBlueTitle),
            ),
            SizedBox(height: 20),
            RichText(
              textAlign: TextAlign.center,
              text: TextSpan(
                style: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // Texto general en negro
                ),
                children: [
                  const TextSpan(
                    text:
                        '¿Tiene problemas con el correo?\nCree una PQR haciendo clic ',
                  ),
                  TextSpan(
                    text: 'aquí',
                    style: const TextStyle(
                      color: FomagColors.neutralBlueTitle,
                      decoration: TextDecoration.underline,
                    ),
                    recognizer:
                        TapGestureRecognizer()
                          ..onTap = () async {
                            final Uri url = Uri.parse(
                              'https://fiduprevisorafidugestorpqrsd.digitalwaresaas.com.co:8082/DMSWebFormExit/#/index',
                            );
                            if (await canLaunchUrl(url)) {
                              await launchUrl(
                                url,
                                mode: LaunchMode.externalApplication,
                              );
                            } else {
                              debugPrint('No se pudo abrir el enlace');
                            }
                          },
                  ),
                  const TextSpan(text: ' para resolver su inconveniente.'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
