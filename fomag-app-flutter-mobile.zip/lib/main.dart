import 'package:equatable/equatable.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fomagapp/core/analytics/analytics_service.dart';
import 'package:fomagapp/core/network/services/conection_service.dart';
import 'package:fomagapp/core/utils/lifecycle_event_handler.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/data/repositories/analytics_repository.dart';
import 'package:fomagapp/presentation/app.dart';
import 'package:fomagapp/presentation/widgets/screens/without_internet_screen.dart';
import 'package:provider/provider.dart';

void mainApp() async {
  WidgetsFlutterBinding.ensureInitialized();
  EquatableConfig.stringify = true;
  // Inicializa Firebase
  await Firebase.initializeApp();
  final firebaseAnalytics = FirebaseAnalytics.instance;
  final analyticsService = AnalyticsService(analytics: firebaseAnalytics);
  final analyticsRepository = AnalyticsRepository(
    analyticsService: analyticsService,
  );

  // Observador del ciclo de vida
  WidgetsBinding.instance.addObserver(
    LifecycleEventHandler(
      pausedCallBack:
          () => analyticsRepository.logEvent(
            UserEventModel(UserEventType.appClosed, {'reason': 'paused'}),
          ),
      detachedCallBack:
          () => analyticsRepository.logEvent(
            UserEventModel(UserEventType.appClosed, {'reason': 'detached'}),
          ),
    ),
  );
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then(
    (value) => runApp(
      ChangeNotifierProvider(
        create: (context) => ConnectionService(),
        builder: (context, child) {
          final connectionService = context.read<ConnectionService>();

          Future.microtask(() {
            connectionService.removeListener(WithoutInternetScreen.show);
            connectionService.addListener(WithoutInternetScreen.show);
          });

          return MyApp();
        },
      ),
    ),
  );
}
