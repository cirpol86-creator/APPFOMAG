import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/enviroment/environment.dart';
import 'package:fomagapp/core/network/services/abstract/firebase_options.dart';
import 'package:fomagapp/core/network/services/implementation/firebase_remote_config_service_impl.dart';
import 'package:fomagapp/main.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Cargar variables de entorno antes de inicializar Firebase
  await dotenv.load(fileName: ".env");

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // 2. Crear e inicializar el servicio de Remote Config
  final remoteConfigService = FirebaseRemoteConfigServiceImpl(
    FirebaseRemoteConfig.instance,
  );
  await remoteConfigService.initialize();

  // 3. Construir el Environment dinámicamente desde Remote Config
  final environment = remoteConfigService.buildEnvironment(
    Environment.quality().envName,
  );
  AppConfig(env: environment);
  mainApp();
}
