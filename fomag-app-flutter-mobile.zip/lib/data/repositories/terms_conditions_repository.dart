import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/terms_conditions_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/core/network/util/const.dart';

class TermsConditionsRepository with ConnectivityMixin {
  final TermsConditionsService _termsConditions;

  TermsConditionsRepository({required TermsConditionsService termsConditions})
    : _termsConditions = termsConditions;

  Future<Either<Failure<DioExceptionType>, String>>
  fetchTermsAndConditions() async {
    if (await isInConnection()) {
      try {
        final client = await _termsConditions.fetchTermsAndConditions();
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
