import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/cities_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';

class CitiesRepository with ConnectivityMixin {
  final CitiesService _service;

  CitiesRepository({required CitiesService service}) : _service = service;

  Future<Either<Failure<DioExceptionType>, List<CitiesResponse>>> call(
    int request,
  ) async {
    if (await isInConnection()) {
      try {
        final client = await _service(request);

        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message:
                  'Se presentó un error en el servicio. Por favor, intente más tarde.',
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
