import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/garnishments_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class GarnishmentsRepository with ConnectivityMixin {
  final GarnishmentsService _garnishmentsService;

  GarnishmentsRepository({required GarnishmentsService garnishmentsService})
    : _garnishmentsService = garnishmentsService;

  Future<
    Either<Failure<DioExceptionType>, List<GarnishmentsCertificateResponse>>
  >
  garnishmentslist(GarnishmentRequest request) async {
    if (await isInConnection()) {
      try {
        final client = await _garnishmentsService.call(request);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
