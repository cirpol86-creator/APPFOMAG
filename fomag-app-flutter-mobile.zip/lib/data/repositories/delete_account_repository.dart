import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/delete_account_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';

class DeleteAccountRepository with ConnectivityMixin {
  final DeleteAccountService _deleteAccountService;

  DeleteAccountRepository({required DeleteAccountService deleteAccountService})
    : _deleteAccountService = deleteAccountService;

  Future<Either<Failure<DioExceptionType>, DeleteAccountResponse>>
  deleteAccount() async {
    if (await isInConnection()) {
      try {
        final client = await _deleteAccountService.deleteAccount();
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
