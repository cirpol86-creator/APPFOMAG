import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/confirm_forgot_password_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class ConfirmForgotPasswordRepository with ConnectivityMixin {
  final ConfirmForgotPasswordService _service;

  ConfirmForgotPasswordRepository({
    required ConfirmForgotPasswordService service,
  }) : _service = service;

  Future<Either<Failure<DioExceptionType>, ConfirmForgotPasswordResponse>>
  confirmForgotPassword(ConfirmForgotPasswordRequest request) async {
    if (await isInConnection()) {
      try {
        final client = await _service(request);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
