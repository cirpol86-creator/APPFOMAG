import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/contact_services.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';

class ContactRepository with ConnectivityMixin {
  final ContactService _contactService;

  ContactRepository({required ContactService contactService})
    : _contactService = contactService;

  Future<Either<Failure<DioExceptionType>, List<ContentResponse>>>
  getContactList() async {
    if (await isInConnection()) {
      try {
        final result = await _contactService.getContacts();
        return Right(result);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: 'No se pudo conectar al servidor. Intenta más tarde.',
              data: e.type,
            ),
          );
        }

        return Left(
          ServerFailure(
            message: e.message ?? 'Error desconocido',
            data: e.type,
          ),
        );
      }
    }
    return const Left(NoConnectionFailure());
  }
}
