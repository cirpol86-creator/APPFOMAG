import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';

import 'package:fomagapp/core/network/services/abstract/banner_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';

class BannerRepository with ConnectivityMixin {
  final BannerService _bannerService;

  BannerRepository({required BannerService bannerService})
    : _bannerService = bannerService;

  Future<Either<Failure<DioExceptionType>, BannerResponse>> getBanner() async {
    if (await isInConnection()) {
      try {
        final result = await _bannerService.getBanner();
        return Right(result);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: 'No se pudo conectar al servidor. Intenta más tarde.',
              data: e.type,
            ),
          );
        }

        return Left(
          ServerFailure(
            message: e.message ?? 'Error desconocido',
            data: e.type,
          ),
        );
      }
    }
    return const Left(NoConnectionFailure());
  }
}
