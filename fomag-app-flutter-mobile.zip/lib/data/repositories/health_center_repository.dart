import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/health_center_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';

class HealthCenterRepository with ConnectivityMixin {
  final HealthCenterService _healthCenterService;

  HealthCenterRepository({required HealthCenterService healthCenterService})
    : _healthCenterService = healthCenterService;

  Future<Either<Failure<DioExceptionType>, List<HealthCenterResponse>>>
  getHealthCenters(int request) async {
    if (await isInConnection()) {
      try {
        final client = await _healthCenterService(request);

        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message:
                  'Se presentó un error en el servicio. Por favor, intente más tarde.',
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
