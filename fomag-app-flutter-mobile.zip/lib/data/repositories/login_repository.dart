import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/login_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class LoginRepository with ConnectivityMixin {
  final LoginService _login;

  LoginRepository({required LoginService login}) : _login = login;

  Future<Either<Failure<DioExceptionType>, AuthResponse>> login(
    LoginRequest loginRequest,
  ) async {
    if (await isInConnection()) {
      try {
        final client = await _login.call(loginRequest);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
