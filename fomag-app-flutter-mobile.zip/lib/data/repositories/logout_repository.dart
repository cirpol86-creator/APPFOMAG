import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/logout_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';

class LogoutRepository with ConnectivityMixin {
  final LogoutService _service;

  LogoutRepository({required LogoutService service}) : _service = service;

  Future<Either<Failure<DioExceptionType>, void>> call(
    LogoutRequest request,
  ) async {
    if (await isInConnection()) {
      try {
        final client = await _service(request);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
