import 'package:fomagapp/core/analytics/analytics_service.dart';
import 'package:fomagapp/data/model/user_event_model.dart';

class AnalyticsRepository {
  final AnalyticsService analyticsService;

  AnalyticsRepository({required this.analyticsService});

  Future<void> logEvent(UserEventModel event) async {
    await analyticsService.sendEvent(event);
  }
}
