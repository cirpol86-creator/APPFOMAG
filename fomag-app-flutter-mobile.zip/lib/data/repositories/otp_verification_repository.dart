import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/otp_validate_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class OtpVerificationRepository with ConnectivityMixin {
  final OtpValidateService _service;

  OtpVerificationRepository({required OtpValidateService service})
    : _service = service;

  Future<Either<Failure<DioExceptionType>, OtpValidateResponse>>
  otpVerification(OtpValidateRequest request) async {
    if (await isInConnection()) {
      try {
        final client = await _service.call(request);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      } on Exception catch (e, stackTrace) {
        if (kDebugMode) {
          log(e.toString(), stackTrace: stackTrace, name: 'Error');
        }

        return Left(
          ServerFailure(message: 'Se presentó un error en la aplicación.'),
        );
      }
    }
    return const Left(NoConnectionFailure());
  }
}
