import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/departments_health_center_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';

class DepartmentsHealthCenterRepository with ConnectivityMixin {
  final DepartmentsHealthCenterService _service;

  DepartmentsHealthCenterRepository({
    required DepartmentsHealthCenterService service,
  }) : _service = service;

  Future<
    Either<Failure<DioExceptionType>, List<DepartmentsHealthCenterResponse>>
  >
  call() async {
    if (await isInConnection()) {
      try {
        final client = await _service();

        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message:
                  'Se presentó un error en el servicio. Por favor, intente más tarde.',
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
