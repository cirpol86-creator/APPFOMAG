import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/news_by_id_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class NewsByIdRepository with ConnectivityMixin {
  final NewsByIdService _service;

  NewsByIdRepository({required NewsByIdService service}) : _service = service;

  Future<Either<Failure<DioExceptionType>, NewsByIdResponse>> newsById(
    int uuid,
  ) async {
    if (await isInConnection()) {
      try {
        final client = await _service.call(uuid);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
