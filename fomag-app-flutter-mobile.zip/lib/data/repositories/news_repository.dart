import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/news_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class NewsRepository with ConnectivityMixin {
  final NewsService _service;

  NewsRepository({required NewsService service}) : _service = service;

  Future<Either<Failure<DioExceptionType>, NewsResponse>> news() async {
    if (await isInConnection()) {
      try {
        final client = await _service();
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
