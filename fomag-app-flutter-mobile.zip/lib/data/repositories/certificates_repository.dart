import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/certificate_service.dart';
import 'package:fomagapp/core/network/services/abstract/payment_interest_certificate_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class CertificatesRepository with ConnectivityMixin {
  final CertificateService _certificateService;
  final PaymentInterestCertificateService _paymentInterestCertificateService;

  CertificatesRepository({
    required CertificateService certificateService,
    required PaymentInterestCertificateService
    paymentInterestCertificateService,
  }) : _certificateService = certificateService,
       _paymentInterestCertificateService = paymentInterestCertificateService;

  Future<Either<Failure<DioExceptionType>, CertificateTypeResponse>>
  getCertificatesType() async {
    if (await isInConnection()) {
      try {
        final client = await _certificateService.call();
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }

  Future<Either<Failure<DioExceptionType>, CertificateResponse>>
  generateCertificate(String path, Map<String, dynamic> entries) async {
    if (await isInConnection()) {
      try {
        final client = await _certificateService.generateCertificate(
          path,
          entries,
        );

        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }

    return const Left(NoConnectionFailure());
  }

  Future<Either<Failure<DioExceptionType>, List<String?>>>
  getPayInterestCertificate(PayInterestCertificateRequest request) async {
    if (await isInConnection()) {
      try {
        final client = await _paymentInterestCertificateService.call(request);

        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }

    return const Left(NoConnectionFailure());
  }
}
