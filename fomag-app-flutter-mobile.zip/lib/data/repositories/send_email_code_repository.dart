import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/send_email_code_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class SendEmailCodeRepository with ConnectivityMixin {
  final SendEmailCodeService _sendEmailCode;

  SendEmailCodeRepository({required SendEmailCodeService sendEmailCode})
    : _sendEmailCode = sendEmailCode;

  Future<Either<Failure<DioExceptionType>, ForgotPasswordResponse>>
  sendEmailCode(EmailCodeRequest emailCodeRequest) async {
    if (await isInConnection()) {
      try {
        final client = await _sendEmailCode.call(emailCodeRequest);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
