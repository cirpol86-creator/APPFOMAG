import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/register_service.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class RegisterRepository with ConnectivityMixin {
  final RegisterService _register;

  RegisterRepository({required RegisterService register})
    : _register = register;

  Future<Either<Failure<DioExceptionType>, RegisterResponse>> register(
    RegisterRequest registerRequest,
  ) async {
    if (await isInConnection()) {
      try {
        final client = await _register.call(registerRequest);
        return Right(client);
      } on DioException catch (e) {
        if (e.type == DioExceptionType.connectionError) {
          return Left(
            ServerFailure(
              message: Const.defaultMessageErrorServer,
              data: e.type,
            ),
          );
        }

        return Left(ServerFailure(message: e.message.toString(), data: e.type));
      }
    }
    return const Left(NoConnectionFailure());
  }
}
