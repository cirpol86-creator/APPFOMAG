import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:fomagapp/data/model/education_secretaries_model.dart';

class SecretaryRepository {
  List<SecretaryModel> _secretarias = [];

  Future<void> loadSecretarias() async {
    final jsonString = await rootBundle.loadString(
      'assets/files/secretaries.json',
    );

    final List<dynamic> jsonList = json.decode(jsonString);
    _secretarias = jsonList.map((e) => SecretaryModel.fromJson(e)).toList();
  }

  List<SecretaryModel> getSecretarias({
    required int page,
    int pageSize = 20,
    String? query,
  }) {
    List<SecretaryModel> filteredList = _secretarias;
    if (query != null && query.isNotEmpty) {
      filteredList =
          _secretarias
              .where(
                (s) => s.nombre.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    }

    final startIndex = (page - 1) * pageSize;
    final endIndex = startIndex + pageSize;

    if (startIndex >= filteredList.length) return [];

    return filteredList.sublist(
      startIndex,
      endIndex > filteredList.length ? filteredList.length : endIndex,
    );
  }

  int get totalPages => (_secretarias.length / 20).ceil();
}
