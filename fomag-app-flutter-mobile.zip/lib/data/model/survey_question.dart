class SurveyQuestion {
  final String question;
  final List<String> options;
  int? selectedOption;

  SurveyQuestion({
    required this.question,
    required this.options,
    this.selectedOption,
  });

  static List<SurveyQuestion> getSampleQuestions() {
    return [
      SurveyQuestion(
        question: "¿Con qué frecuencia realizas actividad física?",
        options: [
          "Diariamente",
          "2-3 veces por semana",
          "1 vez por semana",
          "Raramente",
          "Nunca",
        ],
      ),
      SurveyQuestion(
        question: "¿Cuál es tu principal objetivo al hacer ejercicio?",
        options: [
          "Perder peso",
          "Ganar masa muscular",
          "Mejorar la salud",
          "Reducir el estrés",
          "Mantener la forma física",
        ],
      ),
      SurveyQuestion(
        question: "¿Cuánto tiempo dedicas a cada sesión de ejercicio?",
        options: [
          "Menos de 30 minutos",
          "30-45 minutos",
          "45-60 minutos",
          "Más de 60 minutos",
        ],
      ),
      SurveyQuestion(
        question: "¿Qué tipo de ejercicio prefieres?",
        options: [
          "Cardio",
          "Entrenamiento de fuerza",
          "Yoga/Pilates",
          "Deportes",
          "Mezcla de varios",
        ],
      ),
      SurveyQuestion(
        question: "¿Cuál es tu nivel de experiencia en el ejercicio?",
        options: ["Principiante", "Intermedio", "Avanzado", "Profesional"],
      ),
    ];
  }
}
