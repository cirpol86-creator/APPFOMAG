import 'package:json_annotation/json_annotation.dart';

part 'certificate_response.g.dart';

@JsonSerializable(explicitToJson: true)
class CertificateResponse {
  final String? url;

  @JsonKey(name: 'IsSucessfull')
  final bool? isSuccess;

  CertificateResponse(this.isSuccess, this.url);

  factory CertificateResponse.fromJson(Map<String, dynamic> json) =>
      _$CertificateResponseFromJson(json);

  Map<String, dynamic> toJson() => _$CertificateResponseToJson(this);
}
