import 'package:json_annotation/json_annotation.dart';

part 'departments_health_center_respnse.g.dart';

@JsonSerializable()
class DepartmentsHealthCenterResponse {
  @JsonKey(name: 'id')
  final int id;

  @JsonKey(name: 'name')
  final String name;

  DepartmentsHealthCenterResponse({required this.id, required this.name});

  factory DepartmentsHealthCenterResponse.fromJson(Map<String, dynamic> json) =>
      _$DepartmentsHealthCenterResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$DepartmentsHealthCenterResponseToJson(this);

  static List<DepartmentsHealthCenterResponse> get getDepartments => [
    DepartmentsHealthCenterResponse(id: 1, name: 'Departamento 1'),
    DepartmentsHealthCenterResponse(id: 2, name: 'Departamento 2'),
  ];
}
