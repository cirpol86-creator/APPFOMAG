import 'package:json_annotation/json_annotation.dart';

part 'news_response.g.dart';

@JsonSerializable()
class NewsResponse {
  @JsonKey(name: 'httpCode')
  final int httpCode;
  @JsonKey(name: 'message')
  final String message;
  @JsonKey(name: 'content')
  final List<NewsContent> content;

  NewsResponse({this.httpCode = 0, this.message = '', this.content = const []});

  factory NewsResponse.fromJson(Map<String, dynamic> json) =>
      _$NewsResponseFromJson(json);

  Map<String, dynamic> toJson() => _$NewsResponseToJson(this);
}

@JsonSerializable()
class NewsContent {
  @JsonKey(name: 'id')
  final int id;
  @JsonKey(name: 'title')
  final String title;
  @JsonKey(name: 'imagebanner')
  final String imageBanner;
  @JsonKey(name: 'idReference')
  final int idReference;
  @JsonKey(name: 'body')
  final String body;
  @JsonKey(name: 'date')
  final String date;

  NewsContent({
    this.id = 0,
    this.title = '',
    this.imageBanner = '',
    this.idReference = 0,
    this.body = '',
    this.date = '',
  });

  factory NewsContent.fromJson(Map<String, dynamic> json) =>
      _$NewsContentFromJson(json);

  Map<String, dynamic> toJson() => _$NewsContentToJson(this);
}
