import 'package:json_annotation/json_annotation.dart';
part 'generic_response.g.dart';

@JsonSerializable(explicitToJson: true, genericArgumentFactories: true)
class GenericResponse<T> {
  const GenericResponse({this.message = '', this.data, this.content});

  @JsonKey(name: 'message')
  final String? message;

  @JsonKey(name: 'data')
  final T? data;

  @JsonKey(name: 'content')
  final T? content;

  factory GenericResponse.fromJson(
    Map<String, dynamic> json,
    T Function(Object? json) fromJsonT,
  ) => _$GenericResponseFromJson<T>(json, fromJsonT);

  Map<String, dynamic> toJson(Object? Function(T) toJsonT) =>
      _$GenericResponseToJson<T>(this, toJsonT);
}
