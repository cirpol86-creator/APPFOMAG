import 'package:json_annotation/json_annotation.dart';

part 'cities_response.g.dart';

@JsonSerializable()
class CitiesResponse {
  @JsonKey(name: 'id')
  final int id;

  @JsonKey(name: 'name')
  final String name;

  @JsonKey(name: 'department')
  final int departmentId;

  CitiesResponse({
    required this.id,
    required this.name,
    required this.departmentId,
  });

  factory CitiesResponse.fromJson(Map<String, dynamic> json) =>
      _$CitiesResponseFromJson(json);

  Map<String, dynamic> toJson() => _$CitiesResponseToJson(this);
}
