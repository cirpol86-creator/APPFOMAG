import 'package:json_annotation/json_annotation.dart';

part 'department_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DepartmentResponse {
  const DepartmentResponse({
    required this.state,
    required this.capitalCity,
    required this.cities,
  });

  @JsonKey(name: 'departamento')
  final String state;

  @JsonKey(name: 'capital')
  final String capitalCity;

  @JsonKey(name: 'municipios')
  final List<String> cities;

  factory DepartmentResponse.fromJson(Map<String, dynamic> json) =>
      _$DepartmentResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DepartmentResponseToJson(this);
}
