// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AuthResponse _$AuthResponseFromJson(Map<String, dynamic> json) => AuthResponse(
  challenge: $enumDecodeNullable(_$ChallengeEnumMap, json['challenge']),
  session: json['session'] as String?,
  challengeName: json['challengeName'] as String?,
  userName: json['userName'] as String?,
  idToken: json['id_token'] as String?,
  accessToken: json['access_token'] as String?,
  refreshToken: json['refresh_token'] as String?,
  message: json['message'] as String?,
);

Map<String, dynamic> _$AuthResponseToJson(AuthResponse instance) =>
    <String, dynamic>{
      'challenge': _$ChallengeEnumMap[instance.challenge],
      'session': instance.session,
      'challengeName': instance.challengeName,
      'userName': instance.userName,
      'id_token': instance.idToken,
      'access_token': instance.accessToken,
      'refresh_token': instance.refreshToken,
      'message': instance.message,
    };

const _$ChallengeEnumMap = {
  Challenge.mfaRequired: 'MFA_REQUIRED',
  Challenge.passwordRequired: 'PASSWORD_REQUIRED',
  Challenge.resetPasswordRequired: 'RESET_PASSWORD_REQUIRED',
};
