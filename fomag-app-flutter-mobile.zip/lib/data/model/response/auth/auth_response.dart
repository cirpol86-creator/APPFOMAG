import 'package:json_annotation/json_annotation.dart';

part 'auth_response.g.dart';

@JsonEnum()
enum Challenge {
  @JsonValue('MFA_REQUIRED')
  mfaRequired,
  @JsonValue('PASSWORD_REQUIRED')
  passwordRequired,
  @JsonValue('RESET_PASSWORD_REQUIRED')
  resetPasswordRequired;

  static Challenge? fromString(String? value) {
    switch (value) {
      case 'MFA_REQUIRED':
        return Challenge.mfaRequired;
      case 'PASSWORD_REQUIRED':
        return Challenge.passwordRequired;
      case 'RESET_PASSWORD_REQUIRED':
        return Challenge.resetPasswordRequired;
      default:
        return null;
    }
  }
}

extension ChallengeExtension on Challenge {
  String get value {
    switch (this) {
      case Challenge.mfaRequired:
        return 'MFA_REQUIRED';
      case Challenge.passwordRequired:
        return 'PASSWORD_REQUIRED';
      case Challenge.resetPasswordRequired:
        return 'RESET_PASSWORD_REQUIRED';
    }
  }
}

@JsonSerializable(explicitToJson: true)
class AuthResponse {
  const AuthResponse({
    this.challenge,
    this.session,
    this.challengeName,
    this.userName,
    this.idToken,
    this.accessToken,
    this.refreshToken,
    this.message,
  });

  @JsonKey(name: 'challenge')
  final Challenge? challenge;

  @JsonKey(name: 'session')
  final String? session;

  @JsonKey(name: 'challengeName')
  final String? challengeName;

  @JsonKey(name: 'userName')
  final String? userName;

  @JsonKey(name: 'id_token')
  final String? idToken;

  @JsonKey(name: 'access_token')
  final String? accessToken;

  @JsonKey(name: 'refresh_token')
  final String? refreshToken;

  @JsonKey(name: 'message')
  final String? message;

  /// ✅ Constructor personalizado con lógica de fallback
  factory AuthResponse.fromJson(Map<String, dynamic> json) {
    String? resolveIdToken(String? value) {
      if (value != null && value.isNotEmpty) return value;
      return json['idToken'] as String?;
    }

    String? resolveAccessToken(String? value) {
      if (value != null && value.isNotEmpty) return value;
      return json['accessToken'] as String?;
    }

    String? resolveRefreshToken(String? value) {
      if (value != null && value.isNotEmpty) return value;
      return json['refreshToken'] as String?;
    }

    return AuthResponse(
      challenge: Challenge.fromString(json['challenge'] as String?),
      session: json['session'] as String?,
      challengeName: json['challengeName'] as String?,
      userName: json['userName'] as String?,
      idToken: resolveIdToken(json['id_token'] as String?),
      accessToken: resolveAccessToken(json['access_token'] as String?),
      refreshToken: resolveRefreshToken(json['refresh_token'] as String?),
      message: json['message'] as String?,
    );
  }

  /// Usa el generado para convertir a JSON
  Map<String, dynamic> toJson() => _$AuthResponseToJson(this);
}
