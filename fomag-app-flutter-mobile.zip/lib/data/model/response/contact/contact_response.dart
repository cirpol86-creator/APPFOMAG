import 'package:fomagapp/presentation/contact/widgets/coordinate_parser.dart';
import 'package:json_annotation/json_annotation.dart';

part 'contact_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ContactResponse {
  @JsonKey(name: 'httpCode')
  final int code;

  @JsonKey(name: 'message')
  final String message;

  @JsonKey(name: 'content')
  final List<ContentResponse> content;

  ContactResponse({
    required this.message,
    required this.code,
    required this.content,
  });

  factory ContactResponse.fromJson(Map<String, dynamic> json) =>
      _$ContactResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ContactResponseToJson(this);
}

@JsonSerializable(explicitToJson: true)
class ContentResponse {
  @JsonKey(name: 'id')
  final int id;

  @JsonKey(name: 'nombreCentroAtencion')
  final String nombreCentroAtencion;

  @JsonKey(name: 'ciudad')
  final String ciudad;

  @JsonKey(name: 'direccion')
  final String direccion;

  @JsonKey(name: 'telefonoContacto')
  final String telefonoContacto;

  @JsonKey(name: 'horarioAtencionPublico')
  final String horarioAtencionPublico;

  @JsonKey(name: 'latitud')
  final double latitud;

  @JsonKey(name: 'longitud')
  final double longitud;

  @JsonKey(name: 'estado')
  final int estado;

  ContentResponse({
    required this.id,
    required this.nombreCentroAtencion,
    required this.ciudad,
    required this.direccion,
    required this.telefonoContacto,
    required this.horarioAtencionPublico,
    required this.latitud,
    required this.longitud,
    required this.estado,
  });

  factory ContentResponse.fromJson(Map<String, dynamic> json) {
    final rawLat = json['latitud']?.toString() ?? '';
    final rawLng = json['longitud']?.toString() ?? '';

    return ContentResponse(
      id: json['id'] as int,
      nombreCentroAtencion: json['nombreCentroAtencion'] as String,
      ciudad: json['ciudad'] as String,
      direccion: json['direccion'] as String,
      telefonoContacto: json['telefonoContacto'] as String,
      horarioAtencionPublico: json['horarioAtencionPublico'] as String,
      latitud: parseCoordinate(rawLat),
      longitud: parseCoordinate(rawLng),
      estado: json['estado'] as int,
    );
  }

  Map<String, dynamic> toJson() => _$ContentResponseToJson(this);

  ContentResponse copyWith({
    int? id,
    String? nombreCentroAtencion,
    String? ciudad,
    String? direccion,
    String? telefonoContacto,
    String? horarioAtencionPublico,
    double? latitud,
    double? longitud,
    int? estado,
  }) {
    return ContentResponse(
      id: id ?? this.id,
      nombreCentroAtencion: nombreCentroAtencion ?? this.nombreCentroAtencion,
      ciudad: ciudad ?? this.ciudad,
      direccion: direccion ?? this.direccion,
      telefonoContacto: telefonoContacto ?? this.telefonoContacto,
      horarioAtencionPublico:
          horarioAtencionPublico ?? this.horarioAtencionPublico,
      latitud: latitud ?? this.latitud,
      longitud: longitud ?? this.longitud,
      estado: estado ?? this.estado,
    );
  }
}

parseCoordinate(String value) {
  try {
    if (value.contains(RegExp(r'[NSEW°]'))) {
      return convertDmsToDecimal(value);
    } else {
      return double.tryParse(value) ?? 0.0;
    }
  } catch (e) {
    return 0.0;
  }
}
