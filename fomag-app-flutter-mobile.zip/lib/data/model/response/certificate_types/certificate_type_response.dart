import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:json_annotation/json_annotation.dart';

part 'certificate_type_response.g.dart';

@JsonSerializable(explicitToJson: true)
class CertificateTypeResponse {
  const CertificateTypeResponse({
    required this.httpCode,
    required this.message,
    required this.content,
  });

  @JsonKey(name: 'httpCode')
  final int httpCode;

  final String message;

  final List<CertificateType> content;

  factory CertificateTypeResponse.fromJson(Map<String, dynamic> json) =>
      _$CertificateTypeResponseFromJson(json);

  Map<String, dynamic> toJson() => _$CertificateTypeResponseToJson(this);
}
