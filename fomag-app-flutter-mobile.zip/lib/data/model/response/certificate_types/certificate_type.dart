import 'package:json_annotation/json_annotation.dart';

part 'certificate_type.g.dart';

@JsonSerializable()
class CertificateType {
  const CertificateType({
    required this.id,
    required this.name,
    required this.path,
    required this.state,
  });

  @JsonKey(name: 'id')
  final int id;
  @JsonKey(name: 'nombre')
  final String name;
  @JsonKey(name: 'patch')
  final String path;
  @JsonKey(name: 'estado')
  final String state;

  bool get isHealthCertificate => id == 6;
  bool get isGarnishment => id == 12;
  bool get isPayInterest => id == 7;

  factory CertificateType.fromJson(Map<String, dynamic> json) =>
      _$CertificateTypeFromJson(json);

  Map<String, dynamic> toJson() => _$CertificateTypeToJson(this);
}
