import 'package:json_annotation/json_annotation.dart';

part 'health_center_response.g.dart';

@JsonSerializable()
class HealthCenterResponse {
  @JsonKey(name: 'id')
  final int? id;

  @JsonKey(name: 'name')
  final String? name;

  @JsonKey(name: 'address')
  final String? address;

  @JsonKey(name: 'phone')
  final String? phone1;

  @JsonKey(name: 'phone2')
  final String? phone2;

  HealthCenterResponse({
    required this.id,
    required this.name,
    required this.address,
    required this.phone1,
    required this.phone2,
  });

  factory HealthCenterResponse.fromJson(Map<String, dynamic> json) =>
      _$HealthCenterResponseFromJson(json);

  Map<String, dynamic> toJson() => _$HealthCenterResponseToJson(this);
}
