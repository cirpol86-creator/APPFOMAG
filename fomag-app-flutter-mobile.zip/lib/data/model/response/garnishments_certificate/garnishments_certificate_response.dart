import 'package:json_annotation/json_annotation.dart';

part 'garnishments_certificate_response.g.dart';

@JsonSerializable(explicitToJson: true)
class GarnishmentsCertificateResponse {
  const GarnishmentsCertificateResponse({
    this.nameCourt,
    this.natureProcess,
    this.officialEmbargo,
    this.claimantDocumentNumber,
    this.fullNameClaimant,
    this.surnameClaimant,
    this.processNumber,
    this.descriptionOfServices,
    this.consecutiveGarnishment,
    this.state,
  });

  @JsonKey(name: 'Nombre_Juzgado')
  final String? nameCourt;
  @JsonKey(name: 'Naturaleza_Proceso')
  final String? natureProcess;
  @JsonKey(name: 'Oficio_Embargo')
  final String? officialEmbargo;
  @JsonKey(name: 'Numero_Documento_Demandante')
  final String? claimantDocumentNumber;
  @JsonKey(name: 'Nombre_Completo_Demandante')
  final String? fullNameClaimant;
  @JsonKey(name: 'Apellidos_Demandante')
  final String? surnameClaimant;
  @JsonKey(name: 'Numero_Proceso')
  final String? processNumber;
  @JsonKey(name: 'Descripcion_Prestacion')
  final String? descriptionOfServices;
  @JsonKey(name: 'Consecutivo_Embargo')
  final String? consecutiveGarnishment;
  @JsonKey(name: 'Estado_Embargo')
  final String? state;

  factory GarnishmentsCertificateResponse.fromJson(Map<String, dynamic> json) =>
      _$GarnishmentsCertificateResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$GarnishmentsCertificateResponseToJson(this);
}
