import 'package:json_annotation/json_annotation.dart';

part 'news_by_id_response.g.dart';

@JsonSerializable()
class NewsByIdResponse {
  @JsonKey(name: 'httpCode')
  final int httpCode;
  @JsonKey(name: 'message')
  final String message;
  @JsonKey(name: 'content')
  final NewsByIdContent content;

  NewsByIdResponse({
    required this.httpCode,
    required this.message,
    required this.content,
  });

  factory NewsByIdResponse.fromJson(Map<String, dynamic> json) =>
      _$NewsByIdResponseFromJson(json);
  Map<String, dynamic> toJson() => _$NewsByIdResponseToJson(this);
}

@JsonSerializable()
class NewsByIdContent {
  @JsonKey(name: 'id')
  final int id;
  @JsonKey(name: 'title')
  final String title;
  @JsonKey(name: 'imagebanner')
  final String imagebanner;
  @JsonKey(name: 'idReference')
  final int idReference;
  @JsonKey(name: 'body')
  final String body;
  @JsonKey(name: 'date')
  final String date;

  NewsByIdContent({
    required this.id,
    required this.title,
    required this.imagebanner,
    required this.idReference,
    required this.body,
    required this.date,
  });

  factory NewsByIdContent.fromJson(Map<String, dynamic> json) =>
      _$NewsByIdContentFromJson(json);
  Map<String, dynamic> toJson() => _$NewsByIdContentToJson(this);
}
