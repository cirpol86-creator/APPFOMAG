import 'package:json_annotation/json_annotation.dart';
part 'register_response.g.dart';

@JsonSerializable(explicitToJson: true, genericArgumentFactories: true)
class RegisterResponse<T> {
  const RegisterResponse({this.message = ''});

  @JsonKey(name: 'message')
  final String? message;


  factory RegisterResponse.fromJson(
    Map<String, dynamic> json,
    T Function(Object? json) fromJsonT,
  ) => _$RegisterResponseFromJson<T>(json, fromJsonT);

  Map<String, dynamic> toJson(Object Function(T) toJsonT) =>
      _$RegisterResponseToJson<T>(this, toJsonT);
}