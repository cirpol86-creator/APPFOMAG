// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AccountResponse _$AccountResponseFromJson(Map<String, dynamic> json) =>
    AccountResponse(
      code: json['code'] as String? ?? '',
      data:
          json['data'] == null
              ? const AccountData()
              : AccountData.fromJson(json['data'] as Map<String, dynamic>),
      message: json['message'] as String? ?? '',
    );

Map<String, dynamic> _$AccountResponseToJson(AccountResponse instance) =>
    <String, dynamic>{
      'code': instance.code,
      'data': instance.data.toJson(),
      'message': instance.message,
    };

AccountData _$AccountDataFromJson(Map<String, dynamic> json) => AccountData(
  name: json['name'] as String? ?? '',
  documentType: json['documentType'] as String? ?? '',
  documentNumber: json['documentNumber'] as String? ?? '',
  state: json['state'] as String? ?? '',
  city: json['city'] as String? ?? '',
  typeAffiliate: json['typeAffiliate'] as String? ?? '',
  email: json['email'] as String? ?? '',
);

Map<String, dynamic> _$AccountDataToJson(AccountData instance) =>
    <String, dynamic>{
      'name': instance.name,
      'documentType': instance.documentType,
      'documentNumber': instance.documentNumber,
      'state': instance.state,
      'city': instance.city,
      'typeAffiliate': instance.typeAffiliate,
      'email': instance.email,
    };
