import 'package:json_annotation/json_annotation.dart';

part 'account_response.g.dart';

@JsonSerializable(explicitToJson: true)
class AccountResponse {
  const AccountResponse({
    this.code = '',
    this.data = const AccountData(),
    this.message = '',
  });

  @JsonKey(name: 'code')
  final String code;

  @JsonKey(name: 'data')
  final AccountData data;

  @JsonKey(name: 'message')
  final String message;

  factory AccountResponse.fromJson(Map<String, dynamic> json) =>
      _$AccountResponseFromJson(json);

  Map<String, dynamic> toJson() => _$AccountResponseToJson(this);
}

@JsonSerializable()
class AccountData {
  const AccountData({
    this.name = '',
    this.documentType = '',
    this.documentNumber = '',
    this.state = '',
    this.city = '',
    this.typeAffiliate = '',
    this.email = '',
  });

  @JsonKey(name: 'name')
  final String name;

  @JsonKey(name: 'documentType')
  final String documentType;

  @JsonKey(name: 'documentNumber')
  final String documentNumber;

  @JsonKey(name: 'state')
  final String state;

  @JsonKey(name: 'city')
  final String city;

  @JsonKey(name: 'typeAffiliate')
  final String typeAffiliate;

  @JsonKey(name: 'email')
  final String email;

  factory AccountData.fromJson(Map<String, dynamic> json) =>
      _$AccountDataFromJson(json);

  Map<String, dynamic> toJson() => _$AccountDataToJson(this);
}
