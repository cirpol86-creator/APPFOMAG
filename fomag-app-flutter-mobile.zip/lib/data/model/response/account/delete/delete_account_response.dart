import 'package:json_annotation/json_annotation.dart';

part 'delete_account_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeleteAccountResponse {
  const DeleteAccountResponse({this.message = ''});

  @JsonKey(name: 'message')
  final String message;

  factory DeleteAccountResponse.fromJson(Map<String, dynamic> json) =>
      _$DeleteAccountResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeleteAccountResponseToJson(this);
}
