import 'package:json_annotation/json_annotation.dart';

part 'banner_response.g.dart';

@JsonSerializable(explicitToJson: true)
class BannerResponse {
  @JsonKey(name: 'message')
  final String message;
  @JsonKey(name: 'type')
  final String type;
  @JsonKey(name: 'url')
  final String url;

  BannerResponse({
    required this.message,
    required this.type,
    required this.url,
  });

  factory BannerResponse.fromJson(Map<String, dynamic> json) =>
      _$BannerResponseFromJson(json);

  Map<String, dynamic> toJson() => _$BannerResponseToJson(this);
}
