import 'package:json_annotation/json_annotation.dart';

part 'confirm_forgot_password_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ConfirmForgotPasswordResponse {
  @JsonKey(name: 'message')
  final String message;

  ConfirmForgotPasswordResponse({required this.message});

  factory ConfirmForgotPasswordResponse.fromJson(Map<String, dynamic> json) =>
      _$ConfirmForgotPasswordResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ConfirmForgotPasswordResponseToJson(this);
}
