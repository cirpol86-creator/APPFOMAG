// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_validate_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OtpValidateResponse _$OtpValidateResponseFromJson(Map<String, dynamic> json) =>
    OtpValidateResponse(
      accessToken: json['access_token'] as String,
      idToken: json['id_token'] as String,
      refreshToken: json['refresh_token'] as String,
    );

Map<String, dynamic> _$OtpValidateResponseToJson(
  OtpValidateResponse instance,
) => <String, dynamic>{
  'access_token': instance.accessToken,
  'id_token': instance.idToken,
  'refresh_token': instance.refreshToken,
};

GenericOtpResponse<T> _$GenericOtpResponseFromJson<T>(
  Map<String, dynamic> json,
  T Function(Object? json) fromJsonT,
) => GenericOtpResponse<T>(message: fromJsonT(json['message']));

Map<String, dynamic> _$GenericOtpResponseToJson<T>(
  GenericOtpResponse<T> instance,
  Object? Function(T value) toJsonT,
) => <String, dynamic>{'message': toJsonT(instance.message)};
