import 'package:json_annotation/json_annotation.dart';

part 'otp_validate_response.g.dart';

@JsonSerializable(explicitToJson: true)
class OtpValidateResponse {
  const OtpValidateResponse({
    required this.accessToken,
    required this.idToken,
    required this.refreshToken,
  });

  @JsonKey(name: 'access_token')
  final String accessToken;

  @JsonKey(name: 'id_token')
  final String idToken;

  @JsonKey(name: 'refresh_token')
  final String refreshToken;

  factory OtpValidateResponse.fromJson(Map<String, dynamic> json) =>
      _$OtpValidateResponseFromJson(json);

  Map<String, dynamic> toJson(OtpValidateResponse? instance) =>
      _$OtpValidateResponseToJson(instance ?? this);
}

@JsonSerializable(explicitToJson: true, genericArgumentFactories: true)
class GenericOtpResponse<T> {
  const GenericOtpResponse({required this.message});

  @JsonKey(name: 'message')
  final T message;

  factory GenericOtpResponse.fromJson(
    Map<String, dynamic> json,
    T Function(Object? json) fromJsonT,
  ) => _$GenericOtpResponseFromJson(json, fromJsonT);

  Map<String, dynamic> toJson(Map<String, dynamic> Function(T) toJsonT) =>
      _$GenericOtpResponseToJson(this, toJsonT);
}
