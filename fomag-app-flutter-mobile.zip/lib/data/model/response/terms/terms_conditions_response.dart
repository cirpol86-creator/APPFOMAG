// import 'package:json_annotation/json_annotation.dart';

// part 'terms_conditions_response.g.dart';

// @JsonSerializable()
// class TermsConditionsResponse {
//   @JsonKey(name: 'httpCode')
//   final int httpCode;
//   @JsonKey(name: 'message')
//   final String message;
//   @JsonKey(name: 'content')
//   final List<NewsContent> content;

//   NewsResponse({this.httpCode = 0, this.message = '', this.content = const []});

//   factory NewsResponse.fromJson(Map<String, dynamic> json) =>
//       _$NewsResponseFromJson(json);

//   Map<String, dynamic> toJson() => _$NewsResponseToJson(this);
// }
