class TypesDocuments {
  final String id;
  final String name;

  TypesDocuments({required this.id, required this.name});

  static final List<TypesDocuments> typesDocuments = [
    TypesDocuments(id: '3', name: 'Cédula de Ciudadanía'),
    TypesDocuments(id: '2', name: 'Tarjeta de Identidad'),
    TypesDocuments(id: '5', name: 'Cédula de Extranjería'),
    TypesDocuments(id: '8', name: 'Pasaporte'),
    TypesDocuments(id: '7', name: 'NIT'),
    TypesDocuments(id: '1', name: 'Registro civil'),
    TypesDocuments(id: '4', name: 'Cédula Digital'),
  ];

  static TypesDocuments? getByName(String name) {
    final types = typesDocuments.where((element) => element.name == name);

    return types.firstOrNull;
  }
}
