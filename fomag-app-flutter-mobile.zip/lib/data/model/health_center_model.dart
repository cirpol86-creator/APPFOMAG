import 'package:flutter/material.dart';

class HealthCenterModel {
  final String title;
  final String address;
  final String description;
  final String imageUrl;
  final VoidCallback onTap;

  const HealthCenterModel({
    required this.title,
    required this.address,
    required this.description,
    required this.imageUrl,
    required this.onTap,
  });

  static List<HealthCenterModel> get healthCenterList => [
        HealthCenterModel(
          title: 'Centro de Salud Norte',
          address: 'Calle 123 #45-67',
          description: 'Atención médica general y especializada',
          imageUrl: 'https://www.sedputumayo.gov.co/images/2023/05/19/fomag.jpeg',
          onTap: () {},
        ),
        HealthCenterModel(
          title: 'Centro de Salud Sur',
          address: 'Carrera 78 #90-12',
          description: 'Servicios de urgencias 24/7',
          imageUrl: 'https://sedfacatativa.gov.co/wp-content/uploads/2023/02/Asesoria-virtual-FOMAG_Fomag-1024x1006.jpg',
          onTap: () {},
        ),
        HealthCenterModel(
          title: 'Centro de Salud Este',
          address: 'Avenida 34 #56-78',
          description: 'Especialistas y laboratorio clínico',
          imageUrl: 'https://aproteco.org/wp-content/uploads/2024/07/fomag-salud-1024x537.png',
          onTap: () {},
        ),
        HealthCenterModel(
          title: 'Centro de Salud Oeste',
          address: 'Calle 90 #12-34',
          description: 'Medicina preventiva y vacunación',
          imageUrl: 'https://client-setting-co-institucional-images.s3.amazonaws.com/creditos_para_pensionados_70c4a9d625.webp',
          onTap: () {},
        ),
      ];
} 