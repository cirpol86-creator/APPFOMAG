import 'package:fomagapp/data/model/response/news/news_response.dart';

class CarouselCardData {
  final int id;
  final String imageUrl;
  final String title;

  CarouselCardData({
    required this.imageUrl,
    required this.title,
    required this.id,
  });

  static List<CarouselCardData> getCarouselCardDataByNewsContent(
    List<NewsContent> newsList,
  ) {
    return newsList.map((news) {
      return CarouselCardData(
        imageUrl: news.imageBanner,
        title: news.title,
        id: news.id,
      );
    }).toList();
  }
}
