class DeleteAccountModel {
  final String title;
  final String message;

  DeleteAccountModel({required this.title, required this.message});
}
