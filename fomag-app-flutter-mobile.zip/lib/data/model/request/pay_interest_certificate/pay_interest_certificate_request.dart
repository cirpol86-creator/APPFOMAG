import 'package:json_annotation/json_annotation.dart';

part 'pay_interest_certificate_request.g.dart';

@JsonSerializable(explicitToJson: true)
class PayInterestCertificateRequest {
  const PayInterestCertificateRequest({
    this.documentNumber = '',
    this.vinculacionType = '',
  });

  @JsonKey(name: 'numeroIdentificacion')
  final String documentNumber;

  @JsonKey(name: 'vinculacion')
  final String vinculacionType;

  factory PayInterestCertificateRequest.fromJson(Map<String, dynamic> json) =>
      _$PayInterestCertificateRequestFromJson(json);

  Map<String, dynamic> toJson() => _$PayInterestCertificateRequestToJson(this);
}
