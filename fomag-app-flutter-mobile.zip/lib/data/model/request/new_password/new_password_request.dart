import 'package:json_annotation/json_annotation.dart';

part 'new_password_request.g.dart';

@JsonSerializable(explicitToJson: true)
class NewPasswordRequest {
  const NewPasswordRequest({this.password = 0});

  @JsonKey(name: 'password')
  final int password;

  factory NewPasswordRequest.fromJson(Map<String, dynamic> json) =>
      _$NewPasswordRequestFromJson(json);

  Map<String, dynamic> toJson() => _$NewPasswordRequestToJson(this);
}
