// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'new_password_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NewPasswordRequest _$NewPasswordRequestFromJson(Map<String, dynamic> json) =>
    NewPasswordRequest(password: (json['password'] as num?)?.toInt() ?? 0);

Map<String, dynamic> _$NewPasswordRequestToJson(NewPasswordRequest instance) =>
    <String, dynamic>{'password': instance.password};
