import 'package:json_annotation/json_annotation.dart';

part 'garnishment_request.g.dart';

@JsonSerializable(explicitToJson: true)
class GarnishmentRequest {
  const GarnishmentRequest({this.documentType = '', this.documentNumber = ''});

  @JsonKey(name: 'tipoIdentificacion')
  final String documentType;

  @JsonKey(name: 'numeroIdentificacion')
  final String documentNumber;

  Map<String, dynamic> toJson() => _$GarnishmentRequestToJson(this);
}
