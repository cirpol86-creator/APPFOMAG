// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_code_password_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OtpCodePasswordRequest _$OtpCodePasswordRequestFromJson(
  Map<String, dynamic> json,
) => OtpCodePasswordRequest(code: (json['code'] as num?)?.toInt() ?? 0);

Map<String, dynamic> _$OtpCodePasswordRequestToJson(
  OtpCodePasswordRequest instance,
) => <String, dynamic>{'code': instance.code};
