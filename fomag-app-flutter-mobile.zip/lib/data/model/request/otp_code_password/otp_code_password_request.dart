import 'package:json_annotation/json_annotation.dart';

part 'otp_code_password_request.g.dart';

@JsonSerializable(explicitToJson: true)
class OtpCodePasswordRequest {
  const OtpCodePasswordRequest({this.code = 0});

  @JsonKey(name: 'code')
  final int code;

  factory OtpCodePasswordRequest.fromJson(Map<String, dynamic> json) =>
      _$OtpCodePasswordRequestFromJson(json);

  Map<String, dynamic> toJson() => _$OtpCodePasswordRequestToJson(this);
}
