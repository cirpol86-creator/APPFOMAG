import 'package:json_annotation/json_annotation.dart';

part 'confirm_forgot_password_request.g.dart';

@JsonSerializable(explicitToJson: true)
class ConfirmForgotPasswordRequest {
  @JsonKey(name: 'documentType')
  final String documentType;

  @JsonKey(name: 'documentNumber')
  final String documentNumber;

  @JsonKey(name: 'password')
  final String password;

  @JsonKey(name: 'code')
  final String code;

  ConfirmForgotPasswordRequest({
    required this.documentType,
    required this.documentNumber,
    required this.password,
    required this.code,
  });

  factory ConfirmForgotPasswordRequest.fromJson(Map<String, dynamic> json) =>
      _$ConfirmForgotPasswordRequestFromJson(json);

  Map<String, dynamic> toJson() => _$ConfirmForgotPasswordRequestToJson(this);
}
