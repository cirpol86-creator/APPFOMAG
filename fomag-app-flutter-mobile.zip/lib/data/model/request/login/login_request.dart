import 'package:json_annotation/json_annotation.dart';

part 'login_request.g.dart';

@JsonSerializable(explicitToJson: true)
class LoginRequest {
  const LoginRequest({
    this.documentType = '',
    this.documentNumber = '',
    this.password = '',
  });

  @JsonKey(name: 'documentType')
  final String documentType;

  @JsonKey(name: 'documentNumber')
  final String documentNumber;

  @JsonKey(name: 'password')
  final String password;

  factory LoginRequest.fromJson(Map<String, dynamic> json) =>
      _$LoginRequestFromJson(json);

  Map<String, dynamic> toJson() => _$LoginRequestToJson(this);
}
