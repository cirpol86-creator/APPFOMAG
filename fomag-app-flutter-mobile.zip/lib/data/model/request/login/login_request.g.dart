// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LoginRequest _$LoginRequestFromJson(Map<String, dynamic> json) => LoginRequest(
  documentType: json['documentType'] as String? ?? '',
  documentNumber: json['documentNumber'] as String? ?? '',
  password: json['password'] as String? ?? '',
);

Map<String, dynamic> _$LoginRequestToJson(LoginRequest instance) =>
    <String, dynamic>{
      'documentType': instance.documentType,
      'documentNumber': instance.documentNumber,
      'password': instance.password,
    };
