// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'email_code_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EmailCodeRequest _$EmailCodeRequestFromJson(Map<String, dynamic> json) =>
    EmailCodeRequest(
      typeDocument: json['documentType'] as String? ?? '',
      documentNumber: json['documentNumber'] as String? ?? '',
    );

Map<String, dynamic> _$EmailCodeRequestToJson(EmailCodeRequest instance) =>
    <String, dynamic>{
      'documentType': instance.typeDocument,
      'documentNumber': instance.documentNumber,
    };
