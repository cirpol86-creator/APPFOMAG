import 'package:json_annotation/json_annotation.dart';

part 'email_code_request.g.dart';

@JsonSerializable(explicitToJson: true)
class EmailCodeRequest {
  const EmailCodeRequest({this.typeDocument = '', this.documentNumber = ''});

  @JsonKey(name: 'documentType')
  final String typeDocument;

  @JsonKey(name: 'documentNumber')
  final String documentNumber;

  factory EmailCodeRequest.fromJson(Map<String, dynamic> json) =>
      _$EmailCodeRequestFromJson(json);

  Map<String, dynamic> toJson() => _$EmailCodeRequestToJson(this);
}
