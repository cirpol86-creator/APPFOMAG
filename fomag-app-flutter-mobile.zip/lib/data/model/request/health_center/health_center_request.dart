class HealthCenterRequest {
  final int cityId;
  final int departmentId;

  HealthCenterRequest({required this.cityId, required this.departmentId});

  Map<String, dynamic> toJson() => {
    'city_id': cityId,
    'department_id': departmentId,
  };
}
