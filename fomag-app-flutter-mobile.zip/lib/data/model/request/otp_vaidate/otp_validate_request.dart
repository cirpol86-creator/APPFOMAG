import 'package:json_annotation/json_annotation.dart';

part 'otp_validate_request.g.dart';

@JsonSerializable(explicitToJson: true)
class OtpValidateRequest {
  const OtpValidateRequest({
    required this.userName,
    required this.code,
    required this.session,
    required this.challengeType,
    this.newPassword,
  });

  @JsonKey(name: 'mfaCode')
  final String code;

  @JsonKey(name: 'userName')
  final String userName;

  @JsonKey(name: 'session')
  final String session;

  @JsonKey(name: 'challengeType')
  final String challengeType;

  @JsonKey(name: 'newPassword')
  final String? newPassword;

  factory OtpValidateRequest.fromJson(Map<String, dynamic> json) =>
      _$OtpValidateRequestFromJson(json);

  Map<String, dynamic> toJson() => _$OtpValidateRequestToJson(this);
}
