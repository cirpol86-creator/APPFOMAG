// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_validate_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OtpValidateRequest _$OtpValidateRequestFromJson(Map<String, dynamic> json) =>
    OtpValidateRequest(
      userName: json['userName'] as String,
      code: json['mfaCode'] as String,
      session: json['session'] as String,
      challengeType: json['challengeType'] as String,
      newPassword: json['newPassword'] as String?,
    );

Map<String, dynamic> _$OtpValidateRequestToJson(OtpValidateRequest instance) =>
    <String, dynamic>{
      'mfaCode': instance.code,
      'userName': instance.userName,
      'session': instance.session,
      'challengeType': instance.challengeType,
      'newPassword': instance.newPassword,
    };
