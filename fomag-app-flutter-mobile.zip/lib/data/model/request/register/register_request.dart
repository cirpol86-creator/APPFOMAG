import 'package:json_annotation/json_annotation.dart';

part 'register_request.g.dart';

@JsonSerializable(explicitToJson: true)
class RegisterRequest {
  const RegisterRequest({
    this.documentType = '',
    this.documentNumber = '',
    this.fullName = '',
    this.email = '',
    this.mobile = '',
    this.password = '',
    this.acceptanceTerms = false,
  });

  @JsonKey(name: 'documentType')
  final String documentType;

  @JsonKey(name: 'documentNumber')
  final String documentNumber;

  @JsonKey(name: 'fullName')
  final String fullName;

  @JsonKey(name: 'email')
  final String email;

  @JsonKey(name: 'mobile')
  final String mobile;

  @JsonKey(name: 'password')
  final String password;

  @JsonKey(name: 'acceptanceTerms')
  final bool acceptanceTerms;

  factory RegisterRequest.fromJson(Map<String, dynamic> json) =>
      _$RegisterRequestFromJson(json);

  Map<String, dynamic> toJson() => _$RegisterRequestToJson(this);
}
