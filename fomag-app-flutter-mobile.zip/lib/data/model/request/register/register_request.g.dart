// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'register_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RegisterRequest _$RegisterRequestFromJson(Map<String, dynamic> json) =>
    RegisterRequest(
      documentType: json['documentType'] as String? ?? '',
      documentNumber: json['documentNumber'] as String? ?? '',
      fullName: json['fullName'] as String? ?? '',
      email: json['email'] as String? ?? '',
      mobile: json['mobile'] as String? ?? '',
      password: json['password'] as String? ?? '',
      acceptanceTerms: json['acceptanceTerms'] as bool? ?? false,
    );

Map<String, dynamic> _$RegisterRequestToJson(RegisterRequest instance) =>
    <String, dynamic>{
      'documentType': instance.documentType,
      'documentNumber': instance.documentNumber,
      'fullName': instance.fullName,
      'email': instance.email,
      'mobile': instance.mobile,
      'password': instance.password,
      'acceptanceTerms': instance.acceptanceTerms,
    };
