enum UserEventType {
  appOpened('app_open'),
  login('login_screen'),
  register('register_screen'),
  home('home_screen'),
  certificates('certificates_screen'),
  deleteAccount('account_screen'),
  passwordReset('passwordReset_screen'),
  appClosed('app_close'),
  downloadCertificate('download_certificate');

  final String name;

  const UserEventType(this.name);
}

class UserEventModel {
  final UserEventType type;
  final Map<String, Object> parameters;

  UserEventModel(this.type, [this.parameters = const {}]);
}
