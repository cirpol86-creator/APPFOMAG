class SecretaryModel {
  final int id;
  final String nombre;
  final String url;

  SecretaryModel({required this.id, required this.nombre, required this.url});

  factory SecretaryModel.fromJson(Map<String, dynamic> json) {
    return SecretaryModel(
      id: json['id'],
      nombre: json['nombre'],
      url: json['url'],
    );
  }
}
