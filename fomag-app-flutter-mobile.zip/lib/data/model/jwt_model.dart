class JwtUser {
  final String? sub;
  final bool? emailVerified;
  final String? iss;
  final bool? phoneNumberVerified;
  final String? username;
  final String? originJti;
  final String? aud;
  final String? documentNumber;
  final String? eventId;
  final String? tokenUse;
  final int? authTime;
  final String? name;
  final String? phoneNumber;
  final int? exp;
  final String? roleId;
  final int? iat;
  final String? documentTypeId;
  final String? jti;
  final String? email;

  JwtUser({
    this.sub,
    this.emailVerified,
    this.iss,
    this.phoneNumberVerified,
    this.username,
    this.originJti,
    this.aud,
    this.documentNumber,
    this.eventId,
    this.tokenUse,
    this.authTime,
    this.name,
    this.phoneNumber,
    this.exp,
    this.roleId,
    this.iat,
    this.documentTypeId,
    this.jti,
    this.email,
  });

  factory JwtUser.fromJson(Map<String, dynamic> json) {
    return JwtUser(
      sub: json['sub'],
      emailVerified: json['email_verified'],
      iss: json['iss'],
      phoneNumberVerified: json['phone_number_verified'],
      username: json['cognito:username'],
      originJti: json['origin_jti'],
      aud: json['aud'],
      documentNumber: json['custom:document_number'],
      eventId: json['event_id'],
      tokenUse: json['token_use'],
      authTime: json['auth_time'],
      name: json['name'],
      phoneNumber: json['phone_number'],
      exp: json['exp'],
      roleId: json['custom:role_id'],
      iat: json['iat'],
      documentTypeId: json['custom:document_type_id'],
      jti: json['jti'],
      email: json['email'],
    );
  }
}
