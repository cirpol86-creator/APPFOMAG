import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:go_router/go_router.dart';

enum TransitionType { fade, slideRight, slideUp, none }

class NavigationController extends Equatable {
  static final globalNavigatorKey = GlobalKey<NavigatorState>();

  /// Pushes a new route.
  ///
  /// - If [clean] is `true`, it removes all back stacks after pushing.
  /// - If [replace] is `true`, it replaces the current route with the new one.
  /// If [router] is provided, it uses that router instead of the global one.
  static Future<T?> push<T extends Object>(
    String route, {
    dynamic arguments,
    bool replace = false,
    bool clean = false,
    TransitionType transition = TransitionType.fade,
    GoRouter? router,
  }) async {
    // Si no se proporciona un router explícito, usa el contexto global
    final context = globalNavigatorKey.currentContext;
    final goRouter = router ?? (context != null ? GoRouter.of(context) : null);

    if (goRouter == null) return null;

    if (clean) {
      goRouter.go(route, extra: arguments);
      return null;
    }

    if (replace) {
      return goRouter.replace(route, extra: arguments);
    }

    return goRouter.push(route, extra: arguments);
  }

  /// Handles navigation for drawer item taps.
  /// If [route] is different from home, it clears the stack until home.
  /// If [router] is provided, it uses that router instead of the global one.
  static Future<T?> drawerItemTap<T extends Object>(
    String route, {
    GoRouter? router,
  }) async {
    final context = globalNavigatorKey.currentContext;
    final goRouter = router ?? (context != null ? GoRouter.of(context) : null);

    if (goRouter == null || context == null) return null;

    // Cerramos el Drawer si está abierto
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }

    if (route == Routes.login.routePath) {
      goRouter.go(Routes.login.routePath);
      return null;
    } else {
      return goRouter.push(route);
    }
  }

  /// Pops the current route if possible.
  /// If [router] is provided, it uses that router instead of the global one.
  static void pop({GoRouter? router}) {
    final context = globalNavigatorKey.currentContext;
    final goRouter = router ?? (context != null ? GoRouter.of(context) : null);

    if (goRouter == null) return;

    if (context != null && goRouter.canPop()) {
      goRouter.pop();
    }
  }

  @override
  List<Object?> get props => [globalNavigatorKey];
}
