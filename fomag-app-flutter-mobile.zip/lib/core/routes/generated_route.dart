import 'package:equatable/equatable.dart';

import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/data/model/survey_question.dart';
import 'package:fomagapp/presentation/account/pages/account_page.dart';
import 'package:fomagapp/presentation/allied_entities/pages/allied_entities_page.dart';
import 'package:fomagapp/presentation/certificates/pages/search_certificates_page.dart';
import 'package:fomagapp/presentation/contact/pages/contact_page.dart';
import 'package:fomagapp/presentation/health/pages/health_center_page.dart';
import 'package:fomagapp/presentation/home/page/home_page.dart';
import 'package:fomagapp/presentation/list_news/page/list_news_page.dart';
import 'package:fomagapp/presentation/login/pages/login_page.dart';
import 'package:fomagapp/presentation/new_info/page/new_info_page.dart';
import 'package:fomagapp/presentation/otp_verification/pages/otp_verification_page.dart';
import 'package:fomagapp/presentation/password_reset/pages/password_reset_home.dart';
import 'package:fomagapp/presentation/password_reset/pages/password_reset_login/password_reset_login.dart';
import 'package:fomagapp/presentation/password_reset/pages/password_reset_page.dart';
import 'package:fomagapp/presentation/pqr/page/pqr_list.dart';
import 'package:fomagapp/presentation/register/pages/register_page.dart';
import 'package:fomagapp/presentation/splash/not_found_page.dart';
import 'package:fomagapp/presentation/splash/splash_page.dart';
import 'package:fomagapp/presentation/survey/survey_page.dart';
import 'package:fomagapp/presentation/suspended_account/pages/suspended_account_page.dart';
import 'package:fomagapp/presentation/theme/app_global.dart';
import 'package:fomagapp/presentation/widgets/pdf_viewer_screen.dart';
import 'package:fomagapp/presentation/widgets/screens/progress_loader_screen.dart';
import 'package:go_router/go_router.dart';

class RouterManager extends Equatable {
  static final GoRouter router = GoRouter(
    navigatorKey: NavigationController.globalNavigatorKey,
    observers: [navigationObserver],
    initialLocation: Routes.splashScreen.routePath,
    debugLogDiagnostics: true,
    routes: _routes,
    errorBuilder: (context, state) => const NotFoundPage(),
  );

  static final List<RouteBase> _routes = [
    GoRoute(
      path: Routes.splashScreen.routePath,
      name: Routes.splashScreen.routeName,
      builder: (context, state) => SplashPage(),
    ),
    GoRoute(
      path: Routes.home.routePath,
      name: Routes.home.routeName,
      builder: (context, state) => HomePage(),
    ),
    GoRoute(
      path: Routes.login.routePath,
      name: Routes.login.routeName,
      builder: (context, state) => LoginPage(),
    ),
    GoRoute(
      path: Routes.register.routePath,
      name: Routes.register.routeName,
      builder: (context, state) => RegisterPage(),
    ),
    GoRoute(
      path: Routes.passwordReset.routePath,
      name: Routes.passwordReset.routeName,
      builder: (context, state) => PasswordResetPage(),
    ),
    GoRoute(
      path: Routes.healthcenter.routePath,
      name: Routes.healthcenter.routeName,
      builder: (context, state) => HealthCenterPage(),
    ),
    GoRoute(
      path: Routes.pqr.routePath,
      name: Routes.pqr.routeName,
      builder: (context, state) => PqrList(),
    ),
    GoRoute(
      path: Routes.suspendedAccount.routePath,
      name: Routes.suspendedAccount.routeName,
      builder: (context, state) => SuspendedAccountPage(),
    ),
    GoRoute(
      path: Routes.otpVerification.routePath,
      name: Routes.otpVerification.routeName,
      builder: (context, state) {
        final params = state.extra as OtpVerificationPageParams;

        return OtpVerificationPage(params: params);
      },
    ),
    GoRoute(
      path: Routes.progressLoader.routePath,
      name: Routes.progressLoader.routeName,
      builder: (context, state) {
        final params = state.extra as ProgressLoaderScreenParams;

        return ProgressLoaderScreen(
          message: params.message,
          onFinish: params.onFinish,
          duration: params.duration,
          color: params.color,
          startPercent: params.startPercent,
          isError: params.isError,
        );
      },
    ),
    GoRoute(
      path: Routes.listNews.routePath,
      name: Routes.listNews.routeName,
      builder: (context, state) => ListNewsPage(),
    ),
    GoRoute(
      path: Routes.newInfo.routePath,
      name: Routes.newInfo.routeName,
      builder: (context, state) => NewInfoPage(id: state.extra as int),
    ),
    GoRoute(
      path: Routes.certificates.routePath,
      name: Routes.certificates.routeName,
      builder: (context, state) => SearchCertificatesPage(),
    ),
    GoRoute(
      path: Routes.contact.routePath,
      name: Routes.contact.routeName,
      builder: (context, state) => ContactPage(),
    ),
    GoRoute(
      path: Routes.alliedEntities.routePath,
      name: Routes.alliedEntities.routeName,
      builder: (context, state) => AlliedEntitiesPage(),
    ),

    GoRoute(
      path: Routes.passwordResetHome.routePath,
      name: Routes.passwordResetHome.routeName,
      builder: (context, state) => PasswordHomeResetPage(),
    ),
    GoRoute(
      path: Routes.survey.routePath,
      name: Routes.survey.routeName,
      builder: (context, state) {
        return SurveyPage(questions: SurveyQuestion.getSampleQuestions());
      },
    ),
    GoRoute(
      path: Routes.pdf.routePath,
      name: Routes.pdf.routeName,
      builder: (context, state) {
        return PdfViewerScreen(filePath: state.extra as String);
      },
    ),
    GoRoute(
      path: Routes.accountPage.routePath,
      name: Routes.accountPage.routeName,
      builder: (context, state) {
        return AccountPage();
      },
    ),
    GoRoute(
      path: Routes.passwordResetLogin.routePath,
      name: Routes.passwordResetLogin.routeName,
      builder: (context, state) {
        return PasswordResetLoginPage(
          params: state.extra as PasswordResetLoginPageParams,
        );
      },
    ),

    // GoRoute(
    //   path: Routes.terms.routePath,
    //   name: Routes.terms.routeName,
    //   builder: (context, state) => TermsConditionsPage(),
    // ),
  ];

  @override
  List<Object?> get props => [];
}
