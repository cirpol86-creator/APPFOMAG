import 'package:equatable/equatable.dart';
import 'package:fomagapp/core/routes/name_routes.dart';

enum AppRoute {
  unknown,
  splashScreen,
  login,
  healthcenter,
  home,
  register,
  pqr,
  createPqr,
  contact,
  certificates,
  profile,
  otpVerification,
  suspendedAccount,
  progressLoader,
  listNews,
  newInfo,
  survey,
  passwordReset,
  alliedEntities,
  pdf,
  terms,
  account,
  passwordResetHome,
  passwordResetLogin,
}

class Routes extends Equatable {
  static NamedRoute get unknown => NamedRoute(appRoute: AppRoute.unknown);
  static NamedRoute get splashScreen =>
      NamedRoute(appRoute: AppRoute.splashScreen);
  static NamedRoute get login => NamedRoute(appRoute: AppRoute.login);
  static NamedRoute get healthcenter =>
      NamedRoute(appRoute: AppRoute.healthcenter);
  static NamedRoute get home => NamedRoute(appRoute: AppRoute.home);
  static NamedRoute get register => NamedRoute(appRoute: AppRoute.register);
  static NamedRoute get passwordReset =>
      NamedRoute(appRoute: AppRoute.passwordReset);
  static NamedRoute get passwordResetLogin =>
      NamedRoute(appRoute: AppRoute.passwordResetLogin);
  static NamedRoute get pqr => NamedRoute(appRoute: AppRoute.pqr);
  static NamedRoute get createPqr => NamedRoute(appRoute: AppRoute.createPqr);
  static NamedRoute get contact => NamedRoute(appRoute: AppRoute.contact);
  static NamedRoute get profile => NamedRoute(appRoute: AppRoute.profile);
  static NamedRoute get certificates =>
      NamedRoute(appRoute: AppRoute.certificates);
  static NamedRoute get otpVerification =>
      NamedRoute(appRoute: AppRoute.otpVerification);
  static NamedRoute get suspendedAccount =>
      NamedRoute(appRoute: AppRoute.suspendedAccount);
  static NamedRoute get progressLoader =>
      NamedRoute(appRoute: AppRoute.progressLoader);
  static NamedRoute get listNews => NamedRoute(appRoute: AppRoute.listNews);
  static NamedRoute get newInfo => NamedRoute(appRoute: AppRoute.newInfo);
  static NamedRoute get survey => NamedRoute(appRoute: AppRoute.survey);
  static NamedRoute get pdf => NamedRoute(appRoute: AppRoute.pdf);
  static NamedRoute get alliedEntities =>
      NamedRoute(appRoute: AppRoute.alliedEntities);
  static NamedRoute get terms => NamedRoute(appRoute: AppRoute.terms);
  static NamedRoute get accountPage => NamedRoute(appRoute: AppRoute.account);
  static NamedRoute get passwordResetHome =>
      NamedRoute(appRoute: AppRoute.passwordResetHome);

  @override
  List<Object?> get props => [];
}
