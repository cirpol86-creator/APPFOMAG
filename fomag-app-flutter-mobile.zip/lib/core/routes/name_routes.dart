import 'package:equatable/equatable.dart';
import 'package:fomagapp/core/routes/routes.dart';

class NamedRoute extends Equatable {
  final AppRoute appRoute;

  String get routeName => appRoute.name;
  String get routePath => '/${appRoute.name}';

  const NamedRoute({required this.appRoute});

  @override
  List<Object?> get props => [appRoute, routeName, routePath];
}
