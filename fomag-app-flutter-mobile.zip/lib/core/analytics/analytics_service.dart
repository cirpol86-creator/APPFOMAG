import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:fomagapp/data/model/user_event_model.dart';

class AnalyticsService {
  final FirebaseAnalytics _analytics;

  AnalyticsService({required FirebaseAnalytics analytics})
    : _analytics = analytics;

  Future<void> sendEvent(UserEventModel event) async {
    final name = event.type.name;
    await _analytics.logEvent(name: name, parameters: event.parameters);
  }
}
