import 'package:flutter/widgets.dart';

class LifecycleEventHandler extends WidgetsBindingObserver {
  final Future<void> Function()? resumeCallBack;
  final Future<void> Function()? pausedCallBack;
  final Future<void> Function()? detachedCallBack;

  LifecycleEventHandler({
    this.resumeCallBack,
    this.pausedCallBack,
    this.detachedCallBack,
  });

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        resumeCallBack?.call();
        break;
      case AppLifecycleState.paused:
        pausedCallBack?.call();
        break;
      case AppLifecycleState.detached:
        detachedCallBack?.call();
        break;
      case AppLifecycleState.inactive:
        break;
      case AppLifecycleState.hidden:
        throw UnimplementedError();
    }
  }
}
