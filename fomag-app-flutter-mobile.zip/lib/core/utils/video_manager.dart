import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';

class VideoManager {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  double? _widthVideo;
  double? _heightVideo;
  double? _aspectRatio;

  // Getters y setters públicos
  set videoController(VideoPlayerController? controller) =>
      _videoController = controller;
  VideoPlayerController? get videoController => _videoController;

  set chewieController(ChewieController? controller) =>
      _chewieController = controller;
  ChewieController? get chewieController => _chewieController;

  double? get widthVideo => _widthVideo;
  set widthVideo(double? value) => _widthVideo = value;

  double? get heightVideo => _heightVideo;
  set heightVideo(double? value) => _heightVideo = value;

  double? get aspectRatio => _aspectRatio;
  set aspectRatio(double? value) => _aspectRatio = value;

  /// Inicializa un video directo (mp4, webm, etc.)
  Future<void> initializeVideo(String url) async {
    // Verifica que no sea un link de YouTube antes de inicializar
    if (_isYoutubeUrl(url)) return;

    try {
      _videoController = VideoPlayerController.networkUrl(Uri.parse(url));
      await _videoController?.setLooping(true);
      await _videoController?.initialize();

      _widthVideo = _videoController!.value.size.width;
      _heightVideo = _videoController!.value.size.height;
      _aspectRatio = _videoController!.value.aspectRatio;

      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: false,
        looping: false,
      );
    } catch (e) {
      dispose();
      rethrow;
    }
  }

  /// Limpia todos los recursos de video
  void dispose() {
    try {
      _videoController?.dispose();
    } catch (_) {}
    try {
      _chewieController?.dispose();
    } catch (_) {}

    _videoController = null;
    _chewieController = null;
    _widthVideo = null;
    _heightVideo = null;
    _aspectRatio = null;
  }

  /// Verifica si una URL es de YouTube
  bool _isYoutubeUrl(String url) {
    return url.contains('youtube.com') || url.contains('youtu.be');
  }
}
