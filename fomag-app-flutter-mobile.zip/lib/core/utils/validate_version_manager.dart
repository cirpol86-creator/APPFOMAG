import 'package:equatable/equatable.dart';
import 'package:package_info_plus/package_info_plus.dart';

class ValidateVersionManager extends Equatable {
  static Future<String> getVersion() async {
    final info = await PackageInfo.fromPlatform();

    return info.version;
  }

  @override
  List<Object?> get props => [];
}
