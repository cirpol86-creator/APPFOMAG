import 'dart:ui';

import 'package:equatable/equatable.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter/material.dart';

class SvgManager extends Equatable {
  static const String mapPinned = 'assets/svg/map-pinned.svg';
  static const String logoPath = 'assets/svg/logo.svg';
  static const String arrowLeftPath = 'assets/svg/arrow_left.svg';
  static const String strokePath = 'assets/svg/stroke.svg';
  static const String retryPath = 'assets/svg/retry.svg';
  static const String menuPath = 'assets/svg/menu.svg';
  static const String userPath = 'assets/svg/user.svg';
  static const String housePath = 'assets/svg/house.svg';
  static const String headsetPath = 'assets/svg/headset.svg';
  static const String newsPath = 'assets/svg/news.svg';
  static const String hospitalPath = 'assets/svg/hospital.svg';
  static const String askPath = 'assets/svg/ask.svg';
  static const String checkCloudPath = 'assets/svg/check_cloud.svg';
  static const String phonePath = 'assets/svg/phone.svg';
  static const String certificatePath = 'assets/svg/certificate.svg';
  static const String arrowRightBorderedPath =
      'assets/svg/arrow_right_bordered.svg';
  static const String checkBorderedPath = 'assets/svg/check_bordered.svg';
  static const String arrowRightSimplePath =
      'assets/svg/arrow_right_simple.svg';
  static const String arrowLeftSimplePath = 'assets/svg/arrow_left_simple.svg';
  static const String happyFacePath = 'assets/svg/happy_face.svg';
  static const String logoutPath = 'assets/svg/logout.svg';
  static const String keyPath = 'assets/svg/key.svg';
  static const String withoutInternetPath = 'assets/svg/without_internet.svg';

  static SvgPicture getSvgWithColor(String path, Color color) {
    return SvgPicture.asset(
      path,
      colorFilter: ColorFilter.mode(color, BlendMode.srcIn),
    );
  }

  static SvgPicture get logo => SvgPicture.asset(logoPath);

  static SvgPicture get arrowLeft => SvgPicture.asset(arrowLeftPath);

  static SvgPicture get stroke => SvgPicture.asset(strokePath);

  static SvgPicture get retry => SvgPicture.asset(retryPath);

  static SvgPicture get menu => SvgPicture.asset(menuPath);

  static SvgPicture get user => SvgPicture.asset(userPath);

  static SvgPicture get house => SvgPicture.asset(housePath);

  static SvgPicture get headset => SvgPicture.asset(headsetPath);

  static SvgPicture get news => SvgPicture.asset(newsPath);

  static SvgPicture get hospital => SvgPicture.asset(hospitalPath);

  static SvgPicture get ask => SvgPicture.asset(askPath);

  static SvgPicture get checkCloud => SvgPicture.asset(checkCloudPath);

  static SvgPicture get phone => SvgPicture.asset(phonePath);

  static SvgPicture get certificate => SvgPicture.asset(certificatePath);

  static SvgPicture get arrowRightBordered =>
      SvgPicture.asset(arrowRightBorderedPath);

  static SvgPicture get checkBordered => SvgPicture.asset(checkBorderedPath);

  static SvgPicture get arrowRightSimple =>
      SvgPicture.asset(arrowRightSimplePath);

  static SvgPicture get arrowLeftSimple =>
      SvgPicture.asset(arrowLeftSimplePath);

  static SvgPicture get happyFace => SvgPicture.asset(happyFacePath);

  static SvgPicture get logout => SvgPicture.asset(logoutPath);

  static SvgPicture get key => SvgPicture.asset(keyPath);

  static SvgPicture get withoutInternet =>
      SvgPicture.asset(withoutInternetPath);

  @override
  List<Object?> get props => [];
}
