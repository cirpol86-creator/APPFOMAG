import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';

abstract class DeleteAccountService {
  Future<DeleteAccountResponse> deleteAccount();
}
