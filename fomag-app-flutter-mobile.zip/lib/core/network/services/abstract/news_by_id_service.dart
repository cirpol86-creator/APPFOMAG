import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';

abstract class NewsByIdService {
  Future<NewsByIdResponse> call(int uuid);
}
