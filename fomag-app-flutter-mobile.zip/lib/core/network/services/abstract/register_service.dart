import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';

abstract class RegisterService {
  Future<RegisterResponse> call(RegisterRequest request);
}
