import 'package:fomagapp/data/model/request/logout/logout_request.dart';

abstract class LogoutService {
  Future<void> call(LogoutRequest request);
}
