import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';

abstract class DepartmentsHealthCenterService {
  Future<List<DepartmentsHealthCenterResponse>> call();
}
