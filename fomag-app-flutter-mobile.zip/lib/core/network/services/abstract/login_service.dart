import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';

abstract class LoginService {
  Future<AuthResponse> call(LoginRequest request);
}
