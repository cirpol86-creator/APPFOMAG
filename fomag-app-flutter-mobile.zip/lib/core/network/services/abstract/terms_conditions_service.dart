abstract class TermsConditionsService {
  Future<String> fetchTermsAndConditions();
}
