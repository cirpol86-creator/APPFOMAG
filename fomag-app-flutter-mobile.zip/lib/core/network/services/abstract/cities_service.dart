import 'package:fomagapp/data/model/response/cities/cities_response.dart';

abstract class CitiesService {
  Future<List<CitiesResponse>> call(int request);
}
