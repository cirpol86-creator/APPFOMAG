import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';

abstract class GarnishmentsService {
  Future<List<GarnishmentsCertificateResponse>> call(
    GarnishmentRequest request,
  );
}
