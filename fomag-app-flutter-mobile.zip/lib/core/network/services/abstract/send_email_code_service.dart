import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';

abstract class SendEmailCodeService {
  Future<ForgotPasswordResponse> call(EmailCodeRequest request);
}
