import 'package:fomagapp/data/model/response/contact/contact_response.dart';

abstract class ContactService {
  Future<List<ContentResponse>> getContacts();
}
