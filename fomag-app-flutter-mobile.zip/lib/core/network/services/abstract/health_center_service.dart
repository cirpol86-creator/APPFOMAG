import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';

abstract class HealthCenterService {
  Future<List<HealthCenterResponse>> call(int request);
}
