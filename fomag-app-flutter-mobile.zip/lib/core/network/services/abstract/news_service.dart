import 'package:fomagapp/data/model/response/news/news_response.dart';

abstract class NewsService {
  Future<NewsResponse> call();
}
