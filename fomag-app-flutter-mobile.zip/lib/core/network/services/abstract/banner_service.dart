import 'package:fomagapp/data/model/response/banner/banner_response.dart';

abstract class BannerService {
  Future<BannerResponse> getBanner();
}
