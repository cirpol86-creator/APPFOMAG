import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';

abstract class ConfirmForgotPasswordService {
  Future<ConfirmForgotPasswordResponse> call(
    ConfirmForgotPasswordRequest request,
  );
}
