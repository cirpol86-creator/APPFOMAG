import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';

abstract class OtpValidateService {
  Future<OtpValidateResponse> call(OtpValidateRequest request);
}
