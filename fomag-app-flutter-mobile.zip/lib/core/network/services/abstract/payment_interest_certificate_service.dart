import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';

abstract class PaymentInterestCertificateService {
  Future<List<String?>> call(PayInterestCertificateRequest request);
}
