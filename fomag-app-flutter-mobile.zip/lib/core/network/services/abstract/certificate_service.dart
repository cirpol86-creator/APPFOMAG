import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';

abstract class CertificateService {
  Future<CertificateTypeResponse> call();
  Future<CertificateResponse> generateCertificate(
    String path,
    Map<String, dynamic> entries,
  );
}
