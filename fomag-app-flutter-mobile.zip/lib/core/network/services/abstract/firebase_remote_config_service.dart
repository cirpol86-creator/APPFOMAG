import 'package:fomagapp/core/enviroment/environment.dart';

abstract class RemoteConfigService {
  Future<void> initialize();
  Environment buildEnvironment(String enviromentName);
}
