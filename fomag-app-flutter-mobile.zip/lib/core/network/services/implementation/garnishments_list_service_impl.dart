import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/garnishments_service.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';

class GarnishmentsListImpl extends GarnishmentsService {
  final ApiClient _apiClient;

  GarnishmentsListImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<List<GarnishmentsCertificateResponse>> call(
    GarnishmentRequest garnishmentRequest,
  ) {
    return _apiClient
        .garnishmentsList(garnishmentRequest)
        .then((response) => response.data);
  }
}
