import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/contact_services.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';

class ContactServiceImpl extends ContactService {
  final ApiClient _apiClient;

  ContactServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<List<ContentResponse>> getContacts() {
    return _apiClient.getContactList().then(
      (response) => response.data.content,
    );
  }
}
