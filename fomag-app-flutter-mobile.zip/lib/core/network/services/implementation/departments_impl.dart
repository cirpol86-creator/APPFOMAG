import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/departments_health_center_service.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';

class DepartmentsImpl implements DepartmentsHealthCenterService {
  final ApiClient _apiClient;

  DepartmentsImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<List<DepartmentsHealthCenterResponse>> call() {
    return _apiClient.getDepartments().then((response) {
      return response.data.content ?? [];
    });
  }
}
