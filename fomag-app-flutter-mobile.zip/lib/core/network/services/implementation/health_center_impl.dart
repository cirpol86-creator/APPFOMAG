import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/health_center_service.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';

class HealthCenterImpl implements HealthCenterService {
  final ApiClient _apiClient;

  HealthCenterImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<List<HealthCenterResponse>> call(int request) {
    return _apiClient.getHealthCenters(request).then((response) {
      return response.data.content ?? [];
    });
  }
}
