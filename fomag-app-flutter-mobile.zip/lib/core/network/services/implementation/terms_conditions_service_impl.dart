import 'dart:convert';

import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/terms_conditions_service.dart';

class TermsConditionsServiceImpl extends TermsConditionsService {
  final ApiClient _apiClient;

  TermsConditionsServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<String> fetchTermsAndConditions() {
  return _apiClient.getTermsAndConditions().then((response) {
    final Map<String, dynamic> decoded = jsonDecode(response.data);
    final descripcion = decoded['content']['descripcion'];
    return descripcion ?? '';
  });
}
}
