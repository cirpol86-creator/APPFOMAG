import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/banner_service.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';

class BannerServiceImpl extends BannerService {
  final ApiClient _apiClient;

  BannerServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<BannerResponse> getBanner() {
    return _apiClient.getBanner().then((response) => response.data);
  }
}
