import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/delete_account_service.dart';
import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';

class DeleteAccountServiceImpl extends DeleteAccountService {
  final ApiClient _apiClient;

  DeleteAccountServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<DeleteAccountResponse> deleteAccount() {
    return _apiClient.deleteAccount().then((response) => response.data);
  }
}
