import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/confirm_forgot_password_service.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';

class ConfirmForgotPasswordServiceImpl extends ConfirmForgotPasswordService {
  final ApiClient _apiClient;

  ConfirmForgotPasswordServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<ConfirmForgotPasswordResponse> call(
    ConfirmForgotPasswordRequest request,
  ) {
    return _apiClient
        .confirmForgotPassword(request)
        .then((response) => response.data);
  }
}
