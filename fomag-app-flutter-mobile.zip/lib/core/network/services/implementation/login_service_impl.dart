import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/login_service.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';

class LoginServiceImpl extends LoginService {
  final ApiClient _apiClient;

  LoginServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<AuthResponse> call(LoginRequest request) {
    return _apiClient.login(request).then((response) {
      final authResponse = response.data.data;
      if (authResponse == null) {
        throw Exception('AuthResponse is null');
      }
      return authResponse;
    });
  }
}
