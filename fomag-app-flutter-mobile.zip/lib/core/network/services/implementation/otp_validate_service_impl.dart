import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/otp_validate_service.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';

class OtpValidateServiceImpl extends OtpValidateService {
  final ApiClient _apiClient;

  OtpValidateServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<OtpValidateResponse> call(OtpValidateRequest request) {
    return _apiClient
        .otpValidate(request)
        .then((response) => response.data.message);
  }
}
