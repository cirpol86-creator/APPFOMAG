import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/cities_service.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';

class CitiesImpl implements CitiesService {
  final ApiClient _apiClient;

  CitiesImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<List<CitiesResponse>> call(int departmentId) {
    return _apiClient.getCities(departmentId).then((response) {
      return response.data.content ?? [];
    });
  }
}
