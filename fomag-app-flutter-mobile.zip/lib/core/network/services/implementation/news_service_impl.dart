import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/news_service.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';

class NewsServiceImpl extends NewsService {
  final ApiClient _apiClient;

  NewsServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<NewsResponse> call() {
    return _apiClient.getNews().then((response) => response.data);
  }
}
