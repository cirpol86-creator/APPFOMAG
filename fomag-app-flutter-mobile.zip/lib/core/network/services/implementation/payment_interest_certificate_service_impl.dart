import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/payment_interest_certificate_service.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';

class PaymentInterestCertificateServiceImpl
    extends PaymentInterestCertificateService {
  final ApiClient _apiClient;

  PaymentInterestCertificateServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<List<String>> call(PayInterestCertificateRequest request) {
    return _apiClient
        .getPayInterestCertificate(request)
        .then((response) => response.data);
  }
}
