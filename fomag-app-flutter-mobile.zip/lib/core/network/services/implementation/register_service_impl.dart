import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/register_service.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';

class RegisterServiceImpl extends RegisterService {
  final ApiClient _apiClient;

  RegisterServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<RegisterResponse> call(RegisterRequest request) {
    return _apiClient.register(request).then((response) => response.data);
  }
}
