import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:fomagapp/core/enviroment/environment.dart';
import 'package:fomagapp/core/network/services/abstract/firebase_remote_config_service.dart';
import 'package:fomagapp/core/network/util/const.dart';

class FirebaseRemoteConfigServiceImpl implements RemoteConfigService {
  final FirebaseRemoteConfig _remoteConfig;

  FirebaseRemoteConfigServiceImpl(this._remoteConfig);

  @override
  Future<void> initialize() async {
    await _remoteConfig.setConfigSettings(
      RemoteConfigSettings(
        fetchTimeout: const Duration(seconds: 30),
        minimumFetchInterval: const Duration(hours: 24),
      ),
    );
    await _remoteConfig.fetchAndActivate();
  }

  @override
  Environment buildEnvironment(String enviromentName) {
    final devUrl = _remoteConfig.getString('dev_base_url');
    final qaUrl = _remoteConfig.getString('qa_base_url');
    final prodUrl = _remoteConfig.getString('prod_base_url');

    switch (enviromentName) {
      case Const.enviromentDevelopment:
        return Environment.development(remoteBaseUrl: devUrl);
      case Const.enviromentQuality:
        return Environment.quality(remoteBaseUrl: qaUrl);
      case Const.enviromentRelease:
        return Environment.production(remoteBaseUrl: prodUrl);
      default:
        return Environment.production(remoteBaseUrl: prodUrl);
    }
  }
}
