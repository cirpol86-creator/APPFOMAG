import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/certificate_service.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';

class GetTypesCertificatesServiceImpl extends CertificateService {
  final ApiClient _apiClient;

  GetTypesCertificatesServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<CertificateTypeResponse> call() {
    return _apiClient.getTypesCertificates().then((response) => response.data);
  }

  @override
  Future<CertificateResponse> generateCertificate(
    String path,
    Map<String, dynamic> entries,
  ) {
    return _apiClient
        .generateCertificate(path, entries)
        .then((response) => response.data);
  }
}
