import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/news_by_id_service.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';

class NewsByIdServiceImpl extends NewsByIdService {
  final ApiClient _apiClient;

  NewsByIdServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<NewsByIdResponse> call(int uuid) {
    return _apiClient.getNewById(uuid).then((response) => response.data);
  }
}
