import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/logout_service.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';

class LogoutServiceImpl extends LogoutService {
  final ApiClient _apiClient;

  LogoutServiceImpl({required ApiClient apiClient}) : _apiClient = apiClient;

  @override
  Future<void> call(LogoutRequest request) {
    return _apiClient.logout(request);
  }
}
