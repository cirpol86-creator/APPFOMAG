import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/services/abstract/send_email_code_service.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';

class SendEmailCodeServiceImpl extends SendEmailCodeService {
  final ApiClient _apiClient;

  SendEmailCodeServiceImpl({required ApiClient apiClient})
    : _apiClient = apiClient;

  @override
  Future<ForgotPasswordResponse> call(EmailCodeRequest request) {
    return _apiClient.sendEmailCode(request).then((response) => response.data);
  }
}
