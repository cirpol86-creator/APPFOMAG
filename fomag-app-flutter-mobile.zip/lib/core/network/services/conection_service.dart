import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

class ConnectionService with ChangeNotifier {
  bool _isConnected = true;
  bool get isConnected => _isConnected;

  StreamSubscription<List<ConnectivityResult>>? _subscription;

  ConnectionService() {
    _checkConnection();
  }

  void _checkConnection() {
    _subscription = Connectivity().onConnectivityChanged.listen((
      List<ConnectivityResult> results,
    ) async {
      final isConnected =
          results.contains(ConnectivityResult.mobile) ||
          results.contains(ConnectivityResult.wifi) ||
          results.contains(ConnectivityResult.ethernet);

      final hasInternet = isConnected ? await _hasInternetAccess() : false;

      if (_isConnected != hasInternet) {
        _isConnected = hasInternet;
        notifyListeners();
      }
    });

    _initialCheck();
  }

  Future<void> _initialCheck() async {
    final hasInternet = await _hasInternetAccess();
    if (_isConnected != hasInternet) {
      _isConnected = hasInternet;
      notifyListeners();
    }
  }

  Future<bool> _hasInternetAccess() async {
    try {
      final result = await InternetAddress.lookup(
        'example.com',
      ).timeout(const Duration(seconds: 3));
      return result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<bool> checkConnectionNow() async {
    final hasInternet = await _hasInternetAccess();
    if (_isConnected != hasInternet) {
      _isConnected = hasInternet;
      notifyListeners();
    }
    return hasInternet;
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
