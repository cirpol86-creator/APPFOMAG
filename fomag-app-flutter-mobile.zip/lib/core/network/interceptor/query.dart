import 'dart:developer';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/network/error/error_response.dart';
import 'package:fomagapp/core/network/error/message.dart';
import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/core/utils/validate_version_manager.dart';

class QueryInterceptor extends InterceptorsWrapper {
  static const _contentType = 'content-type';
  static const _applicationJson = 'application/json';
  static const _authorization = 'Authorization';
  static const _clientType = 'Client-Type';
  static const _mobile = 'mobile';
  static const _version = 'version';
  static const _idToken = 'x-id-token';

  final String? identityBaseDomain;
  final bool expectResponseJson;
  final bool ignoreToken;
  final Connectivity connectivity;
  final bool ignoreConnection;
  final Dio dio;

  QueryInterceptor({
    required this.dio,
    required this.identityBaseDomain,
    this.expectResponseJson = false,
    this.ignoreConnection = false,
    this.ignoreToken = false,
    Connectivity? connectivity,
  }) : connectivity = connectivity ?? Connectivity();

  @override
  Future onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    if (!ignoreConnection) {
      await connectivity.checkConnectivity();
    }

    if (!ignoreToken) {
      final String? idToken = await SecureStorageManager.getIdToken();
      if (idToken != null) {
        options.headers[_authorization] = idToken;
        options.headers[_idToken] = idToken;
      }
    }

    options.headers[_clientType] = _mobile;
    options.headers[_version] = await ValidateVersionManager.getVersion();

    return super.onRequest(options, handler);
  }

  @override
  Future onResponse(
    Response response,
    ResponseInterceptorHandler handler,
  ) async {
    final isInValidAuthenticationResponse = _isInValidAuthenticationResponse(
      response,
    );

    if (isInValidAuthenticationResponse) {
      throw DioException(
        requestOptions: response.requestOptions,
        response: response,
        type: DioExceptionType.badCertificate,
        error:
            'Invalid token or current token is expired. Please try logging in again!',
      );
    }

    if (!isResponseOkButNoContent(response) && expectResponseJson) {
      throw DioException(
        requestOptions: response.requestOptions,
        response: response,
        type: DioExceptionType.badResponse,
        error: 'Response format is not a json response',
      );
    }

    return super.onResponse(response, handler);
  }

  @override
  Future onError(DioException err, ErrorInterceptorHandler handler) async {
    return handler.next(_newDioException(err));
  }

  DioException _newDioException(DioException err) {
    if (kDebugMode) {
      log('error: ${err.message}');
      log('type: ${err.type}');
      log('response: ${err.response}');
    }

    ErrorResponse errorResponse = ErrorMessageManager.getErrorResponse(err);

    final response =
        err.response ??
        Response(
          requestOptions: err.requestOptions,
          data: errorResponse.toJson(),
        );

    return DioException(
      message: errorResponse.message,
      requestOptions: err.requestOptions,
      response: response,
      type: err.type,
      error: err.error,
      stackTrace: err.stackTrace,
    );
  }

  bool _isInValidAuthenticationResponse(Response? response) {
    return response?.statusCode == HttpStatus.unauthorized;
  }

  bool isResponseOkButNoContent(Response response) =>
      response.statusCode == HttpStatus.noContent;

  bool? isResponseHeaderTypeJson(Map<String, List<String>> headerMap) {
    return headerMap[_contentType]
        ?.firstWhere(
          (element) => element.contains(_applicationJson),
          orElse: () => '',
        )
        .contains(_applicationJson);
  }
}
