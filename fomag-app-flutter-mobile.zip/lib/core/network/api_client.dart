import 'package:dio/dio.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:fomagapp/data/model/request/new_password/new_password_request.dart';
import 'package:fomagapp/data/model/request/otp_code_password/otp_code_password_request.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/data/model/response/generic/generic_response.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:retrofit/retrofit.dart';

part 'api_client.g.dart';

@RestApi(baseUrl: "")
abstract class ApiClient {
  factory ApiClient(Dio dio, {String? baseUrl}) {
    return _ApiClient(dio, baseUrl: baseUrl);
  }

  @POST('mobile/auth/login')
  Future<HttpResponse<GenericResponse<AuthResponse>>> login(
    @Body() LoginRequest request,
  );

  @POST('mobile/auth/register')
  Future<HttpResponse<RegisterResponse>> register(
    @Body() RegisterRequest request,
  );

  @POST('mobile/auth/verify-2fa')
  Future<HttpResponse<GenericOtpResponse<OtpValidateResponse>>> otpValidate(
    @Body() OtpValidateRequest request,
  );

  @GET('mobile/news')
  Future<HttpResponse<NewsByIdResponse>> getNewById(
    @Query("uuid") int category,
  );

  @GET('mobile/news')
  Future<HttpResponse<NewsResponse>> getNews();

  @POST('mobile/auth/forgot-password')
  Future<HttpResponse<ForgotPasswordResponse>> sendEmailCode(
    @Body() EmailCodeRequest request,
  );

  @POST('otp/sendCode')
  Future<HttpResponse<AuthResponse>> otpCodePassword(
    @Body() OtpCodePasswordRequest request,
  );

  @GET('mobile/certifications/certificates')
  Future<HttpResponse<CertificateTypeResponse>> getTypesCertificates();

  @POST("{path}")
  Future<HttpResponse<CertificateResponse>> generateCertificate(
    @Path("path") String path,
    @Body() Map<String, dynamic> body,
  );

  @POST("mobile/certifications/embargo-details")
  Future<HttpResponse<List<GarnishmentsCertificateResponse>>> garnishmentsList(
    @Body() GarnishmentRequest request,
  );

  @POST('mobile/auth/confirm-forgot-password')
  Future<HttpResponse<ConfirmForgotPasswordResponse>> confirmForgotPassword(
    @Body() ConfirmForgotPasswordRequest request,
  );

  @GET('mobile/departments')
  Future<HttpResponse<GenericResponse<List<DepartmentsHealthCenterResponse>>>>
  getDepartments();

  @GET('mobile/cities')
  Future<HttpResponse<GenericResponse<List<CitiesResponse>>>> getCities(
    @Query('idDepartament') int departmentId,
  );

  @GET('mobile/health-centers')
  Future<HttpResponse<GenericResponse<List<HealthCenterResponse>>>>
  getHealthCenters(@Query('idCity') int idCity);

  @GET('mobile/terms-and-conditions')
  Future<HttpResponse<String>> getTermsAndConditions();

  @GET('mobile/contact-us')
  Future<HttpResponse<ContactResponse>> getContactList();

  @POST('mobile/auth/deleteAccount')
  Future<HttpResponse<DeleteAccountResponse>> deleteAccount();

  @POST("mobile/certifications/severance-pay-interest")
  Future<HttpResponse<List<String>>> getPayInterestCertificate(
    @Body() PayInterestCertificateRequest request,
  );

  @POST('mobile/auth/logout')
  Future<HttpResponse> logout(@Body() LogoutRequest request);

  @GET('mobile/banners')
  Future<HttpResponse<BannerResponse>> getBanner();
}
