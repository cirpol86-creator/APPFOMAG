import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/network/interceptor/curl_log.dart';
import 'package:fomagapp/core/network/interceptor/query.dart';

class ApiClientImpl {
  static ApiClient apiClient({
    required String baseDomain,
    String? identityBaseDomain,
    bool disableRequestBodyLogging = false,
    bool ignoreToken = false,
    bool ignoreConnection = false,
  }) {
    BaseOptions baseOptions = BaseOptions();
    baseOptions.connectTimeout = const Duration(milliseconds: 60000);
    baseOptions.receiveTimeout = const Duration(milliseconds: 60000);
    baseOptions.contentType = Headers.jsonContentType;
    baseOptions.responseType = ResponseType.json;

    final Dio dio = Dio(baseOptions);

    final QueryInterceptor query = QueryInterceptor(
      identityBaseDomain: identityBaseDomain,
      ignoreConnection: ignoreConnection,
      ignoreToken: ignoreToken,
      dio: dio,
    );

    dio.interceptors.add(query);

    if (kDebugMode) {
      dio.interceptors.add(
        CurlLogInterceptor(disableRequestBody: disableRequestBodyLogging),
      );
    }

    return ApiClient(dio, baseUrl: baseDomain);
  }
}
