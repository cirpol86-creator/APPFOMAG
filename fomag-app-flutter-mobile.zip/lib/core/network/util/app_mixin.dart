import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

mixin ConnectivityMixin {
  final Connectivity connectivity = Connectivity();

  Future<bool> isInConnection() async {
    final connectivityResults = await connectivity.checkConnectivity();
    final result = connectivityResults.firstOrNull;

    return result != ConnectivityResult.none && result != null;
  }
}

mixin AfterLayoutMixin<T extends StatefulWidget> on State<T> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback(
      (_) async => afterFirstLayout(context),
    );
    super.initState();
  }

  Future<void> afterFirstLayout(BuildContext context);
}
