class Const {
  static const String enviromentQuality = 'Quality';
  static const String enviromentDevelopment = 'Development';
  static const String enviromentRelease = 'Release';
  static const String defaultMessageErrorServer =
      'Se presentó un error en el servicio. Por favor, intente más tarde.';
  static const String dateValidationMessageError =
      'La fecha final no puede ser menor a la fecha inicial.';
}
