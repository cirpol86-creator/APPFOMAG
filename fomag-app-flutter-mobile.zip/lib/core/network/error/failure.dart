import 'package:dio/dio.dart';
import 'package:equatable/equatable.dart';

/// Clase base para manejar errores de manera tipada y estructurada.
class Failure<T> extends Equatable {
  final String message;
  final T? data;

  const Failure({required this.message, this.data});

  @override
  List<Object?> get props => [message, data];
}

/// Error del servidor (500, 400, etc.)
class ServerFailure<T> extends Failure<T> {
  const ServerFailure({required super.message, super.data});
}

/// Sin conexión a internet
class NoConnectionFailure<T> extends Failure<T> {
  const NoConnectionFailure() : super(message: 'No connection!');
}

/// Usuario no autenticado
class NoAuthenticationFailure<T> extends Failure<T> {
  const NoAuthenticationFailure() : super(message: 'Please sign in');
}

/// Mapea una instancia de [Failure] a su mensaje legible
String mapFailureToMessage(Failure failure) => failure.message;

/// Utilidades para construir errores desde fuentes externas como Dio
class FailureUtils {
  static Failure<DioExceptionType> fromDioError(DioException e) {
    final type = e.type;
    final message = e.message ?? 'Unknown Dio error';

    switch (type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return ServerFailure(message: 'Timeout de conexión', data: type);
      case DioExceptionType.badResponse:
        return ServerFailure(
          message: 'Respuesta incorrecta del servidor',
          data: type,
        );
      case DioExceptionType.connectionError:
        return NoConnectionFailure();
      case DioExceptionType.cancel:
        return ServerFailure(message: 'Petición cancelada', data: type);
      case DioExceptionType.unknown:
      default:
        return ServerFailure(message: message, data: type);
    }
  }
}
