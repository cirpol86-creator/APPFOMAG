import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/error_response.dart';
import 'package:fomagapp/core/network/util/const.dart';

class ErrorMessageManager {
  static Map<DioExceptionType, String> errorMessage = {
    DioExceptionType.connectionError:
        'Se ha presentado un error con la conexión, por favor vuelva a intentarlo más tarde.',
    DioExceptionType.receiveTimeout: 'Tiempo de espera de respuesta excedido.',
  };

  static String getErrorMessage(DioException err) {
    final key = err.type;

    if (errorMessage.containsKey(key)) {
      return errorMessage[key]!;
    } else {
      return Const.defaultMessageErrorServer;
    }
  }

  static ErrorResponse getErrorResponse(DioException err) {
    String message;
    ErrorResponse errorResponse;

    if (err.response?.data is Map<String, dynamic>) {
      errorResponse = ErrorResponse.fromJson(
        err.response?.data as Map<String, dynamic>,
      );
    } else {
      message = ErrorMessageManager.getErrorMessage(err);
      errorResponse = ErrorResponse.fromDioError(
        err.requestOptions.path,
        err.response?.statusCode,
        message,
      );
    }

    return errorResponse;
  }
}
