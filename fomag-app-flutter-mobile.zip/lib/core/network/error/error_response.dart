import 'package:json_annotation/json_annotation.dart';

part 'error_response.g.dart';

@JsonSerializable()
class ErrorResponse {
  const ErrorResponse({
    this.channel = 'mobile',
    this.type = 'bussiness',
    this.dateTimeError,
    this.serviceNameAffected,
    this.httpStatusCode,
    this.responseBackend,
    this.userAuthenticated = '',
    this.message,
  });

  @JsonKey(name: 'channel')
  final String channel;

  @JsonKey(name: 'type')
  final String type;

  @JsonKey(name: 'dateTimeError')
  final String? dateTimeError;

  @JsonKey(name: 'serviceNameAffected')
  final String? serviceNameAffected;

  @JsonKey(name: 'httpStatusCode')
  final int? httpStatusCode;

  @JsonKey(name: 'responseBackend')
  final String? responseBackend;

  @JsonKey(name: 'userAuthenticated')
  final String userAuthenticated;

  @JsonKey(name: 'message')
  final String? message;

  factory ErrorResponse.fromJson(Map<String, dynamic> json) =>
      _$ErrorResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ErrorResponseToJson(this);

  factory ErrorResponse.fromDioError(
    String path,
    int? statusCode,
    String errorMessage,
  ) {
    return ErrorResponse(
      dateTimeError: DateTime.now().toString(),
      serviceNameAffected: path,
      httpStatusCode: statusCode,
      responseBackend: errorMessage,
      message: errorMessage,
    );
  }
}
