import 'package:fomagapp/core/enviroment/development/development_env.dart';
import 'package:fomagapp/core/enviroment/production/production_env.dart';
import 'package:fomagapp/core/enviroment/quality/quality_env.dart';

class Environment {
  /// Prod Environment
  factory Environment.production({String? remoteBaseUrl}) {
    return ProductionEnvironment.production(remoteBaseUrl);
  }

  /// Dev Environment
  factory Environment.development({String? remoteBaseUrl}) {
    return DevelopmentEnvironment.development(remoteBaseUrl);
  }

  /// Dev Environment
  factory Environment.quality({String? remoteBaseUrl}) {
    return QualityEnvironment.quality(remoteBaseUrl);
  }

  Environment({required this.envName, required this.baseDomain});

  final String baseDomain;
  final String envName;
}
