import 'package:fomagapp/core/enviroment/environment.dart';
import 'package:fomagapp/core/network/util/const.dart';

extension DevelopmentEnvironment on Environment {
  static Environment development([String? url]) {
    return Environment(
      baseDomain:
          url ?? 'https://1jkwxw263c.execute-api.us-east-1.amazonaws.com/',
      envName: Const.enviromentDevelopment,
    );
  }
}
