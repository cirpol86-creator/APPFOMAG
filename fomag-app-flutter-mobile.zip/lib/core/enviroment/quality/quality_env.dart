import 'package:fomagapp/core/enviroment/environment.dart';
import 'package:fomagapp/core/network/util/const.dart';

extension QualityEnvironment on Environment {
  static Environment quality(String? url) {
    return Environment(
      baseDomain:
          url ?? 'https://rastbhfds5.execute-api.us-east-1.amazonaws.com/qa/',
      envName: Const.enviromentQuality,
    );
  }
}
