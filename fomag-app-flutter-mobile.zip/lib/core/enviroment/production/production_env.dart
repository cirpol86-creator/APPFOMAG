import 'package:fomagapp/core/enviroment/environment.dart';
import 'package:fomagapp/core/network/util/const.dart';

extension ProductionEnvironment on Environment {
  static Environment production([String? url]) {
    return Environment(
      baseDomain: url ?? 'https://appmovilfomag.fiduprevisora.com.co/prd',
      envName: Const.enviromentRelease,
    );
  }
}
