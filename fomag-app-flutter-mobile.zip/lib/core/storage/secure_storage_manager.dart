import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:fomagapp/data/model/jwt_model.dart';
import 'package:jose/jose.dart';

class SecureStorageManager {
  static const AndroidOptions _androidOptions = AndroidOptions(
    encryptedSharedPreferences: true,
  );

  static FlutterSecureStorage _storage = FlutterSecureStorage(
    aOptions: _androidOptions,
  );

  @visibleForTesting
  static Future<JwtUser?> Function()? decodeJwtUserOverride;

  // Método para testing
  @visibleForTesting
  static void setStorage(FlutterSecureStorage storage) {
    _storage = storage;
  }

  // Keys
  static const String keyDocumentNumber = 'documentNumber';
  static const String keyPassword = 'password';
  static const String keySessionToken = 'session_token';
  static const String keyChallenge = 'challenge';
  static const String keyChallengeName = 'challenge_name';
  static const String keyUserName = 'userName';
  static const String keyAccessToken = 'access_token';
  static const String keyRefreshToken = 'refresh_token';
  static const String keyTypeDocument = 'typeDocument';
  static const String keyIdToken = 'id_token';

  // Setters
  static Future<void> setDocumentNumber(String email) async {
    await _storage.write(key: keyDocumentNumber, value: email);
  }

  static Future<void> setProfile(Map<String, dynamic> profile) async {
    final jsonString = jsonEncode(profile); // Convertir Map a String
    await _storage.write(key: 'keyProfile', value: jsonString);
  }

  static Future<void> setPassword(String password) async {
    await _storage.write(key: keyPassword, value: password);
  }

  static Future<void> setSessionToken(String token) async {
    await _storage.write(key: keySessionToken, value: token);
  }

  static Future<void> setChallenge(String challenge) async {
    await _storage.write(key: keyChallenge, value: challenge);
  }

  static Future<void> setChallengeName(String challengeName) async {
    await _storage.write(key: keyChallengeName, value: challengeName);
  }

  static Future<void> setUserName(String userName) async {
    await _storage.write(key: keyUserName, value: userName);
  }

  static Future<void> setAccessToken(String accessToken) async {
    await _storage.write(key: keyAccessToken, value: accessToken);
  }

  static Future<void> setRefreshToken(String refreshToken) async {
    await _storage.write(key: keyRefreshToken, value: refreshToken);
  }

  static Future<void> setTypeDocument(String typeDocument) async {
    await _storage.write(key: keyTypeDocument, value: typeDocument);
  }

  static Future<void> setIdToken(String idToken) async {
    await _storage.write(key: keyIdToken, value: idToken);
  }

  // Getters
  static Future<String?> getDocumentNumber() async {
    return await _storage.read(key: keyDocumentNumber);
  }

  static Future<Map<String, dynamic>?> getProfileMap() async {
    final jsonString = await _storage.read(key: 'keyProfile');
    if (jsonString == null) return null;

    return jsonDecode(jsonString); // Convertir String a Map
  }

  static Future<String?> getPassword() async {
    return await _storage.read(key: keyPassword);
  }

  static Future<String?> getSessionToken() async {
    return await _storage.read(key: keySessionToken);
  }

  static Future<String?> getChallenge() async {
    return await _storage.read(key: keyChallenge);
  }

  static Future<String?> getChallengeName() async {
    return await _storage.read(key: keyChallengeName);
  }

  static Future<String?> getUserName() async {
    return await _storage.read(key: keyUserName);
  }

  static Future<String?> getAccessToken() async {
    return await _storage.read(key: keyAccessToken);
  }

  static Future<String?> getRefreshToken() async {
    return await _storage.read(key: keyRefreshToken);
  }

  static Future<String?> getTypeDocument() async {
    return await _storage.read(key: keyTypeDocument);
  }

  static Future<String?> getIdToken() async {
    return await _storage.read(key: keyIdToken);
  }

  static Future<JwtUser?> decodeJwtUser() async {
    if (decodeJwtUserOverride != null) return decodeJwtUserOverride!();

    final jwtRaw = await _storage.read(key: keyIdToken);
    if (jwtRaw == null) return null;

    final jwt = JsonWebToken.unverified(jwtRaw);
    final payload = jwt.claims.toJson();

    return JwtUser.fromJson(payload);
  }

  // Clear
  static Future<void> clearAll() async {
    await _storage.deleteAll();
  }

  static Future<void> clearSession() async {
    final keysToKeep = [
      keySessionToken,
      keyRefreshToken,
      keyAccessToken,
      keyChallenge,
      keyChallengeName,
      keyIdToken,
      keyUserName,
    ];

    for (var key in keysToKeep) {
      await _storage.delete(key: key);
    }
  }
}
