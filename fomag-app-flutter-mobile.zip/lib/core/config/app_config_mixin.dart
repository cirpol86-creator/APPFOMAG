mixin AppConfigMixin {
  late String baseDomain;
  late String enviromentName;
}
