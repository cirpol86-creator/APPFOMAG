import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/dependencies/usecase_module.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_bloc.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_bloc.dart';
import 'package:fomagapp/presentation/health/bloc/health_center_bloc.dart';
import 'package:fomagapp/presentation/home/bloc/home_bloc.dart';
import 'package:fomagapp/presentation/login/bloc/login_bloc.dart';
import 'package:fomagapp/presentation/new_info/bloc/news_by_id_bloc.dart';
import 'package:fomagapp/presentation/otp_verification/bloc/otp_verification_bloc.dart';
import 'package:fomagapp/presentation/password_reset/bloc/password_reset_bloc.dart';
import 'package:fomagapp/presentation/register/bloc/register_bloc.dart';
import 'package:fomagapp/presentation/splash/bloc/splash_cubit.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_bloc.dart';

mixin BlocModule on UseCaseModule {
  List<BlocProvider<LoginBloc>> get loginBlocProvider => [
    BlocProvider<LoginBloc>(
      create:
          (context) => LoginBloc(
            loginUseCase: loginUseCase,
            trackUserEventUseCase: trackUserEventUseCase,
          ),
    ),
  ];

  List<BlocProvider<HealthCenterBloc>> get healthCenterBlocProvider => [
    BlocProvider<HealthCenterBloc>(
      create:
          (context) => HealthCenterBloc(
            getHealthCenterUsecase: getHealthCenterUsecase,
            getDepartmentsUsecase: getDepartmentsUsecase,
            getCitiesUsecase: getCitiesUsecase,
          ),
    ),
  ];

  List<BlocProvider<HomeBloc>> get homeBlocProvider => [
    BlocProvider<HomeBloc>(
      create:
          (context) => HomeBloc(
            newsUseCase: newsUseCase,
            trackUserEventUseCase: trackUserEventUseCase,
            getBannerUseCase: getBannerUseCase,
          ),
    ),
  ];

  List<BlocProvider<NewsByIdBloc>> get newsBlocProvider => [
    BlocProvider<NewsByIdBloc>(
      create: (context) => NewsByIdBloc(newsByIdUseCase: newsByIdUseCase),
    ),
  ];

  List<BlocProvider<OtpVerificationBloc>> get otpVerificationBlocProvider => [
    BlocProvider<OtpVerificationBloc>(
      create:
          (context) => OtpVerificationBloc(
            otpVerificationUseCase: otpVerificationUseCase,
          ),
    ),
  ];

  List<BlocProvider<RegisterBloc>> get registerBlocProvider => [
    BlocProvider<RegisterBloc>(
      create:
          (context) => RegisterBloc(
            registerUseCase: registerUseCase,
            trackUserEventUseCase: trackUserEventUseCase,
          ),
    ),
  ];

  List<BlocProvider<PasswordResetBloc>> get passwordResetBlocProvider => [
    BlocProvider<PasswordResetBloc>(
      create:
          (context) => PasswordResetBloc(
            sendCodeUseCase: sendEmailCodeUseCase,
            changePasswordUseCase: otpCodePasswordUseCase,
            trackUserEventUseCase: trackUserEventUseCase,
          ),
    ),
  ];

  List<BlocProvider<CertificatesTypeBloc>> get certificateTypeBlocProvider => [
    BlocProvider<CertificatesTypeBloc>(
      create:
          (context) => CertificatesTypeBloc(
            certificatesUsecase: getTypesCertificatesUsecase,
            getParamsCertificateByIdUsecase: getParamsCertificateByIdUsecase,
          ),
    ),
  ];

  List<BlocProvider<CertificateGenerateBloc>> get certificateBlocProvider => [
    BlocProvider<CertificateGenerateBloc>(
      create:
          (context) => CertificateGenerateBloc(
            generateCertificateUseCase: generateCertificateUsecase,
            downloadPdfUseCase: downloadPdfUseCase,
            garnishmentsListUsecase: garnishmentsListUsecase,
            paymentInterestUsecase: paymentInterestUsecase,
            trackUserEventUseCase: trackUserEventUseCase,
          ),
    ),
  ];

  List<BlocProvider<SplashCubit>> get splashCubit => [
    BlocProvider<SplashCubit>(
      create: (context) => SplashCubit(trackUserEvent: trackUserEventUseCase),
    ),
  ];

  List<BlocProvider<TermsConditionsBloc>> get termsConditionsBlocProvider => [
    BlocProvider<TermsConditionsBloc>(
      create:
          (context) => TermsConditionsBloc(
            termsConditionsUsecase: termsConditionsUsecase,
          ),
    ),
  ];

  List<BlocProvider<ContactBloc>> get contactBlocProvider => [
    BlocProvider<ContactBloc>(
      create:
          (context) =>
              ContactBloc(getContactListUseCase: getContactListUseCase),
    ),
  ];

  List<BlocProvider<DeleteAccountBloc>> get deleteAccountProvider => [
    BlocProvider<DeleteAccountBloc>(
      create:
          (context) => DeleteAccountBloc(
            deleteAccountUsecase: deleteAccountUsecase,
            logoutUsecase: logoutUsecase,
            trackUserEventUseCase: trackUserEventUseCase,
          ),
    ),
  ];

  List<BlocProvider> get blocProviders => [
    ...loginBlocProvider,
    ...healthCenterBlocProvider,
    ...homeBlocProvider,
    ...otpVerificationBlocProvider,
    ...registerBlocProvider,
    ...passwordResetBlocProvider,
    ...newsBlocProvider,
    ...certificateTypeBlocProvider,
    ...certificateBlocProvider,
    ...splashCubit,
    ...termsConditionsBlocProvider,
    ...contactBlocProvider,
    ...deleteAccountProvider,
  ];
}
