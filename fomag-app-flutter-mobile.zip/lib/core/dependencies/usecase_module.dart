import 'package:fomagapp/presentation/account/usecase/delete_account_usecase.dart';
import 'package:fomagapp/presentation/account/usecase/logout_usecase.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/garnishments_list_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/generate_certificate_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_params_certificate_by_id.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_types_certificates_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/payment_interest_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_cities_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_departments_usecase.dart';
import 'package:fomagapp/presentation/contact/usecase/get_contact_list_usecase.dart';
import 'package:fomagapp/presentation/home/usecases/get_banner_use_case.dart';
import 'package:fomagapp/presentation/new_info/usecase/news_by_id_usecase.dart';
import 'package:fomagapp/presentation/home/usecases/news_usecase.dart';
import 'package:fomagapp/presentation/login/usecase/login_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_health_center_usecase.dart';
import 'package:fomagapp/presentation/otp_verification/usecase/otp_verification_usecase.dart';
import 'package:fomagapp/presentation/password_reset/usecase/change_password_usecase.dart';
import 'package:fomagapp/presentation/password_reset/usecase/send_email_code_usecase.dart';
import 'package:fomagapp/presentation/register/usecase/register_usecase.dart';
import 'package:fomagapp/presentation/terms_conditions/usecase/terms_conditions_usecase.dart';
import 'package:fomagapp/presentation/widgets/download_pdf/download_pdf.dart';

import 'repository_module.dart';

mixin UseCaseModule on RepositoryModule {
  LoginUseCase get loginUseCase {
    return LoginUseCase(login: loginRepository);
  }

  RegisterUseCase get registerUseCase {
    return RegisterUseCase(register: registerRepository);
  }

  GetHealthCenterUsecase get getHealthCenterUsecase {
    return GetHealthCenterUsecase(
      healthCenterRepository: healthCenterRepository,
    );
  }

  OtpVerificationUseCase get otpVerificationUseCase {
    return OtpVerificationUseCase(repository: otpVerificationRepository);
  }

  SendCodeUseCase get sendEmailCodeUseCase {
    return SendCodeUseCase(sendEmailCode: sendEmailCodeRepository);
  }

  ChangePasswordUseCase get otpCodePasswordUseCase {
    return ChangePasswordUseCase(repository: confirmForgotPasswordRepository);
  }

  NewsByIdUseCase get newsByIdUseCase {
    return NewsByIdUseCase(repository: newsByIdRepository);
  }

  NewsUseCase get newsUseCase {
    return NewsUseCase(repository: newsRepository);
  }

  GetTypesCertificatesUsecase get getTypesCertificatesUsecase {
    return GetTypesCertificatesUsecase(
      certificateRepository: certificatesRepository,
    );
  }

  GenerateCertificateUsecase get generateCertificateUsecase {
    return GenerateCertificateUsecase(
      certificateRepository: certificatesRepository,
    );
  }

  GetParamsCertificateByIdUsecase get getParamsCertificateByIdUsecase {
    return GetParamsCertificateByIdUsecase();
  }

  DownloadPdfUseCase get downloadPdfUseCase {
    return DownloadPdfUseCase();
  }

  GarnishmentsListUsecase get garnishmentsListUsecase {
    return GarnishmentsListUsecase(
      garnishmentsRepository: garnishmentsRepository,
    );
  }

  GetDepartmentsUsecase get getDepartmentsUsecase {
    return GetDepartmentsUsecase(repository: departmentsHealthCenterRepository);
  }

  GetCitiesUsecase get getCitiesUsecase {
    return GetCitiesUsecase(repository: citiesRepository);
  }

  GetContactListUseCase get getContactListUseCase {
    return GetContactListUseCase(contactRepository: contactRepository);
  }

  TermsConditionsUsecase get termsConditionsUsecase {
    return TermsConditionsUsecase(
      termsConditionsRepository: termsConditionsRepository,
    );
  }

  TrackUserEventUseCase get trackUserEventUseCase {
    return TrackUserEventUseCase(analyticsRepository: analyticsRepository);
  }

  DeleteAccountUsecase get deleteAccountUsecase {
    return DeleteAccountUsecase(
      deleteAccountRepository: deleteAccountRepository,
    );
  }

  PaymentInterestUsecase get paymentInterestUsecase {
    return PaymentInterestUsecase(
      certificatesRepository: certificatesRepository,
    );
  }

  LogoutUsecase get logoutUsecase {
    return LogoutUsecase(repository: logoutRepository);
  }

  GetBannerUseCase get getBannerUseCase {
    return GetBannerUseCase(bannerRepository: bannerRepository);
  }
}
