import 'package:fomagapp/core/analytics/analytics_service.dart';
import 'package:fomagapp/core/network/services/abstract/banner_service.dart';
import 'package:fomagapp/core/network/services/abstract/certificate_service.dart';
import 'package:fomagapp/core/network/services/abstract/cities_service.dart';
import 'package:fomagapp/core/network/services/abstract/confirm_forgot_password_service.dart';
import 'package:fomagapp/core/network/services/abstract/departments_health_center_service.dart';
import 'package:fomagapp/core/network/services/abstract/health_center_service.dart';
import 'package:fomagapp/core/network/services/abstract/logout_service.dart';
import 'package:fomagapp/core/network/services/abstract/payment_interest_certificate_service.dart';
import 'package:fomagapp/core/network/services/implementation/banner_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/cities_impl.dart';
import 'package:fomagapp/core/network/services/implementation/confirm_forgot_password_impl.dart';
import 'package:fomagapp/core/network/services/abstract/garnishments_service.dart';
import 'package:fomagapp/core/network/services/implementation/departments_impl.dart';
import 'package:fomagapp/core/network/services/abstract/delete_account_service.dart';
import 'package:fomagapp/core/network/services/abstract/terms_conditions_service.dart';
import 'package:fomagapp/core/network/services/abstract/contact_services.dart';
import 'package:fomagapp/core/network/services/implementation/delete_account_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/garnishments_list_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/contact_services_impl.dart';
import 'package:fomagapp/core/network/services/implementation/get_types_certificates_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/health_center_impl.dart';
import 'package:fomagapp/core/network/services/implementation/logout_impl.dart';
import 'package:fomagapp/core/network/services/implementation/news_id_by_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/news_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/otp_validate_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/payment_interest_certificate_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/register_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/send_email_code_service_impl.dart';
import 'package:fomagapp/core/network/services/abstract/login_service.dart';
import 'package:fomagapp/core/network/services/implementation/login_service_impl.dart';
import 'package:fomagapp/core/network/services/abstract/news_by_id_service.dart';
import 'package:fomagapp/core/network/services/abstract/news_service.dart';
import 'package:fomagapp/core/network/services/abstract/otp_validate_service.dart';
import 'package:fomagapp/core/network/services/abstract/register_service.dart';
import 'package:fomagapp/core/network/services/abstract/send_email_code_service.dart';
import 'package:fomagapp/core/network/services/implementation/terms_conditions_service_impl.dart';

import 'client_module.dart';

mixin ServiceModule on ClientModule {
  LoginService get loginService {
    return LoginServiceImpl(apiClient: apiClient);
  }

  RegisterService get registerService {
    return RegisterServiceImpl(apiClient: apiClient);
  }

  OtpValidateService get otpService {
    return OtpValidateServiceImpl(apiClient: apiClient);
  }

  SendEmailCodeService get sendEmailCodeService {
    return SendEmailCodeServiceImpl(apiClient: apiClient);
  }

  ConfirmForgotPasswordService get confirmForgotPasswordService {
    return ConfirmForgotPasswordServiceImpl(apiClient: apiClient);
  }

  NewsByIdService get newsByIdService {
    return NewsByIdServiceImpl(apiClient: apiClientToken);
  }

  NewsService get newsService {
    return NewsServiceImpl(apiClient: apiClientToken);
  }

  CertificateService get getTypesCertificates {
    return GetTypesCertificatesServiceImpl(apiClient: apiClientToken);
  }

  GarnishmentsService get garnishmentsService {
    return GarnishmentsListImpl(apiClient: apiClientToken);
  }

  HealthCenterService get healthCenterService {
    return HealthCenterImpl(apiClient: apiClientToken);
  }

  DepartmentsHealthCenterService get departmentsHealthCenterService {
    return DepartmentsImpl(apiClient: apiClientToken);
  }

  CitiesService get citiesService {
    return CitiesImpl(apiClient: apiClientToken);
  }

  AnalyticsService get analyticsService {
    return AnalyticsService(analytics: firebaseAnalytics);
  }

  TermsConditionsService get termsConditionsService {
    return TermsConditionsServiceImpl(apiClient: apiClient);
  }

  ContactService get contactService {
    return ContactServiceImpl(apiClient: apiClientToken);
  }

  DeleteAccountService get deleteAccountService {
    return DeleteAccountServiceImpl(apiClient: apiClientToken);
  }

  PaymentInterestCertificateService get paymentInterestService {
    return PaymentInterestCertificateServiceImpl(apiClient: apiClientToken);
  }

  LogoutService get logoutService {
    return LogoutServiceImpl(apiClient: apiClientToken);
  }

  BannerService get bannerService {
    return BannerServiceImpl(apiClient: apiClientToken);
  }
}
