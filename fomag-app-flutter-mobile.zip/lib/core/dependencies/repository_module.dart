import 'package:fomagapp/core/dependencies/services_module.dart';
import 'package:fomagapp/data/repositories/analytics_repository.dart';
import 'package:fomagapp/data/repositories/banner_repository.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';
import 'package:fomagapp/data/repositories/cities_repository.dart';
import 'package:fomagapp/data/repositories/confirm_forgot_password_repository.dart';
import 'package:fomagapp/data/repositories/delete_account_repository.dart';
import 'package:fomagapp/data/repositories/departments_health_center_repository.dart';
import 'package:fomagapp/data/repositories/garnishments_repository.dart';
import 'package:fomagapp/data/repositories/contact_info_repository.dart';
import 'package:fomagapp/data/repositories/login_repository.dart';
import 'package:fomagapp/data/repositories/health_center_repository.dart';
import 'package:fomagapp/data/repositories/logout_repository.dart';
import 'package:fomagapp/data/repositories/news_by_id_repository.dart';
import 'package:fomagapp/data/repositories/news_repository.dart';
import 'package:fomagapp/data/repositories/otp_verification_repository.dart';
import 'package:fomagapp/data/repositories/register_repository.dart';
import 'package:fomagapp/data/repositories/send_email_code_repository.dart';
import 'package:fomagapp/data/repositories/terms_conditions_repository.dart';

mixin RepositoryModule on ServiceModule {
  LoginRepository get loginRepository {
    return LoginRepository(login: loginService);
  }

  RegisterRepository get registerRepository {
    return RegisterRepository(register: registerService);
  }

  HealthCenterRepository get healthCenterRepository {
    return HealthCenterRepository(healthCenterService: healthCenterService);
  }

  OtpVerificationRepository get otpVerificationRepository {
    return OtpVerificationRepository(service: otpService);
  }

  SendEmailCodeRepository get sendEmailCodeRepository {
    return SendEmailCodeRepository(sendEmailCode: sendEmailCodeService);
  }

  ConfirmForgotPasswordRepository get confirmForgotPasswordRepository {
    return ConfirmForgotPasswordRepository(
      service: confirmForgotPasswordService,
    );
  }

  NewsByIdRepository get newsByIdRepository {
    return NewsByIdRepository(service: newsByIdService);
  }

  NewsRepository get newsRepository {
    return NewsRepository(service: newsService);
  }

  CertificatesRepository get certificatesRepository {
    return CertificatesRepository(
      certificateService: getTypesCertificates,
      paymentInterestCertificateService: paymentInterestService,
    );
  }

  GarnishmentsRepository get garnishmentsRepository {
    return GarnishmentsRepository(garnishmentsService: garnishmentsService);
  }

  AnalyticsRepository get analyticsRepository {
    return AnalyticsRepository(analyticsService: analyticsService);
  }

  TermsConditionsRepository get termsConditionsRepository {
    return TermsConditionsRepository(termsConditions: termsConditionsService);
  }

  ContactRepository get contactRepository {
    return ContactRepository(contactService: contactService);
  }

  DeleteAccountRepository get deleteAccountRepository {
    return DeleteAccountRepository(deleteAccountService: deleteAccountService);
  }

  DepartmentsHealthCenterRepository get departmentsHealthCenterRepository {
    return DepartmentsHealthCenterRepository(
      service: departmentsHealthCenterService,
    );
  }

  CitiesRepository get citiesRepository {
    return CitiesRepository(service: citiesService);
  }

  LogoutRepository get logoutRepository {
    return LogoutRepository(service: logoutService);
  }

  BannerRepository get bannerRepository {
    return BannerRepository(bannerService: bannerService);
  }
}
