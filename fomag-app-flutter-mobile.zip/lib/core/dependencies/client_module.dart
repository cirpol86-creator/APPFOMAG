import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';
import 'package:fomagapp/core/network/api_client_impl.dart';
import 'package:fomagapp/core/network/api_client.dart';

mixin ClientModule on ConfigModule {
  ApiClient get apiClient {
    return ApiClientImpl.apiClient(
      baseDomain: appConfig.baseDomain,
      ignoreToken: true,
    );
  }

  ApiClient get apiClientToken {
    return ApiClientImpl.apiClient(
      baseDomain: appConfig.baseDomain,
      ignoreToken: false,
    );
  }

  FirebaseAnalytics get firebaseAnalytics {
    return FirebaseAnalytics.instance;
  }
}
