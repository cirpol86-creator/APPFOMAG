import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/config/app_config_mixin.dart';

mixin ConfigModule {
  AppConfigMixin get appConfig {
    return AppConfig.shared;
  }
}
