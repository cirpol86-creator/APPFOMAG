# fomagapp

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

flutter run lib/flavors/main_qa.dart
flutter run lib/flavors/main_prod.dart 
flutter run lib/flavors/main_dev.dart 

flutter build apk --flavor dev -t lib/flavors/main_dev.dart
flutter build apk --flavor qa -t lib/flavors/main_qa.dart
flutter build apk --flavor prod -t lib/flavors/main_prod.dart

flutter run --flavor dev -t lib/flavors/main_dev.dart
flutter run --flavor dev -t lib/flavors/main_qa.dart


