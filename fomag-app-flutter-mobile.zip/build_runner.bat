@echo off
flutter pub run build_runner build --delete-conflicting-outputs
pause 