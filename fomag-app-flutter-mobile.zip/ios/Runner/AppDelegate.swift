import Flutter
import UIKit
import GoogleMaps

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)
    GMSServices.provideAPIKey("AIzaSyBkA0OLyYRgQAKPzdLVEM24tSUNe2NEaFs") // 👈 Agregar aquí la API Key
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
