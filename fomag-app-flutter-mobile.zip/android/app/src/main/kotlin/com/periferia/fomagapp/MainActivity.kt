package com.periferia.fomagapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
