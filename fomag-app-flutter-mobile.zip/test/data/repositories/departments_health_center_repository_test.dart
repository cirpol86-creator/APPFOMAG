import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/data/repositories/departments_health_center_repository.dart';
import 'package:fomagapp/core/network/services/abstract/departments_health_center_service.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/core/network/error/failure.dart';

import 'departments_health_center_repository_test.mocks.dart';

@GenerateMocks([DepartmentsHealthCenterService])
class TestDepartmentsHealthCenterRepository
    extends DepartmentsHealthCenterRepository {
  TestDepartmentsHealthCenterRepository({
    required DepartmentsHealthCenterService service,
  }) : super(service: service);

  @override
  Future<bool> isInConnection() async => true;
}

class TestDepartmentsHealthCenterRepositoryNoConnection
    extends DepartmentsHealthCenterRepository {
  TestDepartmentsHealthCenterRepositoryNoConnection({
    required DepartmentsHealthCenterService service,
  }) : super(service: service);

  @override
  Future<bool> isInConnection() async => false;
}

void main() {
  late MockDepartmentsHealthCenterService mockService;
  late DepartmentsHealthCenterRepository repository;

  final mockResponse = [
    DepartmentsHealthCenterResponse(id: 1, name: 'Salud Norte'),
    DepartmentsHealthCenterResponse(id: 2, name: 'Salud Sur'),
  ];

  setUp(() {
    mockService = MockDepartmentsHealthCenterService();
    repository = TestDepartmentsHealthCenterRepository(service: mockService);
  });

  test('debe retornar lista de departamentos de salud correctamente', () async {
    when(mockService()).thenAnswer((_) async => mockResponse);

    final result = await repository.call();

    expect(result, Right(mockResponse));
    verify(mockService()).called(1);
  });

  test(
    'debe retornar ServerFailure en DioException tipo connectionError',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'No hay conexión',
      );

      when(mockService()).thenThrow(dioException);

      final result = await repository.call();

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test(
    'debe retornar ServerFailure en DioException tipo badResponse',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.badResponse,
        message: 'Error del servidor',
      );

      when(mockService()).thenThrow(dioException);

      final result = await repository.call();

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.badResponse);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test('debe retornar NoConnectionFailure cuando no hay conexión', () async {
    repository = TestDepartmentsHealthCenterRepositoryNoConnection(
      service: mockService,
    );

    final result = await repository.call();

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('No debe retornar éxito'),
    );
  });
}
