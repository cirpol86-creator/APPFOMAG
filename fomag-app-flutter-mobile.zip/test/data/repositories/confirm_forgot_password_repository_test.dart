import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';

import 'package:fomagapp/data/repositories/confirm_forgot_password_repository.dart';
import 'package:fomagapp/core/network/services/abstract/confirm_forgot_password_service.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:fomagapp/core/network/error/failure.dart';

import 'confirm_forgot_password_repository_test.mocks.dart';

@GenerateMocks([ConfirmForgotPasswordService])
class TestRepository extends ConfirmForgotPasswordRepository {
  TestRepository({required ConfirmForgotPasswordService service})
    : super(service: service);

  @override
  Future<bool> isInConnection() async => true;
}

class TestRepositoryNoConnection extends ConfirmForgotPasswordRepository {
  TestRepositoryNoConnection({required ConfirmForgotPasswordService service})
    : super(service: service);

  @override
  Future<bool> isInConnection() async => false;
}

void main() {
  late MockConfirmForgotPasswordService mockService;
  late ConfirmForgotPasswordRepository repository;

  final request = ConfirmForgotPasswordRequest(
    documentType: '1',
    documentNumber: '12345678',
    password: 'newpass123',
    code: 'ABC123',
  );

  final response = ConfirmForgotPasswordResponse(
    message: 'Contraseña cambiada',
  );

  setUp(() {
    mockService = MockConfirmForgotPasswordService();
    repository = TestRepository(service: mockService);
  });

  test('debe retornar ConfirmForgotPasswordResponse en éxito', () async {
    when(mockService.call(request)).thenAnswer((_) async => response);

    final result = await repository.confirmForgotPassword(request);

    expect(result, Right(response));
    verify(mockService.call(request)).called(1);
  });

  test(
    'debe retornar ServerFailure en DioException de tipo connectionError',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'Sin conexión',
      );

      when(mockService.call(request)).thenThrow(dioException);

      final result = await repository.confirmForgotPassword(request);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test(
    'debe retornar ServerFailure en DioException de tipo diferente',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.badResponse,
        message: 'Respuesta inválida',
      );

      when(mockService.call(request)).thenThrow(dioException);

      final result = await repository.confirmForgotPassword(request);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.badResponse);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test('debe retornar NoConnectionFailure si no hay conexión', () async {
    repository = TestRepositoryNoConnection(service: mockService);

    final result = await repository.confirmForgotPassword(request);

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('No debe retornar éxito'),
    );
  });
}
