import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/analytics/analytics_service.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/data/repositories/analytics_repository.dart';

import 'analytics_repository_test.mocks.dart';

@GenerateMocks([AnalyticsService])
void main() {
  late MockAnalyticsService mockAnalyticsService;
  late AnalyticsRepository repository;

  setUp(() {
    mockAnalyticsService = MockAnalyticsService();
    repository = AnalyticsRepository(analyticsService: mockAnalyticsService);
  });

  test(
    'debe llamar a sendEvent en analyticsService con los datos correctos',
    () async {
      final event = UserEventModel(UserEventType.login, {'user': 'testUser'});

      when(
        mockAnalyticsService.sendEvent(event),
      ).thenAnswer((_) async => Future.value());

      await repository.logEvent(event);

      verify(mockAnalyticsService.sendEvent(event)).called(1);
    },
  );
}
