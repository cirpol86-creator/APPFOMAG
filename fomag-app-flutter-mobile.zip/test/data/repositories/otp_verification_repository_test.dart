import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/otp_validate_service.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/data/repositories/otp_verification_repository.dart';

import 'otp_verification_repository_test.mocks.dart';

@GenerateMocks([OtpValidateService])
void main() {
  late MockOtpValidateService mockService;
  late OtpVerificationRepository repository;

  final request = OtpValidateRequest(
    userName: 'user',
    code: '123456',
    session: 'session123',
    challengeType: 'SMS',
  );

  final response = OtpValidateResponse(
    accessToken: 'access123',
    idToken: 'id123',
    refreshToken: 'refresh123',
  );

  setUp(() {
    mockService = MockOtpValidateService();
    repository = _TestOtpVerificationRepository(service: mockService);
  });

  test('should return OtpValidateResponse on success', () async {
    when(mockService.call(request)).thenAnswer((_) async => response);

    final result = await repository.otpVerification(request);

    expect(result, isA<Right>());
    result.fold((_) => fail('Expected success'), (res) {
      expect(res.accessToken, equals('access123'));
    });
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService.call(request)).thenThrow(
        DioException(
          type: DioExceptionType.connectionError,
          requestOptions: RequestOptions(path: ''),
          message: 'Connection error',
        ),
      );

      final result = await repository.otpVerification(request);

      expect(result, isA<Left>());
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Expected failure'));
    },
  );

  test('should return ServerFailure on general exception', () async {
    when(mockService.call(request)).thenThrow(Exception('Unknown error'));

    final result = await repository.otpVerification(request);

    expect(result, isA<Left>());
    result.fold((failure) {
      expect(failure, isA<ServerFailure>());
      expect(failure.message, contains('error en la aplicación'));
    }, (_) => fail('Expected failure'));
  });

  test('should return NoConnectionFailure when not connected', () async {
    repository = _TestOtpVerificationRepository(
      service: mockService,
      connected: false,
    );

    final result = await repository.otpVerification(request);

    expect(result, isA<Left>());
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('Expected no connection failure'),
    );
  });
}

/// Repositorio con conectividad simulada para pruebas
class _TestOtpVerificationRepository extends OtpVerificationRepository {
  final bool connected;

  _TestOtpVerificationRepository({
    required OtpValidateService service,
    this.connected = true,
  }) : super(service: service);

  @override
  Future<bool> isInConnection() async => connected;
}
