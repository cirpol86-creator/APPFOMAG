import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/repositories/education_secretaries_repository.dart';

void main() {
  late SecretaryRepository repository;
  const mockJsonData = '''
  [
    { "id": 1, "nombre": "Secretaría de Educación de Bogotá", "url": "https://bogota.gov.co" },
    { "id": 2, "nombre": "Secretaría de Educación de Medellín", "url": "https://medellin.gov.co" },
    { "id": 3, "nombre": "Secretaría de Educación de Cali", "url": "https://cali.gov.co" }
  ]
  ''';

  setUp(() {
    repository = SecretaryRepository();
  });

  test('should load secretarias correctly from json asset', () async {
    // Mock del rootBundle
    const assetPath = 'assets/files/secretaries.json';
    TestWidgetsFlutterBinding.ensureInitialized();
    ServicesBinding.instance.defaultBinaryMessenger.setMockMessageHandler(
      'flutter/assets',
      (message) async {
        final String? key = const StringCodec().decodeMessage(message);
        if (key == assetPath) {
          return const StringCodec().encodeMessage(mockJsonData);
        }
        return null;
      },
    );

    await repository.loadSecretarias();
    final results = repository.getSecretarias(page: 1, pageSize: 20);

    expect(results.length, 3);
    expect(results[0].nombre, contains('Bogotá'));
    expect(repository.totalPages, 1);
  });

  test('should paginate secretarias list correctly', () async {
    // Cargar secretarias desde mock
    TestWidgetsFlutterBinding.ensureInitialized();
    ServicesBinding.instance.defaultBinaryMessenger.setMockMessageHandler(
      'flutter/assets',
      (message) async => const StringCodec().encodeMessage(mockJsonData),
    );

    await repository.loadSecretarias();

    final firstPage = repository.getSecretarias(page: 1, pageSize: 2);
    expect(firstPage.length, 2);

    final secondPage = repository.getSecretarias(page: 2, pageSize: 2);
    expect(secondPage.length, 1);

    final thirdPage = repository.getSecretarias(page: 3, pageSize: 2);
    expect(thirdPage.length, 0);
  });

  test('should filter secretarias by query', () async {
    // Cargar secretarias desde mock
    TestWidgetsFlutterBinding.ensureInitialized();
    ServicesBinding.instance.defaultBinaryMessenger.setMockMessageHandler(
      'flutter/assets',
      (message) async => const StringCodec().encodeMessage(mockJsonData),
    );

    await repository.loadSecretarias();

    final filtered = repository.getSecretarias(page: 1, query: 'Medellín');

    expect(filtered.length, 1);
    expect(filtered[0].nombre, contains('Medellín'));
  });
}
