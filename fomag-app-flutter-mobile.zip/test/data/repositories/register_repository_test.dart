import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/register_service.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/data/repositories/register_repository.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'register_repository_test.mocks.dart';

@GenerateMocks([RegisterService, Connectivity])
class TestRegisterRepository extends RegisterRepository {
  bool connectionResult = true;
  TestRegisterRepository({required RegisterService registerService})
    : super(register: registerService);

  @override
  Future<bool> isInConnection() async => connectionResult;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late MockRegisterService mockRegisterService;
  late RegisterRepository repository;

  final registerRequest = RegisterRequest();
  final registerResponse = RegisterResponse();

  setUp(() {
    mockRegisterService = MockRegisterService();
    repository = TestRegisterRepository(registerService: mockRegisterService);
  });

  test('should return RegisterResponse on successful register', () async {
    when(
      mockRegisterService.call(registerRequest),
    ).thenAnswer((_) async => registerResponse);

    final result = await repository.register(registerRequest);

    expect(result, Right(registerResponse));
    verify(mockRegisterService.call(registerRequest)).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'Connection error',
      );

      when(mockRegisterService.call(registerRequest)).thenThrow(dioException);

      final result = await repository.register(registerRequest);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not succeed'));
    },
  );

  test('should return ServerFailure on DioException (other)', () async {
    final dioException = DioException(
      requestOptions: RequestOptions(path: ''),
      type: DioExceptionType.badResponse,
      message: 'Bad response',
    );

    when(mockRegisterService.call(registerRequest)).thenThrow(dioException);

    final result = await repository.register(registerRequest);

    expect(result.isLeft(), true);
    result.fold((failure) {
      expect(failure, isA<ServerFailure>());
      expect(failure.data, DioExceptionType.badResponse);
    }, (_) => fail('Should not succeed'));
  });
}
