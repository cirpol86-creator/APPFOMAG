import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/data/repositories/login_repository.dart';
import 'package:fomagapp/core/network/services/abstract/login_service.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import '../../mock/services/mock_login_service.mocks.dart';

@GenerateMocks([LoginService])
class TestLoginRepository extends LoginRepository {
  bool connectionResult = true;
  TestLoginRepository({required LoginService login}) : super(login: login);

  @override
  Future<bool> isInConnection() async => connectionResult;
}

class TestLoginRepositoryNotInternet extends LoginRepository {
  bool connectionResult = false;
  TestLoginRepositoryNotInternet({required LoginService login})
    : super(login: login);

  @override
  Future<bool> isInConnection() async => connectionResult;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late MockLoginService mockLoginService;
  late LoginRepository repository;

  final loginRequest = LoginRequest(
    documentType: '3',
    documentNumber: '121212',
    password: 'testpass',
  );

  final authResponse = AuthResponse(
    userName: 'test',
    challenge: Challenge.mfaRequired,
    session: 'SESSION_ID',
    challengeName: 'CUSTOM_CHALLENGE',
  );

  setUp(() {
    mockLoginService = MockLoginService();
    repository = TestLoginRepository(login: mockLoginService);
  });

  test('should return AuthResponse on successful login', () async {
    when(
      mockLoginService.call(loginRequest),
    ).thenAnswer((_) async => authResponse);

    final result = await repository.login(loginRequest);

    expect(result, Right(authResponse));
    verify(mockLoginService.call(loginRequest)).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'Connection error',
      );

      when(mockLoginService.call(loginRequest)).thenThrow(dioException);

      final result = await repository.login(loginRequest);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not succeed'));
    },
  );

  test('should return ServerFailure on DioException (other)', () async {
    final dioException = DioException(
      requestOptions: RequestOptions(path: ''),
      type: DioExceptionType.badResponse,
      message: 'Bad response',
    );

    when(mockLoginService.call(loginRequest)).thenThrow(dioException);

    final result = await repository.login(loginRequest);

    expect(result.isLeft(), true);
    result.fold((failure) {
      expect(failure, isA<ServerFailure>());
      expect(failure.data, DioExceptionType.badResponse);
    }, (_) => fail('Should not succeed'));
  });

  test(
    'should return NoConnectionFailure when there is no connection',
    () async {
      repository = TestLoginRepositoryNotInternet(login: mockLoginService);

      when(mockLoginService.call(loginRequest)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'No connection',
        ),
      );
      final result = await repository.login(loginRequest);

      expect(result.isLeft(), true);
      result.fold(
        (failure) => expect(failure, isA<NoConnectionFailure>()),
        (_) => fail('Should not succeed'),
      );
    },
  );
}
