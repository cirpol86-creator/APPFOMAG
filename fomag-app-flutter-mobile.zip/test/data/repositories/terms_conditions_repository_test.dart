import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/terms_conditions_service.dart';
import 'package:fomagapp/data/repositories/terms_conditions_repository.dart';

import 'terms_conditions_repository_test.mocks.dart';

@GenerateMocks([TermsConditionsService])
void main() {
  late MockTermsConditionsService mockService;
  late TermsConditionsRepository repository;

  const termsText = 'Términos y condiciones de uso...';

  setUp(() {
    mockService = MockTermsConditionsService();
    repository = _TestTermsConditionsRepository(termsConditions: mockService);
  });

  test(
    'debe retornar el texto de términos y condiciones al tener éxito',
    () async {
      when(
        mockService.fetchTermsAndConditions(),
      ).thenAnswer((_) async => termsText);

      final result = await repository.fetchTermsAndConditions();

      expect(result, isA<Right>());
      result.fold(
        (_) => fail('Se esperaba éxito'),
        (data) => expect(data, equals(termsText)),
      );
    },
  );

  test('debe retornar ServerFailure con DioException de conexión', () async {
    when(mockService.fetchTermsAndConditions()).thenThrow(
      DioException(
        type: DioExceptionType.connectionError,
        requestOptions: RequestOptions(path: ''),
      ),
    );

    final result = await repository.fetchTermsAndConditions();

    expect(result, isA<Left>());
    result.fold(
      (failure) => expect(failure.data, DioExceptionType.connectionError),
      (_) => fail('Se esperaba un error de conexión'),
    );
  });

  test('debe retornar ServerFailure con otro tipo de DioException', () async {
    when(mockService.fetchTermsAndConditions()).thenThrow(
      DioException(
        type: DioExceptionType.unknown,
        requestOptions: RequestOptions(path: ''),
        message: 'Error inesperado',
      ),
    );

    final result = await repository.fetchTermsAndConditions();

    expect(result, isA<Left>());
    result.fold((failure) {
      expect(failure, isA<ServerFailure>());
      expect(failure.message, contains('Error inesperado'));
    }, (_) => fail('Se esperaba error'));
  });

  test('debe retornar NoConnectionFailure si no hay conexión', () async {
    repository = _TestTermsConditionsRepository(
      termsConditions: mockService,
      connected: false,
    );

    final result = await repository.fetchTermsAndConditions();

    expect(result, isA<Left>());
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('Se esperaba NoConnectionFailure'),
    );
  });
}

/// Subclase del repositorio que permite forzar conectividad o no
class _TestTermsConditionsRepository extends TermsConditionsRepository {
  final bool connected;

  _TestTermsConditionsRepository({
    required TermsConditionsService termsConditions,
    this.connected = true,
  }) : super(termsConditions: termsConditions);

  @override
  Future<bool> isInConnection() async => connected;
}
