import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/news_service.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/data/repositories/news_repository.dart';

import 'news_repository_test.mocks.dart';

@GenerateMocks([NewsService])
void main() {
  late MockNewsService mockService;
  late NewsRepository repository;

  final newsResponse = NewsResponse(
    httpCode: 200,
    message: 'Success',
    content: [
      NewsContent(
        id: 1,
        title: 'Noticia 1',
        imageBanner: 'https://example.com/banner.jpg',
        idReference: 101,
        body: 'Contenido de la noticia',
        date: '2025-07-08',
      ),
    ],
  );

  setUp(() {
    mockService = MockNewsService();
    repository = _TestNewsRepository(service: mockService);
  });

  test('should return NewsResponse on success', () async {
    when(mockService()).thenAnswer((_) async => newsResponse);

    final result = await repository.news();

    expect(result, isA<Right>());
    result.fold((_) => fail('Should return success'), (res) {
      expect(res.httpCode, 200);
      expect(res.content.first.title, 'Noticia 1');
    });
    verify(mockService()).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService()).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'No connection',
        ),
      );

      final result = await repository.news();

      expect(result, isA<Left>());
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not return success'));
    },
  );

  test('should return NoConnectionFailure when not connected', () async {
    repository = _TestNewsRepository(service: mockService, connected: false);

    final result = await repository.news();

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('Should not return success'),
    );
  });
}

/// Repositorio con conectividad forzada
class _TestNewsRepository extends NewsRepository {
  final bool connected;

  _TestNewsRepository({required NewsService service, this.connected = true})
    : super(service: service);

  @override
  Future<bool> isInConnection() async => connected;
}
