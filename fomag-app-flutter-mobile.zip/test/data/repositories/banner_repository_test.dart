import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/banner_service.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';
import 'package:fomagapp/data/repositories/banner_repository.dart';

import 'banner_repository_test.mocks.dart';

@GenerateMocks([BannerService, BannerRepository])
void main() {
  late MockBannerService mockBannerService;
  late BannerRepository bannerRepository;

  setUp(() {
    mockBannerService = MockBannerService();
    bannerRepository = BannerRepository(bannerService: mockBannerService);
  });

  test(
    'debe retornar BannerResponse cuando el servicio responde correctamente',
    () async {
      final mockResponse = BannerResponse(
        message: 'Banner retrieved successfully',
        type: 'image',
        url: 'https://example.com/banner.jpg',
      );

      when(mockBannerService.getBanner()).thenAnswer((_) async => mockResponse);
      when(bannerRepository.isInConnection()).thenAnswer((_) async => true);

      final result = await bannerRepository.getBanner();

      expect(result.isRight(), true);
      expect(result.getOrElse(() => throw Exception()), equals(mockResponse));
    },
  );

  test('debe retornar NoConnectionFailure cuando no hay conexión', () async {
    when(bannerRepository.isInConnection()).thenAnswer((_) async => false);

    final result = await bannerRepository.getBanner();

    expect(result.isLeft(), true);
    expect(result, const Left(NoConnectionFailure()));
  });

  test('debe retornar ServerFailure cuando hay un error de conexión', () async {
    final dioException = DioException(
      type: DioExceptionType.connectionError,
      requestOptions: RequestOptions(path: '/banner'),
    );

    when(mockBannerService.getBanner()).thenThrow(dioException);
    when(bannerRepository.isInConnection()).thenAnswer((_) async => true);

    final result = await bannerRepository.getBanner();

    expect(result.isLeft(), true);
    expect(
      result.fold((l) => l, (_) => null),
      isA<ServerFailure>().having(
        (f) => f.data,
        'data',
        DioExceptionType.connectionError,
      ),
    );
  });

  test(
    'debe retornar ServerFailure para cualquier otro error de Dio',
    () async {
      final dioException = DioException(
        type: DioExceptionType.receiveTimeout,
        requestOptions: RequestOptions(path: '/banner'),
        message: 'Timeout recibiendo respuesta',
      );

      when(mockBannerService.getBanner()).thenThrow(dioException);
      when(bannerRepository.isInConnection()).thenAnswer((_) async => true);

      final result = await bannerRepository.getBanner();

      expect(result.isLeft(), true);
      expect(
        result.fold((l) => l, (_) => null),
        isA<ServerFailure>()
            .having((f) => f.message, 'message', 'Timeout recibiendo respuesta')
            .having((f) => f.data, 'data', DioExceptionType.receiveTimeout),
      );
    },
  );
}
