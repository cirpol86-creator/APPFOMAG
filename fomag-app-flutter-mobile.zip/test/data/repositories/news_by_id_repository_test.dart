import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/news_by_id_service.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/data/repositories/news_by_id_repository.dart';

import 'news_by_id_repository_test.mocks.dart';

@GenerateMocks([NewsByIdService])
void main() {
  late MockNewsByIdService mockService;
  late NewsByIdRepository repository;

  const uuid = 1;

  final response = NewsByIdResponse(
    httpCode: 200,
    message: 'Success',
    content: NewsByIdContent(
      id: uuid,
      title: 'Título de prueba',
      imagebanner: 'http://image.test/banner.jpg',
      idReference: 123,
      body: 'Contenido de prueba',
      date: '2025-07-08',
    ),
  );

  setUp(() {
    mockService = MockNewsByIdService();
    repository = _TestNewsByIdRepository(service: mockService);
  });

  test('should return NewsByIdResponse on success', () async {
    when(mockService.call(uuid)).thenAnswer((_) async => response);

    final result = await repository.newsById(uuid);

    expect(result, isA<Right>());
    result.fold(
      (_) => fail('Should return success'),
      (res) => expect(res.message, equals('Success')),
    );
    verify(mockService.call(uuid)).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService.call(uuid)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'No connection',
        ),
      );

      final result = await repository.newsById(uuid);

      expect(result, isA<Left>());
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not return success'));
    },
  );

  test('should return NoConnectionFailure when not connected', () async {
    repository = _TestNewsByIdRepository(
      service: mockService,
      connected: false,
    );

    final result = await repository.newsById(uuid);

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('Should not return success'),
    );
  });
}

class _TestNewsByIdRepository extends NewsByIdRepository {
  final bool connected;

  _TestNewsByIdRepository({
    required NewsByIdService service,
    this.connected = true,
  }) : super(service: service);

  @override
  Future<bool> isInConnection() async => connected;
}
