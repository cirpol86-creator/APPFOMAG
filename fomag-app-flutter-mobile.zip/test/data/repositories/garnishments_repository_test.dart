import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/garnishments_service.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/data/repositories/garnishments_repository.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'garnishments_repository_test.mocks.dart';

@GenerateMocks([GarnishmentsService])
void main() {
  late MockGarnishmentsService mockService;
  late GarnishmentsRepository repository;

  final request = GarnishmentRequest(
    documentType: '1',
    documentNumber: '123456',
  );

  final response = [
    GarnishmentsCertificateResponse(
      nameCourt: 'Juzgado 1',
      processNumber: 'PROC123',
    ),
  ];

  setUp(() {
    mockService = MockGarnishmentsService();
    repository = _TestGarnishmentsRepository(mockService);
  });

  test('should return list of garnishment responses on success', () async {
    when(mockService.call(request)).thenAnswer((_) async => response);

    final result = await repository.garnishmentslist(request);

    expect(result, Right(response));
    verify(mockService.call(request)).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService.call(request)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'Connection error',
        ),
      );

      final result = await repository.garnishmentslist(request);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not succeed'));
    },
  );

  test('should return NoConnectionFailure when there is no internet', () async {
    repository = _TestGarnishmentsRepository(mockService, connected: false);

    final result = await repository.garnishmentslist(request);

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('Should not succeed'),
    );
  });
}

class _TestGarnishmentsRepository extends GarnishmentsRepository {
  final bool connected;
  _TestGarnishmentsRepository(
    GarnishmentsService garnishmentsService, {
    this.connected = true,
  }) : super(garnishmentsService: garnishmentsService);

  @override
  Future<bool> isInConnection() async => connected;
}
