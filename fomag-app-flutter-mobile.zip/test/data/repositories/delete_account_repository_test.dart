import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/data/repositories/delete_account_repository.dart';
import 'package:fomagapp/core/network/services/abstract/delete_account_service.dart';
import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';
import 'package:fomagapp/core/network/error/failure.dart';

import 'delete_account_repository_test.mocks.dart';

@GenerateMocks([DeleteAccountService])
class TestDeleteAccountRepository extends DeleteAccountRepository {
  TestDeleteAccountRepository({
    required DeleteAccountService deleteAccountService,
  }) : super(deleteAccountService: deleteAccountService);

  @override
  Future<bool> isInConnection() async => true;
}

class TestDeleteAccountRepositoryNoConnection extends DeleteAccountRepository {
  TestDeleteAccountRepositoryNoConnection({
    required DeleteAccountService deleteAccountService,
  }) : super(deleteAccountService: deleteAccountService);

  @override
  Future<bool> isInConnection() async => false;
}

void main() {
  late MockDeleteAccountService mockDeleteAccountService;
  late DeleteAccountRepository repository;

  const deleteAccountResponse = DeleteAccountResponse(
    message: 'Cuenta eliminada',
  );

  setUp(() {
    mockDeleteAccountService = MockDeleteAccountService();
    repository = TestDeleteAccountRepository(
      deleteAccountService: mockDeleteAccountService,
    );
  });

  test('debe retornar DeleteAccountResponse en éxito', () async {
    when(
      mockDeleteAccountService.deleteAccount(),
    ).thenAnswer((_) async => deleteAccountResponse);

    final result = await repository.deleteAccount();

    expect(result, Right(deleteAccountResponse));
    verify(mockDeleteAccountService.deleteAccount()).called(1);
  });

  test(
    'debe retornar ServerFailure en DioException tipo connectionError',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'Sin conexión',
      );

      when(mockDeleteAccountService.deleteAccount()).thenThrow(dioException);

      final result = await repository.deleteAccount();

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test(
    'debe retornar ServerFailure en DioException tipo badResponse',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.badResponse,
        message: 'Error en servidor',
      );

      when(mockDeleteAccountService.deleteAccount()).thenThrow(dioException);

      final result = await repository.deleteAccount();

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.badResponse);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test('debe retornar NoConnectionFailure cuando no hay conexión', () async {
    repository = TestDeleteAccountRepositoryNoConnection(
      deleteAccountService: mockDeleteAccountService,
    );

    final result = await repository.deleteAccount();

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('No debe retornar éxito'),
    );
  });
}
