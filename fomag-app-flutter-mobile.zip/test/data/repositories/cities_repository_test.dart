import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';

import 'package:fomagapp/data/repositories/cities_repository.dart';
import 'package:fomagapp/core/network/services/abstract/cities_service.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/core/network/error/failure.dart';

import 'cities_repository_test.mocks.dart';

@GenerateMocks([CitiesService])
void main() {
  late MockCitiesService mockService;
  late CitiesRepository repository;

  const requestId = 1;

  final mockResponse = [
    CitiesResponse(id: 1, name: 'Bogotá', departmentId: 11),
    CitiesResponse(id: 2, name: 'Medellín', departmentId: 5),
  ];

  setUp(() {
    mockService = MockCitiesService();
    repository = _TestCitiesRepository(service: mockService);
  });

  test(
    'should return a list of CitiesResponse when service succeeds',
    () async {
      when(mockService.call(requestId)).thenAnswer((_) async => mockResponse);

      final result = await repository.call(requestId);

      expect(result.isRight(), true);
      result.fold((_) => fail('Expected Right, got Left'), (cities) {
        expect(cities.length, 2);
        expect(cities.first.name, 'Bogotá');
      });
    },
  );

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      final exception = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'Connection error',
      );

      when(mockService.call(requestId)).thenThrow(exception);

      final result = await repository.call(requestId);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Expected Left, got Right'));
    },
  );

  test('should return ServerFailure on DioException (other)', () async {
    final exception = DioException(
      requestOptions: RequestOptions(path: ''),
      type: DioExceptionType.badResponse,
      message: 'Bad response',
    );

    when(mockService.call(requestId)).thenThrow(exception);

    final result = await repository.call(requestId);

    expect(result.isLeft(), true);
    result.fold((failure) {
      expect(failure, isA<ServerFailure>());
      expect(failure.data, DioExceptionType.badResponse);
    }, (_) => fail('Expected Left, got Right'));
  });

  test('should return NoConnectionFailure when there is no internet', () async {
    repository = _TestCitiesRepositoryNoInternet(service: mockService);

    final result = await repository.call(requestId);

    expect(result, const Left(NoConnectionFailure()));
  });
}

class _TestCitiesRepository extends CitiesRepository {
  _TestCitiesRepository({required super.service});

  @override
  Future<bool> isInConnection() async => true;
}

class _TestCitiesRepositoryNoInternet extends CitiesRepository {
  _TestCitiesRepositoryNoInternet({required super.service});

  @override
  Future<bool> isInConnection() async => false;
}
