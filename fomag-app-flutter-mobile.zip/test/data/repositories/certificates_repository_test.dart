import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/data/repositories/certificates_repository.dart';
import 'package:fomagapp/core/network/services/abstract/certificate_service.dart';
import 'package:fomagapp/core/network/services/abstract/payment_interest_certificate_service.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';
import 'package:fomagapp/core/network/error/failure.dart';

import 'certificates_repository_test.mocks.dart';

class TestCertificatesRepository extends CertificatesRepository {
  TestCertificatesRepository({
    required CertificateService certificateService,
    required PaymentInterestCertificateService
    paymentInterestCertificateService,
  }) : super(
         certificateService: certificateService,
         paymentInterestCertificateService: paymentInterestCertificateService,
       );

  @override
  Future<bool> isInConnection() async => true;
}

class NoInternetCertificatesRepository extends CertificatesRepository {
  NoInternetCertificatesRepository({
    required CertificateService certificateService,
    required PaymentInterestCertificateService
    paymentInterestCertificateService,
  }) : super(
         certificateService: certificateService,
         paymentInterestCertificateService: paymentInterestCertificateService,
       );

  @override
  Future<bool> isInConnection() async => false;
}

@GenerateMocks([CertificateService, PaymentInterestCertificateService])
void main() {
  late MockCertificateService mockCertificateService;
  late MockPaymentInterestCertificateService
  mockPaymentInterestCertificateService;
  late CertificatesRepository repository;

  setUp(() {
    mockCertificateService = MockCertificateService();
    mockPaymentInterestCertificateService =
        MockPaymentInterestCertificateService();
    repository = TestCertificatesRepository(
      certificateService: mockCertificateService,
      paymentInterestCertificateService: mockPaymentInterestCertificateService,
    );
  });

  group('getCertificatesType', () {
    test('should return CertificateTypeResponse on success', () async {
      final response = CertificateTypeResponse(
        httpCode: 200,
        message: 'OK',
        content: [],
      );

      when(mockCertificateService.call()).thenAnswer((_) async => response);

      final result = await repository.getCertificatesType();

      expect(result, Right(response));
      verify(mockCertificateService.call()).called(1);
    });

    test('should return ServerFailure on DioException', () async {
      when(mockCertificateService.call()).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.badResponse,
          message: 'Server error',
        ),
      );

      final result = await repository.getCertificatesType();

      expect(result.isLeft(), true);
      expect(result.fold((l) => l, (_) => null), isA<ServerFailure>());
    });

    test('should return NoConnectionFailure when offline', () async {
      repository = NoInternetCertificatesRepository(
        certificateService: mockCertificateService,
        paymentInterestCertificateService:
            mockPaymentInterestCertificateService,
      );

      final result = await repository.getCertificatesType();
      expect(result, isA<Left>());
      result.fold(
        (failure) => expect(failure, isA<NoConnectionFailure>()),
        (_) => fail('Should not succeed'),
      );
    });
  });

  group('generateCertificate', () {
    test('should return CertificateResponse on success', () async {
      final certResponse = CertificateResponse(true, 'http://some.url');

      when(
        mockCertificateService.generateCertificate(any, any),
      ).thenAnswer((_) async => certResponse);

      final result = await repository.generateCertificate('path', {
        'key': 'value',
      });

      expect(result, Right(certResponse));
    });

    test('should return ServerFailure on DioException', () async {
      when(mockCertificateService.generateCertificate(any, any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'No connection',
        ),
      );

      final result = await repository.generateCertificate('path', {});

      expect(result.isLeft(), true);
      result.fold(
        (failure) => expect(failure, isA<ServerFailure>()),
        (_) => fail('Should not succeed'),
      );
    });
  });

  group('getPayInterestCertificate', () {
    final request = PayInterestCertificateRequest(
      documentNumber: '12345',
      vinculacionType: 'AFILIADO',
    );

    test('should return List<String> on success', () async {
      when(
        mockPaymentInterestCertificateService.call(request),
      ).thenAnswer((_) async => ['Cert1', 'Cert2']);

      final result = await repository.getPayInterestCertificate(request);

      expect(result, Right(['Cert1', 'Cert2']));
    });

    test('should return ServerFailure on DioException', () async {
      when(mockPaymentInterestCertificateService.call(request)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'Connection error',
        ),
      );

      final result = await repository.getPayInterestCertificate(request);

      expect(result.isLeft(), true);
      result.fold(
        (failure) => expect(failure, isA<ServerFailure>()),
        (_) => fail('Should not succeed'),
      );
    });

    test('should return NoConnectionFailure when offline', () async {
      repository = NoInternetCertificatesRepository(
        certificateService: mockCertificateService,
        paymentInterestCertificateService:
            mockPaymentInterestCertificateService,
      );

      final result = await repository.getPayInterestCertificate(request);

      expect(result.isLeft(), true);
      result.fold(
        (failure) => expect(failure, isA<NoConnectionFailure>()),
        (_) => fail('Should not succeed'),
      );
    });
  });
}
