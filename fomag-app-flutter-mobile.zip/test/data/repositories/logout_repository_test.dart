import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/logout_service.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:fomagapp/data/repositories/logout_repository.dart';

import 'logout_repository_test.mocks.dart';

@GenerateMocks([LogoutService])
void main() {
  late MockLogoutService mockService;
  late LogoutRepository repository;

  final request = LogoutRequest(accessToken: 'fake-token');

  setUp(() {
    mockService = MockLogoutService();
    repository = _TestLogoutRepository(service: mockService);
  });

  test('should return Right(void) on success', () async {
    when(mockService.call(request)).thenAnswer((_) async => null);

    final result = await repository.call(request);

    expect(result, isA<Right>());
    verify(mockService.call(request)).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService.call(request)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'Connection error',
        ),
      );

      final result = await repository.call(request);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not succeed'));
    },
  );

  test('should return NoConnectionFailure when not connected', () async {
    repository = _TestLogoutRepository(service: mockService, connected: false);

    final result = await repository.call(request);

    expect(result, isA<Left>());
    expect(result.fold((l) => l, (_) => null), isA<NoConnectionFailure>());
  });
}

class _TestLogoutRepository extends LogoutRepository {
  final bool connected;

  _TestLogoutRepository({required LogoutService service, this.connected = true})
    : super(service: service);

  @override
  Future<bool> isInConnection() async => connected;
}
