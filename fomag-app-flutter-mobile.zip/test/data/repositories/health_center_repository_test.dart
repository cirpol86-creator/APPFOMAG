import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/health_center_service.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/data/repositories/health_center_repository.dart';

import 'health_center_repository_test.mocks.dart';

@GenerateMocks([HealthCenterService])
void main() {
  late MockHealthCenterService mockService;
  late HealthCenterRepository repository;

  const request = 1;

  final response = [
    HealthCenterResponse(
      id: 1,
      name: 'Centro de Salud 1',
      address: 'Calle 123',
      phone1: '123456',
      phone2: '654321',
    ),
  ];

  setUp(() {
    mockService = MockHealthCenterService();
    repository = _TestHealthCenterRepository(mockService);
  });

  test('should return list of health centers on success', () async {
    when(mockService.call(request)).thenAnswer((_) async => response);

    final result = await repository.getHealthCenters(request);

    expect(result, Right(response));
    verify(mockService.call(request)).called(1);
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService.call(request)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: ''),
          type: DioExceptionType.connectionError,
          message: 'No Internet',
        ),
      );

      final result = await repository.getHealthCenters(request);

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('Should not succeed'));
    },
  );

  test('should return NoConnectionFailure when there is no internet', () async {
    repository = _TestHealthCenterRepository(mockService, connected: false);

    final result = await repository.getHealthCenters(request);

    expect(result, isA<Left>());
    expect(result.fold((l) => l, (_) => null), isA<NoConnectionFailure>());
  });
}

class _TestHealthCenterRepository extends HealthCenterRepository {
  final bool connected;

  _TestHealthCenterRepository(
    HealthCenterService healthCenterService, {
    this.connected = true,
  }) : super(healthCenterService: healthCenterService);

  @override
  Future<bool> isInConnection() async => connected;
}
