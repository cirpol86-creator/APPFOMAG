import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/repositories/contact_info_repository.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/services/abstract/contact_services.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';

import 'contact_repository_test.mocks.dart';

@GenerateMocks([ContactService])
class TestContactRepository extends ContactRepository {
  TestContactRepository({required ContactService contactService})
    : super(contactService: contactService);

  @override
  Future<bool> isInConnection() async => true;
}

class TestContactRepositoryNoConnection extends ContactRepository {
  TestContactRepositoryNoConnection({required ContactService contactService})
    : super(contactService: contactService);

  @override
  Future<bool> isInConnection() async => false;
}

void main() {
  late MockContactService mockContactService;
  late ContactRepository repository;

  final contactList = [
    ContentResponse(
      id: 1,
      nombreCentroAtencion: 'Sede Norte',
      ciudad: 'Bogotá',
      direccion: 'Calle 123',
      telefonoContacto: '1234567',
      horarioAtencionPublico: '8am - 4pm',
      latitud: 4.65,
      longitud: -74.05,
      estado: 1,
    ),
  ];

  setUp(() {
    mockContactService = MockContactService();
    repository = TestContactRepository(contactService: mockContactService);
  });

  test('debe retornar lista de ContentResponse en éxito', () async {
    when(mockContactService.getContacts()).thenAnswer((_) async => contactList);

    final result = await repository.getContactList();

    expect(result, Right(contactList));
    verify(mockContactService.getContacts()).called(1);
  });

  test(
    'debe retornar ServerFailure en DioException tipo connectionError',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.connectionError,
        message: 'Error de red',
      );

      when(mockContactService.getContacts()).thenThrow(dioException);

      final result = await repository.getContactList();

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.connectionError);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test(
    'debe retornar ServerFailure en DioException tipo badResponse',
    () async {
      final dioException = DioException(
        requestOptions: RequestOptions(path: ''),
        type: DioExceptionType.badResponse,
        message: 'Respuesta inválida',
      );

      when(mockContactService.getContacts()).thenThrow(dioException);

      final result = await repository.getContactList();

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure, isA<ServerFailure>());
        expect(failure.data, DioExceptionType.badResponse);
      }, (_) => fail('No debe retornar éxito'));
    },
  );

  test('debe retornar NoConnectionFailure cuando no hay conexión', () async {
    repository = TestContactRepositoryNoConnection(
      contactService: mockContactService,
    );

    final result = await repository.getContactList();

    expect(result.isLeft(), true);
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('No debe retornar éxito'),
    );
  });
}
