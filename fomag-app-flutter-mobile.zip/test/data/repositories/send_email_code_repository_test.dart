import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/services/abstract/send_email_code_service.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:fomagapp/data/repositories/send_email_code_repository.dart';

import 'send_email_code_repository_test.mocks.dart';

@GenerateMocks([SendEmailCodeService])
void main() {
  late MockSendEmailCodeService mockService;
  late SendEmailCodeRepository repository;

  final request = EmailCodeRequest(
    typeDocument: 'CC',
    documentNumber: '123456',
  );

  final response = ForgotPasswordResponse(message: 'Correo enviado');

  setUp(() {
    mockService = MockSendEmailCodeService();
    repository = _TestSendEmailCodeRepository(sendEmailCode: mockService);
  });

  test('should return ForgotPasswordResponse on success', () async {
    when(mockService.call(request)).thenAnswer((_) async => response);

    final result = await repository.sendEmailCode(request);

    expect(result, isA<Right>());
    result.fold(
      (_) => fail('Expected success'),
      (res) => expect(res.message, equals('Correo enviado')),
    );
  });

  test(
    'should return ServerFailure on DioException (connectionError)',
    () async {
      when(mockService.call(request)).thenThrow(
        DioException(
          type: DioExceptionType.connectionError,
          requestOptions: RequestOptions(path: ''),
        ),
      );

      final result = await repository.sendEmailCode(request);

      expect(result, isA<Left>());
      result.fold(
        (failure) => expect(failure.data, DioExceptionType.connectionError),
        (_) => fail('Expected failure'),
      );
    },
  );

  test('should return ServerFailure on general DioException', () async {
    when(mockService.call(request)).thenThrow(
      DioException(
        type: DioExceptionType.unknown,
        requestOptions: RequestOptions(path: ''),
        message: 'Unknown error',
      ),
    );

    final result = await repository.sendEmailCode(request);

    expect(result, isA<Left>());
    result.fold((failure) {
      expect(failure, isA<ServerFailure>());
      expect(failure.message, contains('Unknown error'));
    }, (_) => fail('Expected failure'));
  });

  test('should return NoConnectionFailure when not connected', () async {
    repository = _TestSendEmailCodeRepository(
      sendEmailCode: mockService,
      connected: false,
    );

    final result = await repository.sendEmailCode(request);

    expect(result, isA<Left>());
    result.fold(
      (failure) => expect(failure, isA<NoConnectionFailure>()),
      (_) => fail('Expected no connection failure'),
    );
  });
}

class _TestSendEmailCodeRepository extends SendEmailCodeRepository {
  final bool connected;

  _TestSendEmailCodeRepository({
    required SendEmailCodeService sendEmailCode,
    this.connected = true,
  }) : super(sendEmailCode: sendEmailCode);

  @override
  Future<bool> isInConnection() async => connected;
}
