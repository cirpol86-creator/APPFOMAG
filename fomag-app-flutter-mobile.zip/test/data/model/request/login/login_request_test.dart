import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';

void main() {
  group('LoginRequest', () {
    test('should create with default values', () {
      const request = LoginRequest();

      expect(request.documentType, '');
      expect(request.documentNumber, '');
      expect(request.password, '');
    });

    test('should create with custom values', () {
      const request = LoginRequest(
        documentType: '3',
        documentNumber: '121212',
        password: 'testpass',
      );

      expect(request.documentType, '3');
      expect(request.documentNumber, '121212');
      expect(request.password, 'testpass');
    });

    test('should serialize to JSON', () {
      const request = LoginRequest(
        documentType: '3',
        documentNumber: '121212',
        password: 'testpass',
      );
      final json = request.toJson();

      expect(json, {'userName': 'testuser', 'password': 'testpass'});
    });

    test('should deserialize from JSON', () {
      final json = {
        'documentType': '3',
        'documentNumber': '1212',
        'password': 'testpass',
      };

      final request = LoginRequest.fromJson(json);

      expect(request.documentType, '3');
      expect(request.documentNumber, '1212');
      expect(request.password, 'testpass');
    });

    test('should handle empty JSON', () {
      final json = <String, dynamic>{};

      final request = LoginRequest.fromJson(json);

      expect(request.documentType, '');
      expect(request.documentNumber, '');
      expect(request.password, '');
    });

    test('should handle null values in JSON', () {
      final json = {
        'documentType': null,
        'documentNumber': null,
        'password': null,
      };

      final request = LoginRequest.fromJson(json);

      expect(request.documentType, '3');
      expect(request.documentNumber, '1212');
      expect(request.password, 'testpass');
    });
  });
}
