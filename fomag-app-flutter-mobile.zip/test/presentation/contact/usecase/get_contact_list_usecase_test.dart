import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/data/repositories/contact_info_repository.dart';
import 'package:fomagapp/presentation/contact/usecase/get_contact_list_usecase.dart';

import 'get_contact_list_usecase_test.mocks.dart';

@GenerateMocks([ContactRepository])
void main() {
  late MockContactRepository mockContactRepository;
  late GetContactListUseCase usecase;

  setUp(() {
    mockContactRepository = MockContactRepository();
    usecase = GetContactListUseCase(contactRepository: mockContactRepository);
  });

  group('GetContactListUseCase', () {
    final contactList = [
      ContentResponse(
        id: 1,
        nombreCentroAtencion: 'Centro Principal',
        ciudad: 'Bogotá',
        direccion: 'Calle 123',
        telefonoContacto: '3214567890',
        horarioAtencionPublico: 'Lunes a viernes 8am - 5pm',
        latitud: 4.60971,
        longitud: -74.08175,
        estado: 1,
      ),
    ];

    test('debe retornar lista de contactos cuando es exitoso', () async {
      // arrange
      when(
        mockContactRepository.getContactList(),
      ).thenAnswer((_) async => Right(contactList));

      // act
      final result = await usecase();

      // assert
      expect(result, Right(contactList));
      verify(mockContactRepository.getContactList()).called(1);
      verifyNoMoreInteractions(mockContactRepository);
    });

    test('debe retornar Failure cuando hay error', () async {
      // arrange
      final failure = ServerFailure(
        message: 'Error de servidor',
        data: DioExceptionType.badResponse,
      );

      when(
        mockContactRepository.getContactList(),
      ).thenAnswer((_) async => Left(failure));

      // act
      final result = await usecase();

      // assert
      expect(result, Left(failure));
      verify(mockContactRepository.getContactList()).called(1);
      verifyNoMoreInteractions(mockContactRepository);
    });
  });
}
