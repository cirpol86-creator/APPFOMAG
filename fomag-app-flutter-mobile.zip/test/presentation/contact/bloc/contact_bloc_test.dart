import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_bloc.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_event.dart';
import 'package:fomagapp/presentation/contact/bloc/contact_state.dart';
import 'package:fomagapp/presentation/contact/usecase/get_contact_list_usecase.dart';

import 'contact_bloc_test.mocks.dart';

@GenerateMocks([GetContactListUseCase])
void main() {
  late MockGetContactListUseCase mockGetContactListUseCase;
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    mockGetContactListUseCase = MockGetContactListUseCase();
  });

  group('ContactBloc', () {
    final validContactList = [
      ContentResponse(
        id: 1,
        nombreCentroAtencion: 'Centro 1',
        ciudad: 'Bogotá',
        direccion: 'Calle Falsa 123',
        telefonoContacto: '123456789',
        horarioAtencionPublico: 'Lunes a viernes 8am - 5pm',
        latitud: 4.60971,
        longitud: -74.08175,
        estado: 1,
      ),
    ];

    final invalidContactList = [
      ContentResponse(
        id: 2,
        nombreCentroAtencion: 'Centro Inválido',
        ciudad: 'Cali',
        direccion: 'Carrera 1',
        telefonoContacto: '987654321',
        horarioAtencionPublico: 'Lunes a viernes 9am - 6pm',
        latitud: 0.0,
        longitud: -74.08175,
        estado: 1,
      ),
    ];

    blocTest<ContactBloc, ContactState>(
      'emite [ContactLoading, ContactLoaded] cuando la carga es exitosa',
      build: () {
        when(
          mockGetContactListUseCase(),
        ).thenAnswer((_) async => Right(validContactList));
        return ContactBloc(getContactListUseCase: mockGetContactListUseCase);
      },
      act: (bloc) => bloc.add(LoadContactData()),
      expect:
          () => [
            isA<ContactLoading>(),
            isA<ContactLoaded>().having(
              (state) => state.contactList,
              'contactList',
              validContactList,
            ),
          ],
      verify: (_) {
        verify(mockGetContactListUseCase()).called(1);
      },
    );

    blocTest<ContactBloc, ContactState>(
      'emite [ContactLoading, ContactError] cuando ocurre un error',
      build: () {
        when(mockGetContactListUseCase()).thenAnswer(
          (_) async => Left(
            ServerFailure(message: 'Error', data: DioExceptionType.unknown),
          ),
        );
        return ContactBloc(getContactListUseCase: mockGetContactListUseCase);
      },
      act: (bloc) => bloc.add(LoadContactData()),
      expect:
          () => [
            isA<ContactLoading>(),
            isA<ContactError>().having(
              (state) => state.message,
              'message',
              contains('Error'),
            ),
          ],
      verify: (_) {
        verify(mockGetContactListUseCase()).called(1);
      },
    );

    blocTest<ContactBloc, ContactState>(
      'emite [ContactLoading, ContactError] cuando hay coordenadas inválidas',
      build: () {
        when(
          mockGetContactListUseCase(),
        ).thenAnswer((_) async => Right(invalidContactList));
        return ContactBloc(getContactListUseCase: mockGetContactListUseCase);
      },
      act: (bloc) => bloc.add(LoadContactData()),
      expect:
          () => [
            isA<ContactLoading>(),
            isA<ContactError>().having(
              (state) => state.message.toLowerCase(),
              'message',
              contains('coordenadas inválidas'),
            ),
          ],
    );
  });
  group('ContactEvent', () {
    test('LoadContactData props y comparación funcionan correctamente', () {
      final event1 = LoadContactData();
      final event2 = LoadContactData();

      expect(event1, equals(event2));

      expect(event1.props, []);
    });
  });
}
