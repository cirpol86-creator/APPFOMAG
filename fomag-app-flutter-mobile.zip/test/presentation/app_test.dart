import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:fomagapp/presentation/app.dart';
import 'package:fomagapp/core/routes/generated_route.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('MyApp Widget', () {
    testWidgets('should render without crashing', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());
      expect(find.byType(MaterialApp), findsOneWidget);
    });

    testWidgets('should have correct title', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.title, 'Fomag');
    });

    testWidgets('should have debug banner disabled', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.debugShowCheckedModeBanner, false);
    });

    testWidgets('should have Spanish locale', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.supportedLocales, const [Locale('es', '')]);
    });

    testWidgets('should have router configuration', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.routerConfig, RouterManager.router);
    });

    testWidgets('should have Listener as builder with correct behavior', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(const MyApp());

      // Encontrar el Listener que está dentro del builder del MaterialApp
      final Listener? listener =
          find
                  .descendant(
                    of: find.byType(MaterialApp),
                    matching: find.byType(Listener),
                  )
                  .evaluate()
                  .firstOrNull
                  ?.widget
              as Listener?;

      expect(listener, isNotNull);
      expect(listener?.behavior, HitTestBehavior.opaque);
    });

    testWidgets('should have MultiBlocProvider', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());
      expect(find.byType(MultiBlocProvider), findsOneWidget);
    });

    testWidgets('should have theme data', (WidgetTester tester) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.theme, isNotNull);
    });

    testWidgets('should have correct localizations delegates', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.localizationsDelegates, GlobalMaterialLocalizations.delegates);
    });

    testWidgets('should have correct builder configuration', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(const MyApp());
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.builder, isNotNull);
    });
  });

  group('App Initialization', () {
    test('should initialize app without throwing', () {
      expect(() => app(), returnsNormally);
    });

    test('should set preferred orientations', () async {
      final orientations = [
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ];

      await SystemChrome.setPreferredOrientations(orientations);
      // No need to verify the result as setPreferredOrientations returns void
    });
  });
}
