import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/data/repositories/register_repository.dart';
import 'package:fomagapp/presentation/register/usecase/register_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'register_usecase_test.mocks.dart';

@GenerateMocks([RegisterRepository])
void main() {
  late RegisterUseCase usecase;
  late MockRegisterRepository mockRepository;

  setUp(() {
    mockRepository = MockRegisterRepository();
    usecase = RegisterUseCase(register: mockRepository);
  });

  final tRequest = RegisterRequest(
    documentType: 'CC',
    documentNumber: '123456',
    fullName: 'Carlos Rengifo',
    email: 'test@example.com',
    mobile: '3211234567',
    password: 'password123',
    acceptanceTerms: true,
  );

  const tResponse = RegisterResponse(message: 'Registro exitoso');

  test('should return RegisterResponse when register is successful', () async {
    when(
      mockRepository.register(tRequest),
    ).thenAnswer((_) async => const Right(tResponse));

    final result = await usecase.callRegister(tRequest);

    expect(result, const Right(tResponse));
    verify(mockRepository.register(tRequest)).called(1);
    verifyNoMoreInteractions(mockRepository);
  });

  test('should return Failure when register fails', () async {
    final failure = ServerFailure<DioExceptionType>(message: 'Server error');

    when(
      mockRepository.register(tRequest),
    ).thenAnswer((_) async => Left(failure));

    final result = await usecase.callRegister(tRequest);

    expect(result, Left(failure));
    verify(mockRepository.register(tRequest)).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
