import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/data/model/response/department/department_response.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/register/bloc/register_bloc.dart';
import 'package:fomagapp/presentation/register/bloc/register_event.dart';
import 'package:fomagapp/presentation/register/bloc/register_state.dart';
import 'package:fomagapp/presentation/register/usecase/register_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'register_bloc_test.mocks.dart';

@GenerateMocks([RegisterUseCase, TrackUserEventUseCase])
void main() {
  late RegisterBloc bloc;
  late MockRegisterUseCase mockRegisterUseCase;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;

  setUp(() {
    mockRegisterUseCase = MockRegisterUseCase();
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();

    bloc = RegisterBloc(
      registerUseCase: mockRegisterUseCase,
      trackUserEventUseCase: mockTrackUserEventUseCase,
    );
  });

  final tRequest = RegisterRequest(
    documentType: 'CC',
    documentNumber: '123456',
    fullName: 'Carlos Rengifo',
    email: 'test@example.com',
    mobile: '3211234567',
    password: 'password123',
    acceptanceTerms: true,
  );

  const tResponse = RegisterResponse(message: 'Registro exitoso');

  test('initial state should be RegisterLoading', () {
    expect(bloc.state, equals(RegisterLoading()));
  });

  blocTest<RegisterBloc, RegisterState>(
    'emits [RegisterLoading, RegisterSuccess] when registration succeeds',
    build: () {
      when(
        mockRegisterUseCase.callRegister(any),
      ).thenAnswer((_) async => const Right(tResponse));
      return bloc;
    },
    act: (bloc) => bloc.add(RegisterSubmitted(request: tRequest)),
    expect:
        () => [
          RegisterLoading(),
          RegisterSuccess(response: 'Registro exitoso'),
        ],
    verify: (_) {
      verify(mockRegisterUseCase.callRegister(tRequest)).called(1);
    },
  );

  blocTest<RegisterBloc, RegisterState>(
    'emits [RegisterLoading, RegisterFailure] when registration fails',
    build: () {
      when(mockRegisterUseCase.callRegister(any)).thenAnswer(
        (_) async => Left(ServerFailure(message: 'Error de servidor')),
      );
      return bloc;
    },
    act: (bloc) => bloc.add(RegisterSubmitted(request: tRequest)),
    expect:
        () => [
          RegisterLoading(),
          RegisterFailure(message: 'Error de servidor'),
        ],
  );

  blocTest<RegisterBloc, RegisterState>(
    'calls tracker usecase when TrackerEvent is added',
    build: () {
      when(
        mockTrackUserEventUseCase.call(any),
      ).thenAnswer((_) async => Future.value());
      return bloc;
    },
    act: (bloc) => bloc.add(TrackerEvent()),
    verify: (_) {
      verify(
        mockTrackUserEventUseCase.call(
          argThat(
            predicate<UserEventModel>((event) {
              return event.type == UserEventType.register &&
                  event.parameters['screen_name'] == 'RegisterPage';
            }),
          ),
        ),
      ).called(1);
    },
  );

  group('RegisterState', () {
    test('DeparmentsLoading props', () {
      expect(DeparmentsLoading().props, []);
    });

    test('DeparmentsLoaded equality and copyWith', () {
      final dept = DepartmentResponse(
        state: 'Antioquia',
        capitalCity: 'Medellín',
        cities: ['Medellín', 'Envigado'],
      );

      final state1 = DeparmentsLoaded(
        departmentResponse: [dept],
        selectedDepartment: 'Antioquia',
        selectedMunicipios: ['Medellín'],
      );

      final state2 = state1.copyWith(selectedMunicipios: ['Envigado']);

      expect(state1.selectedMunicipios, ['Medellín']);
      expect(state2.selectedMunicipios, ['Envigado']);
      expect(state1.selectedDepartment, state2.selectedDepartment);
    });

    test('DepartmentsError props', () {
      final state = DepartmentsError(message: 'Error cargando departamentos');
      expect(state.props, ['Error cargando departamentos']);
    });

    test('CitiesSuccess props', () {
      final state = CitiesSuccess(cities: ['Cali', 'Bogotá']);
      expect(state.props, [
        ['Cali', 'Bogotá'],
      ]);
    });

    test('RegisterSuccess props', () {
      final state = RegisterSuccess(response: 'OK');
      expect(state.props, ['OK']);
    });

    test('RegisterFailure props', () {
      final state = RegisterFailure(message: 'Fallo');
      expect(state.props, ['Fallo']);
    });
  });
}
