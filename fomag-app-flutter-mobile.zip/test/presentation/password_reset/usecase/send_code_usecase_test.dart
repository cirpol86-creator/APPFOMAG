import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:fomagapp/data/repositories/send_email_code_repository.dart';
import 'package:fomagapp/presentation/password_reset/usecase/send_email_code_usecase.dart';

import 'send_code_usecase_test.mocks.dart';

@GenerateMocks([SendEmailCodeRepository])
void main() {
  late MockSendEmailCodeRepository mockRepository;
  late SendCodeUseCase useCase;

  setUp(() {
    mockRepository = MockSendEmailCodeRepository();
    useCase = SendCodeUseCase(sendEmailCode: mockRepository);
  });

  const tRequest = EmailCodeRequest(
    typeDocument: 'CC',
    documentNumber: '123456789',
  );

  final tResponse = ForgotPasswordResponse(message: 'Código enviado');

  test(
    'debe retornar respuesta exitosa cuando el repositorio responde con éxito',
    () async {
      // arrange
      when(
        mockRepository.sendEmailCode(tRequest),
      ).thenAnswer((_) async => Right(tResponse));

      // act
      final result = await useCase(tRequest);

      // assert
      expect(result, equals(Right(tResponse)));
      verify(mockRepository.sendEmailCode(tRequest)).called(1);
      verifyNoMoreInteractions(mockRepository);
    },
  );

  test('debe retornar Failure cuando el repositorio falla', () async {
    // arrange
    final failure = Failure<DioExceptionType>(message: 'Error en red');
    when(
      mockRepository.sendEmailCode(tRequest),
    ).thenAnswer((_) async => Left(failure));

    // act
    final result = await useCase(tRequest);

    // assert
    expect(result, equals(Left(failure)));
    verify(mockRepository.sendEmailCode(tRequest)).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
