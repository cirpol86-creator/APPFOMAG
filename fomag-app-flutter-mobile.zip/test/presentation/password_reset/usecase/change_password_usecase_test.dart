import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:fomagapp/data/repositories/confirm_forgot_password_repository.dart';
import 'package:fomagapp/presentation/password_reset/usecase/change_password_usecase.dart';

import 'change_password_usecase_test.mocks.dart';

@GenerateMocks([ConfirmForgotPasswordRepository])
void main() {
  late MockConfirmForgotPasswordRepository mockRepository;
  late ChangePasswordUseCase useCase;

  setUp(() {
    mockRepository = MockConfirmForgotPasswordRepository();
    useCase = ChangePasswordUseCase(repository: mockRepository);
  });

  final tRequest = ConfirmForgotPasswordRequest(
    documentType: 'CC',
    documentNumber: '123456789',
    password: 'NewPassword123!',
    code: '654321',
  );

  final tResponse = ConfirmForgotPasswordResponse(
    message: 'Contraseña actualizada con éxito',
  );

  test(
    'debe retornar ConfirmForgotPasswordResponse cuando el cambio de contraseña es exitoso',
    () async {
      // arrange
      when(
        mockRepository.confirmForgotPassword(tRequest),
      ).thenAnswer((_) async => Right(tResponse));

      // act
      final result = await useCase(tRequest);

      // assert
      expect(result, Right(tResponse));
      verify(mockRepository.confirmForgotPassword(tRequest)).called(1);
      verifyNoMoreInteractions(mockRepository);
    },
  );

  test('debe retornar Failure cuando ocurre un error', () async {
    // arrange
    final failure = Failure<DioExceptionType>(message: 'Error de red');
    when(
      mockRepository.confirmForgotPassword(tRequest),
    ).thenAnswer((_) async => Left(failure));

    // act
    final result = await useCase(tRequest);

    // assert
    expect(result, Left(failure));
    verify(mockRepository.confirmForgotPassword(tRequest)).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
