import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/password_reset/bloc/password_reset_bloc.dart';
import 'package:fomagapp/presentation/password_reset/usecase/change_password_usecase.dart';
import 'package:fomagapp/presentation/password_reset/usecase/send_email_code_usecase.dart';

import 'password_reset_bloc_test.mocks.dart';

@GenerateMocks([SendCodeUseCase, ChangePasswordUseCase, TrackUserEventUseCase])
void main() {
  late MockSendCodeUseCase mockSendCodeUseCase;
  late MockChangePasswordUseCase mockChangePasswordUseCase;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;

  late PasswordResetBloc bloc;

  setUp(() {
    mockSendCodeUseCase = MockSendCodeUseCase();
    mockChangePasswordUseCase = MockChangePasswordUseCase();
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();

    bloc = PasswordResetBloc(
      sendCodeUseCase: mockSendCodeUseCase,
      changePasswordUseCase: mockChangePasswordUseCase,
      trackUserEventUseCase: mockTrackUserEventUseCase,
    );
  });

  const tEmailRequest = EmailCodeRequest(
    typeDocument: 'CC',
    documentNumber: '123456789',
  );

  final tForgotPasswordResponse = ForgotPasswordResponse(
    message: 'Código enviado',
  );

  final tConfirmRequest = ConfirmForgotPasswordRequest(
    documentType: 'CC',
    documentNumber: '123456789',
    password: '12345678',
    code: '9999',
  );

  final tConfirmResponse = ConfirmForgotPasswordResponse(
    message: 'Contraseña cambiada',
  );

  group('SendCodeSubmitted', () {
    blocTest<PasswordResetBloc, PasswordResetState>(
      'emite [Loading, SendCodeSuccess] cuando el código se envía correctamente',
      build: () {
        when(
          mockSendCodeUseCase.call(tEmailRequest),
        ).thenAnswer((_) async => Right(tForgotPasswordResponse));
        return bloc;
      },
      act: (bloc) => bloc.add(SendCodeSubmitted(request: tEmailRequest)),
      expect:
          () => [
            isA<PasswordResetLoading>(),
            isA<SendCodeSuccess>().having(
              (s) => s.message,
              'message',
              'Código enviado',
            ),
          ],
    );

    blocTest<PasswordResetBloc, PasswordResetState>(
      'emite [Loading, SendCodeFailure] cuando ocurre un error',
      build: () {
        when(
          mockSendCodeUseCase.call(tEmailRequest),
        ).thenAnswer((_) async => Left(Failure(message: 'Error')));
        return bloc;
      },
      act: (bloc) => bloc.add(SendCodeSubmitted(request: tEmailRequest)),
      expect:
          () => [
            isA<PasswordResetLoading>(),
            isA<SendCodeFailure>().having((f) => f.message, 'message', 'Error'),
          ],
    );
  });

  group('OtpCodePasswordSubmitted', () {
    blocTest<PasswordResetBloc, PasswordResetState>(
      'emite [Loading, ChangePasswordSuccess] cuando cambia la contraseña correctamente',
      build: () {
        when(
          mockChangePasswordUseCase.call(tConfirmRequest),
        ).thenAnswer((_) async => Right(tConfirmResponse));
        return bloc;
      },
      act:
          (bloc) =>
              bloc.add(OtpCodePasswordSubmitted(request: tConfirmRequest)),
      expect:
          () => [
            isA<PasswordResetLoading>(),
            isA<ChangePasswordSuccess>().having(
              (s) => s.message,
              'message',
              'Contraseña cambiada',
            ),
          ],
    );

    blocTest<PasswordResetBloc, PasswordResetState>(
      'emite [Loading, ChangePasswordFailure] cuando falla el cambio de contraseña',
      build: () {
        when(
          mockChangePasswordUseCase.call(tConfirmRequest),
        ).thenAnswer((_) async => Left(Failure(message: 'Fallo')));
        return bloc;
      },
      act:
          (bloc) =>
              bloc.add(OtpCodePasswordSubmitted(request: tConfirmRequest)),
      expect:
          () => [
            isA<PasswordResetLoading>(),
            isA<ChangePasswordFailure>().having(
              (s) => s.message,
              'message',
              'Fallo',
            ),
          ],
    );
  });
  group('TrackerEvent', () {
    blocTest<PasswordResetBloc, PasswordResetState>(
      'ejecuta el trackeo del evento correctamente',
      build: () {
        when(mockTrackUserEventUseCase.call(any)).thenAnswer((_) async {});
        return bloc;
      },
      act: (bloc) => bloc.add(TrackerEvent()),
      expect: () => [],
      verify: (_) {
        verify(mockTrackUserEventUseCase.call(any)).called(1);
      },
    );
  });
}
