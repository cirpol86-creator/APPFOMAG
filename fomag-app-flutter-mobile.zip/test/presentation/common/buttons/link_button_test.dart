import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/common/buttons/link_button.dart';

void main() {
  group('LinkButtonWidget', () {
    testWidgets('renders with provided text', (WidgetTester tester) async {
      const testText = 'Test Link';

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LinkButtonWidget(text: testText, onPressed: () {}),
          ),
        ),
      );

      expect(find.text(testText), findsOneWidget);
    });

    testWidgets('calls onPressed when tapped', (WidgetTester tester) async {
      bool wasPressed = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LinkButtonWidget(
              text: 'Test Link',
              onPressed: () => wasPressed = true,
            ),
          ),
        ),
      );

      await tester.tap(find.byType(LinkButtonWidget));
      await tester.pump();

      expect(wasPressed, true);
    });
  });
}
