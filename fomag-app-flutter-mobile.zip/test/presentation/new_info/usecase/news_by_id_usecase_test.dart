import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/data/repositories/news_by_id_repository.dart';
import 'package:fomagapp/presentation/new_info/usecase/news_by_id_usecase.dart';

import 'news_by_id_usecase_test.mocks.dart';

@GenerateMocks([NewsByIdRepository])
void main() {
  late NewsByIdRepository repository;
  late NewsByIdUseCase useCase;

  setUp(() {
    repository = MockNewsByIdRepository();
    useCase = NewsByIdUseCase(repository: repository);
  });

  const tUuid = 1;

  final tResponse = NewsByIdResponse(
    httpCode: 200,
    message: 'OK',
    content: NewsByIdContent(
      id: 1,
      title: 'Noticia',
      imagebanner: 'banner.jpg',
      idReference: 123,
      body: 'Contenido de la noticia',
      date: '2025-07-08',
    ),
  );

  test('should return NewsByIdResponse when call is successful', () async {
    when(repository.newsById(tUuid)).thenAnswer((_) async => Right(tResponse));

    final result = await useCase.call(tUuid);

    expect(result, Right(tResponse));
    verify(repository.newsById(tUuid)).called(1);
    verifyNoMoreInteractions(repository);
  });

  test('should return Failure when repository fails', () async {
    final failure = ServerFailure<DioExceptionType>(message: 'Error');
    when(repository.newsById(tUuid)).thenAnswer((_) async => Left(failure));

    final result = await useCase.call(tUuid);

    expect(result, Left(failure));
  });
}
