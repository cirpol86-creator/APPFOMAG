import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart'
    as model;
import 'package:fomagapp/presentation/new_info/bloc/news_by_id_bloc.dart';
import 'package:fomagapp/presentation/new_info/usecase/news_by_id_usecase.dart';

import 'news_by_id_bloc_test.mocks.dart';

@GenerateMocks([NewsByIdUseCase])
void main() {
  late NewsByIdBloc bloc;
  late MockNewsByIdUseCase mockUseCase;

  const tUuid = 1;

  final tResponse = NewsByIdResponse(
    httpCode: 200,
    message: 'Success',
    content: model.NewsByIdContent(
      id: 1,
      title: 'Test News',
      imagebanner: 'banner.png',
      idReference: 100,
      body: 'Some body content',
      date: '2025-07-08',
    ),
  );

  setUp(() {
    mockUseCase = MockNewsByIdUseCase();
    bloc = NewsByIdBloc(newsByIdUseCase: mockUseCase);
  });

  test('initial state should be NewsByIdLoading', () {
    expect(bloc.state, equals(NewsByIdLoading()));
  });

  blocTest<NewsByIdBloc, NewInfoBloc>(
    'emits [NewsByIdLoading, NewsByIdSuccess] when data is fetched successfully',
    build: () {
      when(mockUseCase(tUuid)).thenAnswer((_) async => Right(tResponse));
      return bloc;
    },
    act: (bloc) => bloc.add(const NewByIdSubmitted(tUuid)),
    expect: () => [NewsByIdLoading(), NewsByIdSuccess(response: tResponse)],
  );

  blocTest<NewsByIdBloc, NewInfoBloc>(
    'emits [NewsByIdLoading, NewsByIdFailure] when fetching data fails',
    build: () {
      when(
        mockUseCase(tUuid),
      ).thenAnswer((_) async => Left(ServerFailure(message: 'Error')));
      return bloc;
    },
    act: (bloc) => bloc.add(const NewByIdSubmitted(tUuid)),
    expect: () => [NewsByIdLoading(), NewsByIdFailure(message: 'Error')],
  );
}
