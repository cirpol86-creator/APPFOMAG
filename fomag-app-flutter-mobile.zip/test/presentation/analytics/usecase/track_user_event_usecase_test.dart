import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/data/repositories/analytics_repository.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'track_user_event_usecase_test.mocks.dart';

@GenerateMocks([AnalyticsRepository])
void main() {
  late MockAnalyticsRepository mockRepository;
  late TrackUserEventUseCase useCase;

  setUp(() {
    mockRepository = MockAnalyticsRepository();
    useCase = TrackUserEventUseCase(analyticsRepository: mockRepository);
  });

  test('debe llamar logEvent del repositorio con el evento correcto', () async {
    final event = UserEventModel(UserEventType.deleteAccount, {
      'screen_name': 'AccountPage',
    });

    when(
      mockRepository.logEvent(event),
    ).thenAnswer((_) async => Future.value());

    await useCase.call(event);

    verify(mockRepository.logEvent(event)).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
