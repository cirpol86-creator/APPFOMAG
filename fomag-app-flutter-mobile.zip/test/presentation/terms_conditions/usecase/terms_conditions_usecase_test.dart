import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/repositories/terms_conditions_repository.dart';
import 'package:fomagapp/presentation/terms_conditions/usecase/terms_conditions_usecase.dart';

import 'terms_conditions_usecase_test.mocks.dart';

@GenerateMocks([TermsConditionsRepository])
void main() {
  late TermsConditionsUsecase usecase;
  late MockTermsConditionsRepository mockRepository;

  setUp(() {
    mockRepository = MockTermsConditionsRepository();
    usecase = TermsConditionsUsecase(termsConditionsRepository: mockRepository);
  });

  const tResponse = 'Términos y condiciones de uso';

  test(
    'debe retornar el string con los términos al hacer la petición con éxito',
    () async {
      when(
        mockRepository.fetchTermsAndConditions(),
      ).thenAnswer((_) async => const Right(tResponse));

      final result = await usecase.getTerms();

      expect(result, const Right(tResponse));
      verify(mockRepository.fetchTermsAndConditions()).called(1);
      verifyNoMoreInteractions(mockRepository);
    },
  );

  test('debe retornar un fallo cuando la petición falla', () async {
    final failure = ServerFailure(
      message: 'Error de servidor',
      data: DioExceptionType.badResponse,
    );

    when(
      mockRepository.fetchTermsAndConditions(),
    ).thenAnswer((_) async => Left(failure));

    final result = await usecase.getTerms();

    expect(result, Left(failure));
    verify(mockRepository.fetchTermsAndConditions()).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
