import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_bloc.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_event.dart';
import 'package:fomagapp/presentation/terms_conditions/bloc/terms_conditions_state.dart';
import 'package:fomagapp/presentation/terms_conditions/usecase/terms_conditions_usecase.dart';

import 'terms_conditions_bloc_test.mocks.dart';

@GenerateMocks([TermsConditionsUsecase])
void main() {
  late MockTermsConditionsUsecase mockUsecase;

  setUp(() {
    mockUsecase = MockTermsConditionsUsecase();
  });

  group('TermsConditionsBloc', () {
    const tTerms = 'Estos son los términos y condiciones de prueba';

    blocTest<TermsConditionsBloc, TermsConditionsState>(
      'emite [Loading, Success] cuando la petición es exitosa',
      build: () {
        when(
          mockUsecase.getTerms(),
        ).thenAnswer((_) async => const Right(tTerms));
        return TermsConditionsBloc(termsConditionsUsecase: mockUsecase);
      },
      act: (bloc) => bloc.add(TermsConditionsSubmitted()),
      expect:
          () => [
            TermsConditionsLoading(),
            TermsConditionsSuccess(terms: tTerms),
          ],
      verify: (_) {
        verify(mockUsecase.getTerms()).called(1);
      },
    );

    blocTest<TermsConditionsBloc, TermsConditionsState>(
      'emite [Loading, Failure] cuando ocurre un fallo',
      build: () {
        when(mockUsecase.getTerms()).thenAnswer(
          (_) async => Left(
            ServerFailure(
              message: 'Error de servidor',
              data: DioExceptionType.badResponse,
            ),
          ),
        );
        return TermsConditionsBloc(termsConditionsUsecase: mockUsecase);
      },
      act: (bloc) => bloc.add(TermsConditionsSubmitted()),
      expect:
          () => [
            TermsConditionsLoading(),
            TermsConditionsFailure(message: 'Error de servidor'),
          ],
      verify: (_) {
        verify(mockUsecase.getTerms()).called(1);
      },
    );
  });
}
