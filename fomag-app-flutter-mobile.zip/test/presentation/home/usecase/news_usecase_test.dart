import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/data/repositories/news_repository.dart';
import 'package:fomagapp/presentation/home/usecases/news_usecase.dart';

import 'news_usecase_test.mocks.dart';

@GenerateMocks([NewsRepository])
void main() {
  late MockNewsRepository mockRepository;
  late NewsUseCase useCase;

  setUp(() {
    mockRepository = MockNewsRepository();
    useCase = NewsUseCase(repository: mockRepository);
  });

  final tNewsResponse = NewsResponse(
    httpCode: 200,
    message: 'OK',
    content: [
      NewsContent(
        id: 1,
        title: 'Título',
        imageBanner: 'banner.png',
        idReference: 1,
        body: 'Contenido',
        date: '2025-01-01',
      ),
    ],
  );

  test('debe retornar NewsResponse cuando la llamada es exitosa', () async {
    // arrange
    when(mockRepository.news()).thenAnswer((_) async => Right(tNewsResponse));

    // act
    final result = await useCase();

    // assert
    expect(result, Right(tNewsResponse));
    verify(mockRepository.news()).called(1);
    verifyNoMoreInteractions(mockRepository);
  });

  test('debe retornar Failure cuando la llamada falla', () async {
    // arrange
    final tFailure = ServerFailure<DioExceptionType>(message: 'Error');
    when(mockRepository.news()).thenAnswer((_) async => Left(tFailure));

    // act
    final result = await useCase();

    // assert
    expect(result, Left(tFailure));
    verify(mockRepository.news()).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
