import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';
import 'package:fomagapp/data/repositories/banner_repository.dart';
import 'package:fomagapp/presentation/home/usecases/get_banner_use_case.dart';

import 'get_banner_usecase_test.mocks.dart';

@GenerateMocks([BannerRepository])
void main() {
  late MockBannerRepository mockBannerRepository;
  late GetBannerUseCase useCase;

  setUp(() {
    mockBannerRepository = MockBannerRepository();
    useCase = GetBannerUseCase(bannerRepository: mockBannerRepository);
  });

  final tBannerResponse = BannerResponse(
    message: 'Banner OK',
    type: 'image',
    url: 'https://example.com/banner.jpg',
  );

  test(
    'debe retornar BannerResponse cuando la llamada al repositorio es exitosa',
    () async {
      // arrange
      when(
        mockBannerRepository.getBanner(),
      ).thenAnswer((_) async => Right(tBannerResponse));

      // act
      final result = await useCase();

      // assert
      expect(result, Right(tBannerResponse));
      verify(mockBannerRepository.getBanner()).called(1);
      verifyNoMoreInteractions(mockBannerRepository);
    },
  );

  test(
    'debe retornar un ServerFailure cuando hay un error en el repositorio',
    () async {
      // arrange
      final failure = ServerFailure<DioExceptionType>(
        message: 'Error al obtener banner',
        data: DioExceptionType.connectionError,
      );

      when(
        mockBannerRepository.getBanner(),
      ).thenAnswer((_) async => Left(failure));

      // act
      final result = await useCase();

      // assert
      expect(result, Left(failure));
      verify(mockBannerRepository.getBanner()).called(1);
      verifyNoMoreInteractions(mockBannerRepository);
    },
  );
}
