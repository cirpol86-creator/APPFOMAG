import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/home/bloc/home_bloc.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/home/usecases/news_usecase.dart';
import 'package:fomagapp/presentation/home/usecases/get_banner_use_case.dart';

import 'home_bloc_test.mocks.dart';

@GenerateMocks([NewsUseCase, TrackUserEventUseCase, GetBannerUseCase])
void main() {
  late MockNewsUseCase mockNewsUseCase;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;
  late MockGetBannerUseCase mockGetBannerUseCase;
  late HomeBloc homeBloc;

  setUp(() {
    mockNewsUseCase = MockNewsUseCase();
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();
    mockGetBannerUseCase = MockGetBannerUseCase();

    homeBloc = HomeBloc(
      newsUseCase: mockNewsUseCase,
      trackUserEventUseCase: mockTrackUserEventUseCase,
      getBannerUseCase: mockGetBannerUseCase,
    );
  });

  tearDown(() {
    homeBloc.close();
  });

  final tNewsResponse = NewsResponse(
    httpCode: 200,
    message: 'OK',
    content: [
      NewsContent(
        id: 1,
        title: 'Noticia de prueba',
        imageBanner: 'banner.jpg',
        idReference: 1,
        body: 'Contenido de prueba',
        date: '2025-01-01',
      ),
    ],
  );

  final tBannerResponse = BannerResponse(
    message: 'Banner retrieved successfully',
    type: 'image',
    url: 'https://example.com/banner.jpg',
  );

  group('NewsSubmitted', () {
    blocTest<HomeBloc, HomeState>(
      'emite [NewsLoading, NewsSuccess] cuando la carga de noticias es exitosa',
      build: () {
        when(mockNewsUseCase()).thenAnswer((_) async => Right(tNewsResponse));
        return homeBloc;
      },
      act: (bloc) => bloc.add(NewsSubmitted()),
      expect: () => [NewsLoading(), NewsSuccess(response: tNewsResponse)],
    );

    blocTest<HomeBloc, HomeState>(
      'emite [NewsLoading, NewsFailure] cuando la carga de noticias falla',
      build: () {
        when(mockNewsUseCase()).thenAnswer(
          (_) async => Left(ServerFailure(message: 'Error del servidor')),
        );
        return homeBloc;
      },
      act: (bloc) => bloc.add(NewsSubmitted()),
      expect: () => [NewsLoading(), NewsFailure(message: 'Error del servidor')],
    );
  });

  group('TrackerEvent', () {
    blocTest<HomeBloc, HomeState>(
      'llama correctamente al TrackUserEventUseCase',
      build: () {
        when(
          mockTrackUserEventUseCase.call(any),
        ).thenAnswer((_) async => Future.value());
        return homeBloc;
      },
      act: (bloc) => bloc.add(TrackerEvent()),
      verify: (_) {
        verify(
          mockTrackUserEventUseCase.call(
            UserEventModel(UserEventType.home, {'screen_name': 'HomePage'}),
          ),
        ).called(1);
      },
      expect: () => [],
    );
  });

  group('LoadBannerEvent', () {
    blocTest<HomeBloc, HomeState>(
      'emite [BannerLoading, BannerLoaded] cuando carga correctamente el banner',
      build: () {
        when(
          mockGetBannerUseCase(),
        ).thenAnswer((_) async => Right(tBannerResponse));
        return homeBloc;
      },
      act: (bloc) => bloc.add(LoadBannerEvent()),
      expect: () => [BannerLoading(), BannerLoaded(tBannerResponse)],
    );

    blocTest<HomeBloc, HomeState>(
      'emite [BannerLoading, BannerError] cuando falla la carga del banner',
      build: () {
        when(mockGetBannerUseCase()).thenAnswer(
          (_) async => Left(ServerFailure(message: 'Falló el banner')),
        );
        return homeBloc;
      },
      act: (bloc) => bloc.add(LoadBannerEvent()),
      expect: () => [BannerLoading(), BannerError('Falló el banner')],
    );
  });
}
