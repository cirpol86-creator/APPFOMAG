import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/presentation/otp_verification/bloc/otp_verification_bloc.dart';
import 'package:fomagapp/presentation/otp_verification/usecase/otp_verification_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'otp_verification_bloc_test.mocks.dart';

@GenerateMocks([OtpVerificationUseCase])
void main() {
  late MockOtpVerificationUseCase mockUseCase;
  late OtpVerificationBloc bloc;

  setUp(() {
    mockUseCase = MockOtpVerificationUseCase();
    bloc = OtpVerificationBloc(otpVerificationUseCase: mockUseCase);
  });

  final tRequest = OtpValidateRequest(
    userName: 'test_user',
    code: '123456',
    session: 'session123',
    challengeType: 'SMS',
  );

  final tResponse = OtpValidateResponse(
    accessToken: 'access_token',
    idToken: 'id_token',
    refreshToken: 'refresh_token',
  );

  group('OtpVerificationBloc', () {
    test('initial state should be OtpVerificationLoading', () {
      expect(bloc.state, isA<OtpVerificationLoading>());
    });

    blocTest<OtpVerificationBloc, OtpVerificationState>(
      'emits [Loading, Success] when usecase returns data',
      build: () {
        when(
          mockUseCase.callOtpVerification(tRequest),
        ).thenAnswer((_) async => Right(tResponse));
        return bloc;
      },
      act: (bloc) => bloc.add(OtpVerificationSubmitted(request: tRequest)),
      expect:
          () => [
            isA<OtpVerificationLoading>(),
            isA<OtpVerificationSuccess>().having(
              (s) => s.response,
              'response',
              tResponse,
            ),
          ],
      verify: (_) {
        verify(mockUseCase.callOtpVerification(tRequest)).called(1);
      },
    );

    blocTest<OtpVerificationBloc, OtpVerificationState>(
      'emits [Loading, Failure] when usecase returns error',
      build: () {
        when(mockUseCase.callOtpVerification(tRequest)).thenAnswer(
          (_) async => Left(Failure<DioExceptionType>(message: 'Invalid code')),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(OtpVerificationSubmitted(request: tRequest)),
      expect:
          () => [
            isA<OtpVerificationLoading>(),
            isA<OtpVerificationFailure>().having(
              (f) => f.message,
              'message',
              'Invalid code',
            ),
          ],
      verify: (_) {
        verify(mockUseCase.callOtpVerification(tRequest)).called(1);
      },
    );
  });
}
