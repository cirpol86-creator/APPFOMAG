import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/data/repositories/otp_verification_repository.dart';
import 'package:fomagapp/presentation/otp_verification/usecase/otp_verification_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'otp_verification_usecase_test.mocks.dart';

@GenerateMocks([OtpVerificationRepository])
void main() {
  late OtpVerificationUseCase useCase;
  late MockOtpVerificationRepository mockRepository;

  setUp(() {
    mockRepository = MockOtpVerificationRepository();
    useCase = OtpVerificationUseCase(repository: mockRepository);
  });

  final tRequest = OtpValidateRequest(
    userName: 'testuser',
    code: '123456',
    session: 'abc-session',
    challengeType: 'SMS',
  );

  final tResponse = OtpValidateResponse(
    accessToken: 'access_token',
    idToken: 'id_token',
    refreshToken: 'refresh_token',
  );

  test(
    'should return OtpValidateResponse when OTP verification is successful',
    () async {
      // arrange
      when(
        mockRepository.otpVerification(any),
      ).thenAnswer((_) async => Right(tResponse));

      // act
      final result = await useCase.callOtpVerification(tRequest);

      // assert
      expect(result, Right(tResponse));
      verify(mockRepository.otpVerification(tRequest)).called(1);
    },
  );

  test('should return Failure when OTP verification fails', () async {
    // arrange
    final failure = Failure<DioExceptionType>(message: 'Error');
    when(
      mockRepository.otpVerification(any),
    ).thenAnswer((_) async => Left(failure));

    // act
    final result = await useCase.callOtpVerification(tRequest);

    // assert
    expect(result, Left(failure));
    verify(mockRepository.otpVerification(tRequest)).called(1);
  });
}
