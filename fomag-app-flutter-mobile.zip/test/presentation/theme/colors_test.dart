import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

void main() {
  group('FomagColors', () {
    test('should extend Equatable with empty props', () {
      final colors1 = FomagColors();
      final colors2 = FomagColors();

      // Two instances should be equal
      expect(colors1, equals(colors2));

      // Props should be empty
      expect(colors1.props, isEmpty);
    });

    test('should have correct color values', () {
      // Primary colors
      expect(FomagColors.primaryColor, const Color(0xFF259FD9));
      expect(FomagColors.secondaryColor, const Color(0xFF114964));
      expect(FomagColors.white, const Color(0xFFFFFFFF));
      expect(FomagColors.black, const Color(0xFF000000));

      // Gray scale
      expect(FomagColors.lightGray, const Color(0xFFE0E0E0));
      expect(FomagColors.mediumGray, const Color(0xFFDFDFDF));
      expect(FomagColors.gray, const Color(0xFF616161));
      expect(FomagColors.fogGray, const Color(0xFFEEEEEE));

      // Blue shades
      expect(FomagColors.darkBlue, const Color(0xFF0082B3));
      expect(FomagColors.lightBlue, const Color(0xFF00ACEC));
      expect(FomagColors.blue450, const Color(0xFF4CB0E0));

      // Action colors
      expect(FomagColors.error, const Color(0xFFC51D34));
      expect(FomagColors.greenButton, const Color(0xFF4CAF50));
      expect(FomagColors.redButton, const Color(0xFFE53935));
      expect(FomagColors.buttonPrimary, const Color(0xFF259FD9));

      // Neutral colors
      expect(FomagColors.neutralTitleText, const Color(0xFF2A2A2A));
      expect(FomagColors.neutralText, const Color(0xFF5F5F5F));
      expect(FomagColors.neutralRojo, const Color(0xFFE53935));
      expect(FomagColors.neutralBlueTitle, const Color(0xFF114964));
      expect(FomagColors.neutralBlueText, const Color(0xFF0077A3));

      // Special colors
      expect(FomagColors.magenta650, const Color(0xFFC70971));
      expect(FomagColors.backgroundInputOtp, const Color(0xFFD9D9D9));
    });
  });
}
