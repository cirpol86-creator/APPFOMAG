import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_bloc.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/types/certificates_type_state.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_params_certificate_by_id.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_types_certificates_usecase.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'certificates_type_bloc_test.mocks.dart';

@GenerateMocks([GetTypesCertificatesUsecase, GetParamsCertificateByIdUsecase])
void main() {
  late MockGetTypesCertificatesUsecase mockGetTypesCertificatesUsecase;
  late MockGetParamsCertificateByIdUsecase mockGetParamsCertificateByIdUsecase;
  late CertificatesTypeBloc bloc;

  final certificate = CertificateType(
    id: 1,
    name: 'Certificado A',
    path: 'cert/a',
    state: 'activo',
  );

  final certificateList = [certificate];

  setUp(() {
    mockGetTypesCertificatesUsecase = MockGetTypesCertificatesUsecase();
    mockGetParamsCertificateByIdUsecase = MockGetParamsCertificateByIdUsecase();
    bloc = CertificatesTypeBloc(
      certificatesUsecase: mockGetTypesCertificatesUsecase,
      getParamsCertificateByIdUsecase: mockGetParamsCertificateByIdUsecase,
    );
  });

  group('GetCertificates', () {
    test('GetCertificates props contiene force', () {
      const event = GetCertificates(force: true);
      expect(event.props, [true]);
    });

    blocTest<CertificatesTypeBloc, CertificatesTypeState>(
      'emite [Loading, Success] cuando obtiene certificados correctamente',
      build: () {
        when(mockGetTypesCertificatesUsecase.getCertificates()).thenAnswer(
          (_) async => Right(
            CertificateTypeResponse(
              httpCode: 200,
              message: 'ok',
              content: certificateList,
            ),
          ),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(const GetCertificates()),
      expect:
          () => [
            CertificatesTypeLoading(),
            CertificatesTypeSuccess(
              response: certificateList,
              selected: null,
              params: [],
            ),
          ],
    );

    blocTest<CertificatesTypeBloc, CertificatesTypeState>(
      'emite [Loading, Failure] cuando ocurre un error al obtener certificados',
      build: () {
        when(mockGetTypesCertificatesUsecase.getCertificates()).thenAnswer(
          (_) async => Left(Failure(message: 'Error al obtener certificados')),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(const GetCertificates()),
      expect:
          () => [
            CertificatesTypeLoading(),
            const CertificatesTypeFailure(
              message: 'Error al obtener certificados',
            ),
          ],
    );

    blocTest<CertificatesTypeBloc, CertificatesTypeState>(
      'no emite nada si ya hay datos y no se fuerza',
      build: () => bloc,
      seed:
          () => CertificatesTypeSuccess(
            response: certificateList,
            selected: null,
            params: [],
          ),
      act: (bloc) => bloc.add(const GetCertificates()),
      expect: () => [],
    );
  });

  group('CertificateTypeSelectedChanged', () {
    final params = [
      CertificateParam(
        name: 'period',
        label: 'Periodo',
        type: 'dropdown',
        options: ['2024', '2023'],
      ),
    ];

    test('CertificateTypeSelectedChanged props contiene el certificado', () {
      final event = CertificateTypeSelectedChanged(certificate);
      expect(event.props, [certificate]);
    });

    blocTest<CertificatesTypeBloc, CertificatesTypeState>(
      'emite estado actualizado con certificado y parámetros',
      build: () {
        when(
          mockGetParamsCertificateByIdUsecase.getParams(
            certificate: certificate,
          ),
        ).thenReturn(params);
        return bloc;
      },
      seed:
          () => CertificatesTypeSuccess(
            response: certificateList,
            selected: null,
            params: [],
          ),
      act: (bloc) => bloc.add(CertificateTypeSelectedChanged(certificate)),
      expect:
          () => [
            CertificatesTypeSuccess(
              response: certificateList,
              selected: certificate,
              params: params,
            ),
          ],
    );

    blocTest<CertificatesTypeBloc, CertificatesTypeState>(
      'no hace nada si el estado actual no es CertificatesTypeSuccess',
      build: () => bloc,
      act: (bloc) => bloc.add(CertificateTypeSelectedChanged(certificate)),
      expect: () => [],
    );
  });

  group('ResetCertificates', () {
    test('ResetCertificates props está vacío', () {
      expect(ResetCertificates().props, []);
    });

    blocTest<CertificatesTypeBloc, CertificatesTypeState>(
      'emite CertificatesTypeInitial cuando se reinicia el estado',
      build: () => bloc,
      seed:
          () => CertificatesTypeSuccess(
            response: certificateList,
            selected: certificate,
            params: [],
          ),
      act: (bloc) => bloc.add(ResetCertificates()),
      expect: () => [CertificatesTypeInitial()],
    );
  });
}
