import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_event.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/certificate_generate_state.dart';
import 'package:fomagapp/presentation/certificates/bloc/generate/generate_certificate_bloc.dart';
import 'package:fomagapp/presentation/certificates/usecase/garnishments_list_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/generate_certificate_usecase.dart';
import 'package:fomagapp/presentation/certificates/usecase/payment_interest_usecase.dart';
import 'package:fomagapp/presentation/widgets/download_pdf/download_pdf.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'certificate_generate_bloc_test.mocks.dart';

@GenerateMocks([
  GenerateCertificateUsecase,
  DownloadPdfUseCase,
  GarnishmentsListUsecase,
  PaymentInterestUsecase,
  TrackUserEventUseCase,
])
void main() {
  late MockGenerateCertificateUsecase mockGenerateCertificateUsecase;
  late MockDownloadPdfUseCase mockDownloadPdfUseCase;
  late MockGarnishmentsListUsecase mockGarnishmentsListUsecase;
  late MockPaymentInterestUsecase mockPaymentInterestUsecase;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;

  setUp(() {
    mockGenerateCertificateUsecase = MockGenerateCertificateUsecase();
    mockDownloadPdfUseCase = MockDownloadPdfUseCase();
    mockGarnishmentsListUsecase = MockGarnishmentsListUsecase();
    mockPaymentInterestUsecase = MockPaymentInterestUsecase();
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();
  });

  CertificateGenerateBloc buildBloc() {
    return CertificateGenerateBloc(
      generateCertificateUseCase: mockGenerateCertificateUsecase,
      downloadPdfUseCase: mockDownloadPdfUseCase,
      garnishmentsListUsecase: mockGarnishmentsListUsecase,
      paymentInterestUsecase: mockPaymentInterestUsecase,
      trackUserEventUseCase: mockTrackUserEventUseCase,
    );
  }

  group('CertificateGenerateBloc', () {
    final certificate = CertificateType(
      id: 1,
      name: 'Certificado',
      path: 'path/to/cert',
      state: 'A',
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, success] cuando GetGarnishments es exitoso',
      build: () {
        when(
          mockGarnishmentsListUsecase.getGarnishments(),
        ).thenAnswer((_) async => Right([GarnishmentsCertificateResponse()]));
        return buildBloc();
      },
      act: (bloc) => bloc.add(GetGarnishments()),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>()
                .having(
                  (s) => s.status,
                  'success',
                  CertificateGenerateStatus.success,
                )
                .having((s) => s.garnishments.length, 'garnishments', 1),
          ],
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, failure] cuando GetGarnishments falla',
      build: () {
        when(
          mockGarnishmentsListUsecase.getGarnishments(),
        ).thenAnswer((_) async => Left(Failure(message: 'Error de red')));
        return buildBloc();
      },
      act: (bloc) => bloc.add(GetGarnishments()),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>()
                .having(
                  (s) => s.status,
                  'failure',
                  CertificateGenerateStatus.failure,
                )
                .having((s) => s.message, 'message', 'Error de red'),
          ],
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, failure] cuando GetCertificateInterest retorna lista vacía',
      build: () {
        when(
          mockPaymentInterestUsecase.getPayInterestCertificate(
            vinculationType: '',
          ),
        ).thenAnswer((_) async => Right([]));
        return buildBloc();
      },
      act: (bloc) => bloc.add(GetCertificateInterest()),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>()
                .having(
                  (s) => s.status,
                  'failure',
                  CertificateGenerateStatus.failure,
                )
                .having(
                  (s) => s.message,
                  'message',
                  contains('No se encontraron datos'),
                ),
          ],
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, success] cuando GetCertificateInterest retorna lista válida',
      build: () {
        when(
          mockPaymentInterestUsecase.getPayInterestCertificate(
            vinculationType: '',
          ),
        ).thenAnswer((_) async => Right(['Cert A', 'Cert B']));
        return buildBloc();
      },
      act: (bloc) => bloc.add(GetCertificateInterest()),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>()
                .having(
                  (s) => s.status,
                  'success',
                  CertificateGenerateStatus.success,
                )
                .having(
                  (s) => s.certificateTypes.length,
                  'certificateTypes',
                  2,
                ),
          ],
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, failure] cuando GenerateCertificate retorna respuesta sin URL',
      build: () {
        when(
          mockGenerateCertificateUsecase.generateCertificate(
            certificate: certificate,
            formEntries: anyNamed('formEntries'),
          ),
        ).thenAnswer((_) async => Right(CertificateResponse(true, null)));
        return buildBloc();
      },
      act:
          (bloc) =>
              bloc.add(GenerateCertificate({'nombre': 'carlos'}, certificate)),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>()
                .having(
                  (s) => s.status,
                  'failure',
                  CertificateGenerateStatus.failure,
                )
                .having(
                  (s) => s.message,
                  'message',
                  contains('No hay certificados'),
                ),
          ],
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'llama a TrackUserEventUseCase cuando se lanza TrackerEvent',
      build: () {
        when(
          mockTrackUserEventUseCase.call(any),
        ).thenAnswer((_) async => Future.value());
        return buildBloc();
      },
      act: (bloc) => bloc.add(TrackerEvent()),
      expect: () => [],
      verify: (_) {
        verify(mockTrackUserEventUseCase.call(any)).called(1);
      },
    );

    final healthCertificate = CertificateType(
      id: 6,
      name: 'Salud',
      path: 'salud-path',
      state: 'A',
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, showHealthDialog] cuando certificado de salud es exitoso',
      build: () {
        when(
          mockGenerateCertificateUsecase.generateCertificate(
            certificate: healthCertificate,
            formEntries: anyNamed('formEntries'),
          ),
        ).thenAnswer((_) async => Right(CertificateResponse(true, null)));
        return buildBloc();
      },
      act:
          (bloc) => bloc.add(
            GenerateCertificate({'nombre': 'Carlos'}, healthCertificate),
          ),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'showHealthDialog',
              CertificateGenerateStatus.showHealthDialog,
            ),
          ],
    );

    blocTest<CertificateGenerateBloc, CertificateGenerateState>(
      'emite [loading, failure] cuando certificado de salud falla',
      build: () {
        when(
          mockGenerateCertificateUsecase.generateCertificate(
            certificate: healthCertificate,
            formEntries: anyNamed('formEntries'),
          ),
        ).thenAnswer((_) async => Right(CertificateResponse(false, null)));
        return buildBloc();
      },
      act:
          (bloc) => bloc.add(
            GenerateCertificate({'nombre': 'Carlos'}, healthCertificate),
          ),
      expect:
          () => [
            isA<CertificateGenerateState>().having(
              (s) => s.status,
              'loading',
              CertificateGenerateStatus.loading,
            ),
            isA<CertificateGenerateState>()
                .having(
                  (s) => s.status,
                  'failure',
                  CertificateGenerateStatus.failure,
                )
                .having(
                  (s) => s.message,
                  'message',
                  contains('no está disponible'),
                ),
          ],
    );
  });
}
