import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';
import 'package:fomagapp/presentation/certificates/logic/certificate_factory.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/usecase/generate_certificate_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'generate_certificate_usecase_test.mocks.dart';

@GenerateMocks([CertificatesRepository, GetCertificate])
void main() {
  late MockCertificatesRepository mockRepository;
  late MockGetCertificate mockGetCertificate;
  late GenerateCertificateUsecase usecase;

  final certificateType = CertificateType(
    id: 1,
    name: 'Cert Test',
    path: 'test/path',
    state: 'Activo',
  );

  final formEntries = {'campo': 'valor'};

  setUp(() {
    mockRepository = MockCertificatesRepository();
    mockGetCertificate = MockGetCertificate();
    usecase = GenerateCertificateUsecase(certificateRepository: mockRepository);
    CertificateFactory.override = (_, __) => mockGetCertificate;
  });

  tearDown(() {
    CertificateFactory.override = null; // Limpiar después del test
  });

  group('GenerateCertificateUsecase', () {
    test('retorna Right(CertificateResponse) en éxito', () async {
      final mockResponse = CertificateResponse(true, 'http://pdf.com/test.pdf');
      final expectedParams = {'campo': 'valor'};

      when(
        mockGetCertificate.paramsOut(formEntries),
      ).thenAnswer((_) async => expectedParams);
      when(
        mockRepository.generateCertificate(
          certificateType.path,
          expectedParams,
        ),
      ).thenAnswer((_) async => Right(mockResponse));

      // ⚠️ Inyectamos el mockGetCertificate en CertificateFactory (temporalmente)
      CertificateFactory.override = (_, __) => mockGetCertificate;

      final result = await usecase.generateCertificate(
        certificate: certificateType,
        formEntries: formEntries,
      );

      expect(result.isRight(), true);
      expect(
        result.getOrElse(() => CertificateResponse(false, '')),
        mockResponse,
      );

      CertificateFactory.override = null;
    });

    test('retorna Left(Failure) cuando el repositorio falla', () async {
      final failure = ServerFailure(
        message: 'Error',
        data: DioExceptionType.badResponse,
      );
      final expectedParams = {'campo': 'valor'};

      when(
        mockGetCertificate.paramsOut(formEntries),
      ).thenAnswer((_) async => expectedParams);
      when(
        mockRepository.generateCertificate(
          certificateType.path,
          expectedParams,
        ),
      ).thenAnswer((_) async => Left(failure));

      CertificateFactory.override = (_, __) => mockGetCertificate;

      final result = await usecase.generateCertificate(
        certificate: certificateType,
        formEntries: formEntries,
      );

      expect(result.isLeft(), true);
      result.fold(
        (l) => expect(l.message, 'Error'),
        (_) => fail('No se esperaba éxito'),
      );

      CertificateFactory.override = null;
    });

    test('retorna Left(Failure) cuando paramsOut lanza excepción', () async {
      when(
        mockGetCertificate.paramsOut(formEntries),
      ).thenThrow(Exception('Error inesperado'));

      CertificateFactory.override = (_, __) => mockGetCertificate;

      final result = await usecase.generateCertificate(
        certificate: certificateType,
        formEntries: formEntries,
      );

      expect(result.isLeft(), true);
      result.fold(
        (failure) => expect(failure.message, contains('Error inesperado')),
        (_) => fail('No se esperaba éxito'),
      );

      CertificateFactory.override = null;
    });

    test('retorna Left(Failure) cuando paramsOut lanza DioException', () async {
      final dioError = DioException(
        requestOptions: RequestOptions(path: '/path'),
        type: DioExceptionType.connectionTimeout,
      );

      when(mockGetCertificate.paramsOut(formEntries)).thenThrow(dioError);

      CertificateFactory.override = (_, __) => mockGetCertificate;

      final result = await usecase.generateCertificate(
        certificate: certificateType,
        formEntries: formEntries,
      );

      expect(result.isLeft(), true);
      result.fold((failure) {
        expect(failure.message, isNotEmpty);
        expect(failure.data, DioExceptionType.connectionTimeout);
      }, (_) => fail('No se esperaba éxito'));

      CertificateFactory.override = null;
    });
  });
}
