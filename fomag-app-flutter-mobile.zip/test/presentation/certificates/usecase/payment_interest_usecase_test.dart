import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/model/jwt_model.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';
import 'package:fomagapp/presentation/certificates/usecase/payment_interest_usecase.dart';

import 'payment_interest_usecase_test.mocks.dart';

@GenerateMocks([CertificatesRepository])
void main() {
  late PaymentInterestUsecase usecase;
  late MockCertificatesRepository mockRepository;

  final jwtUser = JwtUser(
    documentTypeId: '1',
    documentNumber: '12345678',
    username: 'Carlos',
  );

  decodeJwtUserFn() async => jwtUser;

  setUp(() {
    mockRepository = MockCertificatesRepository();
    usecase = PaymentInterestUsecase(
      certificatesRepository: mockRepository,
      decodeJwtUserFn: decodeJwtUserFn,
    );
  });

  test(
    'debe retornar lista de certificados cuando el llamado es exitoso',
    () async {
      final responseList = ['Certificado A', 'Certificado B'];
      final request = PayInterestCertificateRequest(
        documentNumber: '12345678',
        vinculacionType: '',
      );

      when(
        mockRepository.getPayInterestCertificate(request),
      ).thenAnswer((_) async => Right(responseList));

      final result = await usecase.getPayInterestCertificate();

      expect(result, Right(responseList));
      verify(mockRepository.getPayInterestCertificate(request)).called(1);
      verifyNoMoreInteractions(mockRepository);
    },
  );

  test('debe retornar Failure cuando el llamado falla', () async {
    final request = PayInterestCertificateRequest(
      documentNumber: '12345678',
      vinculacionType: '',
    );

    final failure = Failure<DioExceptionType>(
      message: 'Error de red',
      data: DioExceptionType.connectionTimeout,
    );

    when(
      mockRepository.getPayInterestCertificate(request),
    ).thenAnswer((_) async => Left(failure));

    final result = await usecase.getPayInterestCertificate();

    expect(result.isLeft(), true);
    result.fold((left) {
      expect(left.message, 'Error de red');
      expect(left.data, DioExceptionType.connectionTimeout);
    }, (_) => fail('No se esperaba éxito'));

    verify(mockRepository.getPayInterestCertificate(request)).called(1);
    verifyNoMoreInteractions(mockRepository);
  });
}
