import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/presentation/certificates/logic/get_certificate.dart';
import 'package:fomagapp/presentation/certificates/logic/model/certificate_param.dart';
import 'package:fomagapp/presentation/certificates/certificate_generator.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_params_certificate_by_id.dart';

import 'get_params_certificate_by_id_usecase_test.mocks.dart';

@GenerateMocks([CertificateGenerator, GetCertificate])
void main() {
  late MockCertificateGenerator mockGenerator;
  late MockGetCertificate mockGetCertificate;
  late GetParamsCertificateByIdUsecase usecase;

  setUp(() {
    mockGenerator = MockCertificateGenerator();
    mockGetCertificate = MockGetCertificate();
    usecase = GetParamsCertificateByIdUsecase(generator: mockGenerator);
  });

  final certificate = CertificateType(
    id: 1,
    name: 'Certificado Test',
    path: 'url_test',
    state: 'Activo',
  );

  final expectedParams = [
    CertificateParam(
      name: 'año',
      label: 'Año',
      type: 'year',
      options: [2023, 2024],
      required: true,
    ),
    CertificateParam(
      name: 'mes',
      label: 'Mes',
      type: 'month',
      options: ['Enero', 'Febrero'],
      required: true,
    ),
  ];

  test(
    'debe retornar los parámetros correctamente usando el generator mockeado',
    () {
      when(
        mockGenerator.generate(certificate.id, certificate.path),
      ).thenReturn(mockGetCertificate);
      when(mockGetCertificate.paramsIn()).thenReturn(expectedParams);

      final result = usecase.getParams(certificate: certificate);

      expect(result, equals(expectedParams));
      verify(
        mockGenerator.generate(certificate.id, certificate.path),
      ).called(1);
      verify(mockGetCertificate.paramsIn()).called(1);
    },
  );

  test('debe retornar lista vacía si paramsIn retorna nulo o vacío', () {
    when(
      mockGenerator.generate(certificate.id, certificate.path),
    ).thenReturn(mockGetCertificate);
    when(mockGetCertificate.paramsIn()).thenReturn([]);

    final result = usecase.getParams(certificate: certificate);

    expect(result, isEmpty);
  });
}
