import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:fomagapp/data/model/jwt_model.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/data/repositories/garnishments_repository.dart';
import 'package:fomagapp/presentation/certificates/usecase/garnishments_list_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'garnishments_list_usecase_test.mocks.dart';

@GenerateMocks([GarnishmentsRepository])
void main() {
  late GarnishmentsListUsecase usecase;
  late MockGarnishmentsRepository mockRepository;

  setUp(() {
    mockRepository = MockGarnishmentsRepository();
    usecase = GarnishmentsListUsecase(garnishmentsRepository: mockRepository);
  });

  final tJwtUser = JwtUser(documentNumber: '123456789', documentTypeId: 'CC');

  final tResponse = [
    const GarnishmentsCertificateResponse(nameCourt: 'Juzgado 1'),
  ];

  group('GarnishmentsListUsecase', () {
    setUp(() {
      SecureStorageManager.decodeJwtUserOverride = () async => tJwtUser;
    });

    tearDown(() {
      SecureStorageManager.decodeJwtUserOverride = null;
    });

    test('retorna lista de embargos correctamente (Right)', () async {
      when(
        mockRepository.garnishmentslist(any),
      ).thenAnswer((_) async => Right(tResponse));

      final result = await usecase.getGarnishments();

      expect(result.isRight(), true);
      expect(result.getOrElse(() => []), tResponse);

      verify(
        mockRepository.garnishmentslist(
          argThat(
            isA<GarnishmentRequest>()
                .having((r) => r.documentNumber, 'documentNumber', '123456789')
                .having((r) => r.documentType, 'documentType', 'CC'),
          ),
        ),
      ).called(1);
    });

    test('retorna ServerFailure cuando el repositorio falla (Left)', () async {
      final failure = ServerFailure(
        message: 'Error de red',
        data: DioExceptionType.connectionError,
      );

      when(
        mockRepository.garnishmentslist(any),
      ).thenAnswer((_) async => Left(failure));

      final result = await usecase.getGarnishments();

      expect(result.isLeft(), true);
      result.fold(
        (l) => expect(l.message, 'Error de red'),
        (_) => fail('No se esperaba éxito'),
      );

      verify(mockRepository.garnishmentslist(any)).called(1);
    });
  });
}
