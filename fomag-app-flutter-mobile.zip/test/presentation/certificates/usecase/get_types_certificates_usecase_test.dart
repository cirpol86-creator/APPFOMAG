import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/repositories/certificates_repository.dart';
import 'package:fomagapp/presentation/certificates/usecase/get_types_certificates_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'get_types_certificates_usecase_test.mocks.dart';

@GenerateMocks([CertificatesRepository])
void main() {
  late MockCertificatesRepository mockRepository;
  late GetTypesCertificatesUsecase usecase;

  setUp(() {
    mockRepository = MockCertificatesRepository();
    usecase = GetTypesCertificatesUsecase(
      certificateRepository: mockRepository,
    );
  });

  test(
    'debe retornar lista ordenada por nombre al obtener certificados correctamente',
    () async {
      final unsortedList = [
        const CertificateType(id: 2, name: 'Zeta', path: 'z', state: 'ACTIVO'),
        const CertificateType(id: 1, name: 'Alpha', path: 'a', state: 'ACTIVO'),
      ];

      final response = CertificateTypeResponse(
        httpCode: 200,
        message: 'OK',
        content: List.from(unsortedList),
      );

      when(
        mockRepository.getCertificatesType(),
      ).thenAnswer((_) async => Right(response));

      final result = await usecase.getCertificates();

      expect(result.isRight(), true);
      result.fold((_) => fail('No debe fallar'), (sorted) {
        expect(sorted.content[0].name, 'Alpha');
        expect(sorted.content[1].name, 'Zeta');
        expect(sorted.content.length, 2);
      });

      verify(mockRepository.getCertificatesType()).called(1);
    },
  );

  test('debe retornar Failure si la petición falla', () async {
    final failure = Failure<DioExceptionType>(
      message: 'Error de red',
      data: DioExceptionType.connectionError,
    );

    when(
      mockRepository.getCertificatesType(),
    ).thenAnswer((_) async => Left(failure));

    final result = await usecase.getCertificates();

    expect(result.isLeft(), true);
    result.fold((f) {
      expect(f.message, 'Error de red');
      expect(f.data, DioExceptionType.connectionError);
    }, (_) => fail('Debe fallar'));
  });
}
