import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/login/bloc/login_bloc.dart';
import 'package:fomagapp/presentation/login/usecase/login_usecase.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:dartz/dartz.dart';
import 'package:bloc_test/bloc_test.dart';

@GenerateMocks([LoginUseCase, FlutterSecureStorage, TrackUserEventUseCase])
import 'login_bloc_test.mocks.dart';

void main() {
  late LoginBloc loginBloc;
  late MockLoginUseCase mockLoginUseCase;
  late MockFlutterSecureStorage mockStorage;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;

  setUpAll(() {
    TestWidgetsFlutterBinding.ensureInitialized();
  });

  setUp(() {
    mockLoginUseCase = MockLoginUseCase();
    mockStorage = MockFlutterSecureStorage();
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();
    SecureStorageManager.setStorage(mockStorage);
    loginBloc = LoginBloc(
      loginUseCase: mockLoginUseCase,
      trackUserEventUseCase: mockTrackUserEventUseCase,
    );
  });

  tearDown(() {
    loginBloc.close();
  });

  group('LoginBloc', () {
    final testRequest = LoginRequest(
      documentType: '',
      documentNumber: 'test@test.com',
      password: 'password',
    );

    final testResponse = AuthResponse(
      challenge: Challenge.resetPasswordRequired,
      challengeName: 'Success',
      session: '',
      userName: '',
    );

    test('initial state should be LoginLoading', () {
      expect(loginBloc.state, isA<LoginLoading>());
    });

    blocTest<LoginBloc, LoginState>(
      'emits [LoginLoading, LoginSuccess] when login is successful',
      build: () {
        when(
          mockLoginUseCase.callLogin(testRequest),
        ).thenAnswer((_) async => Right(testResponse));
        when(
          mockStorage.write(key: anyNamed('key'), value: anyNamed('value')),
        ).thenAnswer((_) async {});
        return loginBloc;
      },
      act: (bloc) => bloc.add(LoginSubmitted(request: testRequest)),
      expect:
          () => [
            isA<LoginLoading>(),
            isA<LoginSuccess>().having(
              (state) => state.response,
              'email',
              testResponse,
            ),
          ],
    );

    blocTest<LoginBloc, LoginState>(
      'emits [LoginLoading, LoginFailure] when login fails',
      build: () {
        when(
          mockLoginUseCase.callLogin(testRequest),
        ).thenAnswer((_) async => Left(ServerFailure(message: 'Server error')));
        return loginBloc;
      },
      act: (bloc) => bloc.add(LoginSubmitted(request: testRequest)),
      expect:
          () => [
            isA<LoginLoading>(),
            isA<LoginFailure>().having(
              (state) => state.message,
              'message',
              'Server error',
            ),
          ],
    );

    blocTest<LoginBloc, LoginState>(
      'emits [LoginLoading, LoginFailure] when response code is not 01',
      build: () {
        final testResponse = AuthResponse(
          challenge: Challenge.resetPasswordRequired,
          challengeName: 'Success',
          session: '',
          userName: '',
        );
        when(
          mockLoginUseCase.callLogin(testRequest),
        ).thenAnswer((_) async => Right(testResponse));
        return loginBloc;
      },
      act: (bloc) => bloc.add(LoginSubmitted(request: testRequest)),
      expect:
          () => [
            isA<LoginLoading>(),
            isA<LoginFailure>().having(
              (state) => state.message,
              'message',
              'Invalid credentials',
            ),
          ],
    );
  });
}
