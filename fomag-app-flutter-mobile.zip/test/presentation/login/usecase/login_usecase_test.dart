import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/login/usecase/login_usecase.dart';
import 'package:mockito/mockito.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import '../../../mock/repositories/mock_login_repository.mocks.dart';

void main() {
  late MockLoginRepository mockLoginRepository;
  late LoginUseCase loginUseCase;

  setUp(() {
    mockLoginRepository = MockLoginRepository();
    loginUseCase = LoginUseCase(login: mockLoginRepository);
  });

  final loginRequest = LoginRequest(
    documentType: '3',
    documentNumber: 'usuario1',
    password: '1234',
  );

  final authResponse = AuthResponse(
    challenge: Challenge.mfaRequired,
    session: 'SESSION_ID',
    challengeName: 'CUSTOM_CHALLENGE',
    userName: 'usuario1',
    message: 'message',
  );

  test('debe retornar AuthResponse cuando el login es exitoso', () async {
    // Arrange
    when(
      mockLoginRepository.login(loginRequest),
    ).thenAnswer((_) async => Right(authResponse));

    // Act
    final result = await loginUseCase.callLogin(loginRequest);

    // Assert
    expect(result.isRight(), true);
    expect(result.getOrElse(() => throw Exception()), authResponse);
    verify(mockLoginRepository.login(loginRequest)).called(1);
  });

  test('debe retornar Failure cuando el login falla', () async {
    final failure = ServerFailure<DioExceptionType>(
      message: 'Unauthorized',
      data: DioExceptionType.connectionError,
    );

    when(
      mockLoginRepository.login(loginRequest),
    ).thenAnswer((_) async => Left(failure));

    // Act
    final result = await loginUseCase.callLogin(loginRequest);

    // Assert
    expect(result.isLeft(), true);
    result.fold((fail) {
      expect(fail.message, 'Unauthorized');
      expect(fail.data, DioExceptionType.connectionError);
    }, (_) => fail('No debería ser éxito'));

    verify(mockLoginRepository.login(loginRequest)).called(1);
  });
}
