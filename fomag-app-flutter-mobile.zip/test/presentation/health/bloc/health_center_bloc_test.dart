import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/presentation/health/bloc/health_center_bloc.dart';
import 'package:fomagapp/presentation/health/usecase/get_cities_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_departments_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_health_center_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'health_center_bloc_test.mocks.dart';

@GenerateMocks([
  GetHealthCenterUsecase,
  GetDepartmentsUsecase,
  GetCitiesUsecase,
])
void main() {
  late MockGetHealthCenterUsecase mockGetHealthCenterUsecase;
  late MockGetDepartmentsUsecase mockGetDepartmentsUsecase;
  late MockGetCitiesUsecase mockGetCitiesUsecase;
  late HealthCenterBloc bloc;

  setUp(() {
    mockGetHealthCenterUsecase = MockGetHealthCenterUsecase();
    mockGetDepartmentsUsecase = MockGetDepartmentsUsecase();
    mockGetCitiesUsecase = MockGetCitiesUsecase();

    bloc = HealthCenterBloc(
      getHealthCenterUsecase: mockGetHealthCenterUsecase,
      getDepartmentsUsecase: mockGetDepartmentsUsecase,
      getCitiesUsecase: mockGetCitiesUsecase,
    );
  });

  group('HealthCenterLoad', () {
    final tCityId = 1;
    final tCenters = [
      HealthCenterResponse(
        id: 1,
        name: 'Centro 1',
        address: 'Calle 123',
        phone1: '111',
        phone2: '222',
      ),
    ];

    blocTest<HealthCenterBloc, HealthCenterState>(
      'emite [HealthCenterLoading, HealthCenterLoaded] en caso de éxito',
      build: () {
        when(
          mockGetHealthCenterUsecase.getHealthCenters(tCityId),
        ).thenAnswer((_) async => Right(tCenters));
        return bloc;
      },
      act: (bloc) => bloc.add(HealthCenterLoad(tCityId)),
      expect:
          () => [
            HealthCenterLoading(),
            HealthCenterLoaded(healthCenters: tCenters),
          ],
    );

    blocTest<HealthCenterBloc, HealthCenterState>(
      'emite [HealthCenterLoading, HealthCenterError] en caso de error',
      build: () {
        when(mockGetHealthCenterUsecase.getHealthCenters(tCityId)).thenAnswer(
          (_) async => Left(
            ServerFailure(message: 'Error', data: DioExceptionType.badResponse),
          ),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(HealthCenterLoad(tCityId)),
      expect:
          () => [HealthCenterLoading(), HealthCenterError(message: 'Error')],
    );
  });

  group('DepartmentLoad', () {
    final tDepartments = DepartmentsHealthCenterResponse.getDepartments;

    blocTest<HealthCenterBloc, HealthCenterState>(
      'emite [DepartmentsLoading, DepartmentsLoaded] al obtener departamentos',
      build: () {
        when(
          mockGetDepartmentsUsecase(),
        ).thenAnswer((_) async => Right(tDepartments));
        return bloc;
      },
      act: (bloc) => bloc.add(DepartmentLoad()),
      expect:
          () => [
            DepartmentsLoading(),
            DepartmentsLoaded(departments: tDepartments),
          ],
    );

    blocTest<HealthCenterBloc, HealthCenterState>(
      'emite [DepartmentsLoading, DepartmentsError] al fallar la carga',
      build: () {
        when(mockGetDepartmentsUsecase()).thenAnswer(
          (_) async => Left(
            ServerFailure(
              message: 'Error departamentos',
              data: DioExceptionType.connectionError,
            ),
          ),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(DepartmentLoad()),
      expect:
          () => [
            DepartmentsLoading(),
            DepartmentsError(message: 'Error departamentos'),
          ],
    );
  });

  group('CityLoad', () {
    final departmentId = 1;
    final tCities = [
      CitiesResponse(id: 1, name: 'Ciudad A', departmentId: departmentId),
    ];

    blocTest<HealthCenterBloc, HealthCenterState>(
      'emite [CitiesLoading, CitiesLoaded] al obtener ciudades',
      build: () {
        when(
          mockGetCitiesUsecase(departmentId),
        ).thenAnswer((_) async => Right(tCities));
        return bloc;
      },
      act: (bloc) => bloc.add(CityLoad(departmentId)),
      expect: () => [CitiesLoading(), CitiesLoaded(cities: tCities)],
    );

    blocTest<HealthCenterBloc, HealthCenterState>(
      'emite [CitiesLoading, CitiesError] si falla la carga',
      build: () {
        when(mockGetCitiesUsecase(departmentId)).thenAnswer(
          (_) async => Left(
            ServerFailure(
              message: 'Error ciudades',
              data: DioExceptionType.receiveTimeout,
            ),
          ),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(CityLoad(departmentId)),
      expect: () => [CitiesLoading(), CitiesError(message: 'Error ciudades')],
    );
  });
}
