import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';
import 'package:fomagapp/data/repositories/health_center_repository.dart';
import 'package:fomagapp/presentation/health/usecase/get_health_center_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'get_health_center_usecase_test.mocks.dart';

@GenerateMocks([HealthCenterRepository])
void main() {
  late GetHealthCenterUsecase usecase;
  late MockHealthCenterRepository mockRepository;

  setUp(() {
    mockRepository = MockHealthCenterRepository();
    usecase = GetHealthCenterUsecase(healthCenterRepository: mockRepository);
  });

  final tCityId = 1;
  final tResponse = [
    HealthCenterResponse(
      id: 1,
      name: 'Centro A',
      address: 'Dirección A',
      phone1: '1111',
      phone2: '2222',
    ),
  ];

  test(
    'debe retornar una lista de centros de salud en caso de éxito',
    () async {
      when(
        mockRepository.getHealthCenters(tCityId),
      ).thenAnswer((_) async => Right(tResponse));

      final result = await usecase.getHealthCenters(tCityId);

      expect(result, Right(tResponse));
      verify(mockRepository.getHealthCenters(tCityId)).called(1);
      verifyNoMoreInteractions(mockRepository);
    },
  );

  test('debe retornar un Failure en caso de error', () async {
    final failure = ServerFailure(
      message: 'Error',
      data: DioExceptionType.badResponse,
    );
    when(
      mockRepository.getHealthCenters(tCityId),
    ).thenAnswer((_) async => Left(failure));

    final result = await usecase.getHealthCenters(tCityId);

    expect(result, Left(failure));
  });
}
