import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/repositories/cities_repository.dart';
import 'package:fomagapp/presentation/health/usecase/get_cities_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'get_cities_usecase_test.mocks.dart';

@GenerateMocks([CitiesRepository])
void main() {
  late GetCitiesUsecase usecase;
  late MockCitiesRepository mockRepository;

  setUp(() {
    mockRepository = MockCitiesRepository();
    usecase = GetCitiesUsecase(repository: mockRepository);
  });

  final departmentId = 1;
  final tCities = [
    CitiesResponse(id: 1, name: 'Ciudad A', departmentId: departmentId),
  ];

  test('debe retornar una lista de ciudades para un departamento', () async {
    when(mockRepository(departmentId)).thenAnswer((_) async => Right(tCities));

    final result = await usecase(departmentId);

    expect(result, Right(tCities));
    verify(mockRepository(departmentId)).called(1);
  });

  test('debe retornar un Failure en caso de error', () async {
    final failure = ServerFailure(
      message: 'Error',
      data: DioExceptionType.unknown,
    );
    when(mockRepository(departmentId)).thenAnswer((_) async => Left(failure));

    final result = await usecase(departmentId);

    expect(result, Left(failure));
  });
}
