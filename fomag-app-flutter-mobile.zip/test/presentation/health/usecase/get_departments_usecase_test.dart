import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/repositories/departments_health_center_repository.dart';
import 'package:fomagapp/presentation/health/usecase/get_departments_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'get_departments_usecase_test.mocks.dart';

@GenerateMocks([DepartmentsHealthCenterRepository])
void main() {
  late GetDepartmentsUsecase usecase;
  late MockDepartmentsHealthCenterRepository mockRepository;

  setUp(() {
    mockRepository = MockDepartmentsHealthCenterRepository();
    usecase = GetDepartmentsUsecase(repository: mockRepository);
  });

  final tDepartments = DepartmentsHealthCenterResponse.getDepartments;

  test('debe retornar lista de departamentos al ejecutar el usecase', () async {
    when(mockRepository()).thenAnswer((_) async => Right(tDepartments));

    final result = await usecase();

    expect(result, Right(tDepartments));
    verify(mockRepository()).called(1);
  });

  test('debe retornar un Failure si ocurre un error', () async {
    final failure = ServerFailure(
      message: 'Error',
      data: DioExceptionType.connectionError,
    );
    when(mockRepository()).thenAnswer((_) async => Left(failure));

    final result = await usecase();

    expect(result, Left(failure));
  });
}
