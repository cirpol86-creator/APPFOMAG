import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/data/model/user_event_model.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:fomagapp/presentation/splash/bloc/splash_cubit.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'splash_cubit_test.mocks.dart';

@GenerateMocks([TrackUserEventUseCase])
void main() {
  late SplashCubit cubit;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;

  setUp(() {
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();

    when(
      mockTrackUserEventUseCase.call(any),
    ).thenAnswer((_) async => Future.value());

    cubit = SplashCubit(trackUserEvent: mockTrackUserEventUseCase);
  });

  tearDown(() => cubit.close());

  test('initial state should be empty string', () {
    expect(cubit.state, '');
  });

  test('should emit version and track event on loadVersion()', () async {
    // Act
    await cubit.loadVersion();

    // Assert
    expect(cubit.state, isNotEmpty); // Cualquier versión no vacía

    verify(
      mockTrackUserEventUseCase.call(
        UserEventModel(UserEventType.appOpened, {'screen_name': 'SplashPage'}),
      ),
    ).called(1);
  });
}
