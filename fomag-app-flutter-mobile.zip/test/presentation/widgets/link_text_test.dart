import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/link_text.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

void main() {
  group('LinkTextWidget', () {
    testWidgets('renders with provided text', (WidgetTester tester) async {
      const testText = 'Test Link';

      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: LinkTextWidget(text: testText))),
      );

      expect(find.text(testText), findsOneWidget);
    });

    testWidgets('has correct text style properties', (
      WidgetTester tester,
    ) async {
      const testText = 'Test Link';

      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: LinkTextWidget(text: testText))),
      );

      final textWidget = tester.widget<Text>(find.byType(Text));
      final textStyle = textWidget.style as TextStyle;

      expect(textStyle.fontSize, 16);
      expect(textStyle.color, FomagColors.neutralText);
      expect(textStyle.fontWeight, FontWeight.w400);
      expect(textStyle.decoration, TextDecoration.underline);
      expect(textStyle.decorationThickness, 2);
      expect(textStyle.decorationColor, FomagColors.neutralText);
    });

    testWidgets('maintains text style when text changes', (
      WidgetTester tester,
    ) async {
      const initialText = 'Initial Text';
      const newText = 'New Text';

      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: LinkTextWidget(text: initialText))),
      );

      final initialTextWidget = tester.widget<Text>(find.byType(Text));
      final initialStyle = initialTextWidget.style as TextStyle;

      // Update the widget with new text
      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: LinkTextWidget(text: newText))),
      );

      final newTextWidget = tester.widget<Text>(find.byType(Text));
      final newStyle = newTextWidget.style as TextStyle;

      // Verify that the style remains the same
      expect(newStyle.fontSize, initialStyle.fontSize);
      expect(newStyle.color, initialStyle.color);
      expect(newStyle.fontWeight, initialStyle.fontWeight);
      expect(newStyle.decoration, initialStyle.decoration);
      expect(newStyle.decorationThickness, initialStyle.decorationThickness);
      expect(newStyle.decorationColor, initialStyle.decorationColor);
    });
  });
}
