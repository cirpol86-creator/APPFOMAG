import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/modals/informative_modal.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

void main() {
  group('InformativeModal', () {
    testWidgets('renders correctly with all required properties', (
      WidgetTester tester,
    ) async {
      const title = 'Test Title';
      const message = 'Test Message';
      const buttonText = 'OK';
      const iconColor = Colors.blue;
      const topIcon = Icons.info;

      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder:
                (context) => InformativeModal(
                  title: title,
                  message: message,
                  buttonText: buttonText,
                  onButtonPressed: () {},
                  iconColor: iconColor,
                  topIcon: topIcon,
                ),
          ),
        ),
      );

      // Verify title is displayed
      expect(find.text(title), findsOneWidget);

      // Verify message is displayed
      expect(find.text(message), findsOneWidget);

      // Verify button is displayed with correct text
      expect(find.text(buttonText), findsOneWidget);

      // Verify icon is displayed
      expect(find.byIcon(topIcon), findsOneWidget);
    });

    testWidgets('shows dialog when static show method is called', (
      WidgetTester tester,
    ) async {
      const title = 'Test Title';
      const message = 'Test Message';
      const buttonText = 'OK';
      const iconColor = Colors.blue;
      const topIcon = Icons.info;

      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder:
                (context) => ElevatedButton(
                  onPressed: () {
                    InformativeModal.show(
                      context: context,
                      title: title,
                      message: message,
                      buttonText: buttonText,
                      onButtonPressed: () {},
                      iconColor: iconColor,
                      topIcon: topIcon,
                    );
                  },
                  child: const Text('Show Modal'),
                ),
          ),
        ),
      );

      // Tap the button to show the modal
      await tester.tap(find.text('Show Modal'));
      await tester.pumpAndSettle();

      // Verify modal is displayed
      expect(find.text(title), findsOneWidget);
      expect(find.text(message), findsOneWidget);
      expect(find.text(buttonText), findsOneWidget);
      expect(find.byIcon(topIcon), findsOneWidget);
    });

    testWidgets('uses custom button color when provided', (
      WidgetTester tester,
    ) async {
      const customButtonColor = Colors.red;

      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder:
                (context) => InformativeModal(
                  title: 'Title',
                  message: 'Message',
                  buttonText: 'OK',
                  onButtonPressed: () {},
                  iconColor: Colors.blue,
                  topIcon: Icons.info,
                  buttonColor: customButtonColor,
                ),
          ),
        ),
      );

      final button = tester.widget<ElevatedButton>(find.byType(ElevatedButton));
      final buttonStyle = button.style as ButtonStyle;
      final backgroundColor = buttonStyle.backgroundColor?.resolve({});

      expect(backgroundColor, equals(customButtonColor));
    });

    testWidgets('uses default button color when not provided', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder:
                (context) => InformativeModal(
                  title: 'Title',
                  message: 'Message',
                  buttonText: 'OK',
                  onButtonPressed: () {},
                  iconColor: Colors.blue,
                  topIcon: Icons.info,
                ),
          ),
        ),
      );

      final button = tester.widget<ElevatedButton>(find.byType(ElevatedButton));
      final buttonStyle = button.style as ButtonStyle;
      final backgroundColor = buttonStyle.backgroundColor?.resolve({});

      expect(backgroundColor, equals(FomagColors.primaryColor));
    });
  });
}
