import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/text_label.dart';

void main() {
  group('CustomText', () {
    testWidgets('renders with default properties', (WidgetTester tester) async {
      const text = 'Test Text';

      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: CustomText(text: text))),
      );

      // Verify text is displayed
      expect(find.text(text), findsOneWidget);

      // Get the Text widget and verify its properties
      final textWidget = tester.widget<Text>(find.text(text));
      final textStyle = textWidget.style as TextStyle;

      expect(textStyle.fontSize, equals(14));
      expect(textStyle.fontWeight, equals(FontWeight.w400));
      expect(textStyle.color, equals(Colors.black));
      expect(textStyle.fontFamily, equals('NunitoSans'));
    });

    testWidgets('renders with custom properties', (WidgetTester tester) async {
      const text = 'Custom Text';
      const fontSize = 20.0;
      const fontWeight = FontWeight.bold;
      const color = Colors.blue;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomText(
              text: text,
              fontSize: fontSize,
              fontWeight: fontWeight,
              color: color,
            ),
          ),
        ),
      );

      // Verify text is displayed
      expect(find.text(text), findsOneWidget);

      // Get the Text widget and verify its properties
      final textWidget = tester.widget<Text>(find.text(text));
      final textStyle = textWidget.style as TextStyle;

      expect(textStyle.fontSize, equals(fontSize));
      expect(textStyle.fontWeight, equals(fontWeight));
      expect(textStyle.color, equals(color));
      expect(textStyle.fontFamily, equals('NunitoSans'));
    });

    testWidgets('renders with different text content', (
      WidgetTester tester,
    ) async {
      const text1 = 'First Text';
      const text2 = 'Second Text';

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Column(
              children: const [
                CustomText(text: text1),
                CustomText(text: text2),
              ],
            ),
          ),
        ),
      );

      // Verify both texts are displayed
      expect(find.text(text1), findsOneWidget);
      expect(find.text(text2), findsOneWidget);

      // Verify both texts have the same default properties
      final text1Widget = tester.widget<Text>(find.text(text1));
      final text2Widget = tester.widget<Text>(find.text(text2));
      final text1Style = text1Widget.style as TextStyle;
      final text2Style = text2Widget.style as TextStyle;

      expect(text1Style.fontSize, equals(text2Style.fontSize));
      expect(text1Style.fontWeight, equals(text2Style.fontWeight));
      expect(text1Style.color, equals(text2Style.color));
      expect(text1Style.fontFamily, equals(text2Style.fontFamily));
    });
  });
}
