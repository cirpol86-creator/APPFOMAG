import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_text.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

void main() {
  group('RoundedEntry', () {
    testWidgets('renders with basic properties', (WidgetTester tester) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(body: RoundedEntry(label: label, hintText: hintText)),
        ),
      );

      // Assert
      expect(find.text(label), findsOneWidget);
      expect(find.text(hintText), findsOneWidget);
      expect(find.byType(TextFormField), findsOneWidget);
    });

    testWidgets('shows validation error when empty', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      final formKey = GlobalKey<FormState>();

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Form(key: formKey, child: RoundedEntry(label: label)),
          ),
        ),
      );

      // Trigger validation
      formKey.currentState?.validate();
      await tester.pump();

      // Assert
      expect(find.text('Este campo es obligatorio'), findsOneWidget);
    });

    testWidgets('uses custom validator when provided', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      const errorMessage = 'Custom error message';
      final formKey = GlobalKey<FormState>();

      String? customValidator(String? value) {
        return value?.isEmpty ?? true ? errorMessage : null;
      }

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Form(
              key: formKey,
              child: RoundedEntry(label: label, validator: customValidator),
            ),
          ),
        ),
      );

      // Trigger validation
      formKey.currentState?.validate();
      await tester.pump();

      // Assert
      expect(find.text(errorMessage), findsOneWidget);
    });

    testWidgets('toggles password visibility', (WidgetTester tester) async {
      // Arrange
      const label = 'Test Label';
      final controller = TextEditingController();

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RoundedEntry(
              label: label,
              isPassword: true,
              controller: controller,
            ),
          ),
        ),
      );

      // Enter password text
      await tester.enterText(find.byType(TextFormField), 'password123');
      await tester.pump();

      // Initial state should be obscured
      expect(find.byIcon(Icons.visibility_off_outlined), findsOneWidget);

      // Tap visibility toggle
      await tester.tap(find.byIcon(Icons.visibility_off_outlined));
      await tester.pump();

      // Assert
      expect(find.byIcon(Icons.visibility_outlined), findsOneWidget);
    });

    testWidgets('updates text when controller changes', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      final controller = TextEditingController();

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RoundedEntry(label: label, controller: controller),
          ),
        ),
      );

      // Change controller text
      controller.text = 'new text';
      await tester.pump();

      // Assert
      expect(find.text('new text'), findsOneWidget);
    });

    testWidgets('shows error state with red label', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      final formKey = GlobalKey<FormState>();

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Form(key: formKey, child: RoundedEntry(label: label)),
          ),
        ),
      );

      // Trigger validation
      formKey.currentState?.validate();
      await tester.pumpAndSettle();

      // Assert
      final labelFinder = find.text(label);
      final labelWidget = tester.widget<Text>(labelFinder);
      // If the label is not a direct Text widget, consider using a Key in RoundedEntry for the label and finding by Key here.
      expect(labelWidget.style?.color, equals(FomagColors.redButton));
    });
  });
}
