import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/inputs/input_picker.dart';

void main() {
  group('RoundedPicker', () {
    testWidgets('renders with basic properties', (WidgetTester tester) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';
      const options = ['Option 1', 'Option 2', 'Option 3'];

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RoundedPicker(
              label: label,
              hintText: hintText,
              options: options,
              onChanged: (value) {},
              selectedValue: options.first,
            ),
          ),
        ),
      );

      // Assert
      expect(find.text(label), findsOneWidget);
      expect(find.text(hintText), findsOneWidget);
      expect(find.byType(DropdownButtonFormField<String>), findsOneWidget);
    });

    testWidgets('shows validation error when no option selected', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';
      const options = ['Option 1', 'Option 2'];
      final formKey = GlobalKey<FormState>();

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Form(
              key: formKey,
              child: RoundedPicker(
                label: label,
                hintText: hintText,
                options: options,
                onChanged: (value) {},
                selectedValue: options.first,
              ),
            ),
          ),
        ),
      );

      // Trigger validation
      formKey.currentState?.validate();
      await tester.pump();

      // Assert
      expect(find.text('Seleccione una opción'), findsOneWidget);
    });

    testWidgets('uses custom validator when provided', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';
      const options = ['Option 1', 'Option 2'];
      const errorMessage = 'Custom error message';
      final formKey = GlobalKey<FormState>();

      String? customValidator(String? value) {
        return value?.isEmpty ?? true ? errorMessage : null;
      }

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Form(
              key: formKey,
              child: RoundedPicker(
                label: label,
                hintText: hintText,
                options: options,
                validator: customValidator,
                onChanged: (value) {},
                selectedValue: options.first,
              ),
            ),
          ),
        ),
      );

      // Trigger validation
      formKey.currentState?.validate();
      await tester.pump();

      // Assert
      expect(find.text(errorMessage), findsOneWidget);
    });

    testWidgets('selects option and calls onChanged', (
      WidgetTester tester,
    ) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';
      const options = ['Option 1', 'Option 2', 'Option 3'];
      String? selectedValue;

      void onChanged(String? value) {
        selectedValue = value;
      }

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RoundedPicker(
              label: label,
              hintText: hintText,
              options: options,
              onChanged: onChanged,
              selectedValue: options.first,
            ),
          ),
        ),
      );

      // Open dropdown
      await tester.tap(find.byType(DropdownButtonFormField<String>));
      await tester.pumpAndSettle();

      // Select option
      await tester.tap(find.text('Option 2').last);
      await tester.pumpAndSettle();

      // Assert
      expect(selectedValue, equals('Option 2'));
    });

    testWidgets('initializes with selected value', (WidgetTester tester) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';
      const options = ['Option 1', 'Option 2', 'Option 3'];
      const initialValue = 'Option 2';

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RoundedPicker(
              label: label,
              hintText: hintText,
              options: options,
              selectedValue: initialValue,
              onChanged: (value) {},
            ),
          ),
        ),
      );

      // Assert
      expect(find.text(initialValue), findsOneWidget);
    });

    testWidgets('shows all options in dropdown', (WidgetTester tester) async {
      // Arrange
      const label = 'Test Label';
      const hintText = 'Test Hint';
      const options = ['Option 1', 'Option 2', 'Option 3'];

      // Act
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RoundedPicker(
              label: label,
              hintText: hintText,
              options: options,
              onChanged: (value) {},
              selectedValue: options.first,
            ),
          ),
        ),
      );

      // Open dropdown
      await tester.tap(find.byType(DropdownButtonFormField<String>));
      await tester.pumpAndSettle();

      // Assert
      for (final option in options) {
        expect(find.text(option), findsOneWidget);
      }
    });
  });
}
