import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/screens/progress_loader_screen.dart';

void main() {
  testWidgets('ProgressLoaderScreen muestra el mensaje y el botón Continuar', (
    WidgetTester tester,
  ) async {
    bool onFinishCalled = false;

    await tester.pumpWidget(
      MaterialApp(
        home: ProgressLoaderScreen(
          message: 'Cargando...',
          onFinish: () {
            onFinishCalled = true;
          },
          duration: const Duration(milliseconds: 100), // para test rápido
        ),
      ),
    );

    // Verifica que el mensaje se muestre
    expect(find.text('Cargando...'), findsOneWidget);

    // Espera a que termine el progreso
    await tester.pumpAndSettle(const Duration(milliseconds: 200));

    // El botón debe estar habilitado y visible
    expect(find.text('Continuar'), findsOneWidget);
    final continuarButton = tester.widget<ElevatedButton>(
      find.byType(ElevatedButton),
    );
    expect(continuarButton.enabled, isTrue);

    // Presiona el botón
    await tester.tap(find.text('Continuar'));
    await tester.pump();

    // Verifica que se llamó a onFinish
    expect(onFinishCalled, isTrue);
  });

  testWidgets('ProgressLoaderScreen muestra error y botón de Reintentar', (
    WidgetTester tester,
  ) async {
    bool onFinishCalled = false;

    await tester.pumpWidget(
      MaterialApp(
        home: ProgressLoaderScreen(
          message: 'Hubo un error',
          onFinish: () {
            onFinishCalled = true;
          },
          duration: const Duration(milliseconds: 100),
          isError: true,
        ),
      ),
    );

    // Verifica que el mensaje se muestre
    expect(find.text('Hubo un error'), findsOneWidget);
    expect(find.text('Error'), findsOneWidget);

    // Espera a que termine el progreso
    await tester.pumpAndSettle(const Duration(milliseconds: 200));

    // El botón debe estar habilitado y visible
    expect(find.text('Reintentar'), findsOneWidget);
    final reintentarButton = tester.widget<ElevatedButton>(
      find.byType(ElevatedButton),
    );
    expect(reintentarButton.enabled, isTrue);

    // Presiona el botón
    await tester.tap(find.text('Reintentar'));
    await tester.pump();

    // Verifica que se llamó a onFinish
    expect(onFinishCalled, isTrue);
  });
}
