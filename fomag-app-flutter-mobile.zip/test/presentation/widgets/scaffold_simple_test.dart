import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/presentation/widgets/scaffolds/scaffold_simple.dart';
import 'package:fomagapp/presentation/theme/colors.dart';

void main() {
  group('ScaffoldSimple', () {
    testWidgets('renders with correct background color', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(home: ScaffoldSimple(body: Container())),
      );

      final scaffold = tester.widget<Scaffold>(find.byType(Scaffold));
      expect(scaffold.backgroundColor, FomagColors.white);
    });

    testWidgets('renders with correct padding', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(home: ScaffoldSimple(body: Container())),
      );

      final padding = tester.widget<Padding>(find.byType(Padding));
      expect(
        padding.padding,
        const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
      );
    });

    testWidgets('renders back button', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(home: ScaffoldSimple(body: Container())),
      );

      expect(find.byType(InkWell), findsOneWidget);
    });

    testWidgets('renders body with correct body', (WidgetTester tester) async {
      const testBody = Text('Test Body');

      await tester.pumpWidget(
        MaterialApp(home: ScaffoldSimple(body: testBody)),
      );

      expect(find.text('Test Body'), findsOneWidget);
    });

    testWidgets('renders in SingleChildScrollView', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(home: ScaffoldSimple(body: Container())),
      );

      expect(find.byType(SingleChildScrollView), findsOneWidget);
    });

    testWidgets('maintains crossAxisAlignment start', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        MaterialApp(home: ScaffoldSimple(body: Container())),
      );

      final column = tester.widget<Column>(find.byType(Column));
      expect(column.crossAxisAlignment, CrossAxisAlignment.start);
    });
  });
}
