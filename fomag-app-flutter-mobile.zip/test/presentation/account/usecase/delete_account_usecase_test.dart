import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/core/network/util/const.dart';
import 'package:fomagapp/data/model/delete_account_model.dart';
import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';
import 'package:fomagapp/data/repositories/delete_account_repository.dart';
import 'package:fomagapp/presentation/account/usecase/delete_account_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'delete_account_usecase_test.mocks.dart';

@GenerateMocks([DeleteAccountRepository])
void main() {
  late MockDeleteAccountRepository mockRepository;
  late DeleteAccountUsecase usecase;

  setUp(() {
    mockRepository = MockDeleteAccountRepository();
    usecase = DeleteAccountUsecase(deleteAccountRepository: mockRepository);
  });

  group('DeleteAccountUsecase', () {
    test(
      'debe retornar DeleteAccountModel cuando la respuesta es válida',
      () async {
        const rawMessage = 'Éxito - La cuenta fue eliminada';
        final response = DeleteAccountResponse(message: rawMessage);
        final expected = DeleteAccountModel(
          title: 'Éxito',
          message: 'La cuenta fue eliminada',
        );

        when(
          mockRepository.deleteAccount(),
        ).thenAnswer((_) async => Right(response));

        final result = await usecase.deleteAccount();

        expect(result, equals(Right(expected)));
      },
    );

    test('debe retornar Failure cuando la respuesta no tiene guion', () async {
      final response = DeleteAccountResponse(message: 'Mensaje inválido');

      when(
        mockRepository.deleteAccount(),
      ).thenAnswer((_) async => Right(response));

      final result = await usecase.deleteAccount();

      expect(
        result,
        equals(
          Left(
            Failure(
              message: Const.defaultMessageErrorServer,
              data: DioExceptionType.badResponse,
            ),
          ),
        ),
      );
    });

    test(
      'debe retornar Failure cuando ocurre un error en el repositorio',
      () async {
        final failure = Failure<DioExceptionType>(
          message: 'Error',
          data: DioExceptionType.connectionError,
        );

        when(
          mockRepository.deleteAccount(),
        ).thenAnswer((_) async => Left(failure));

        final result = await usecase.deleteAccount();

        expect(result, equals(Left(failure)));
      },
    );
  });
}
