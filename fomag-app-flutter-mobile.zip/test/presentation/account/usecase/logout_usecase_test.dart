import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:fomagapp/data/repositories/logout_repository.dart';
import 'package:fomagapp/presentation/account/usecase/logout_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'logout_usecase_test.mocks.dart';

@GenerateMocks([LogoutRepository])
void main() {
  late MockLogoutRepository mockRepository;
  late LogoutUsecase usecase;

  setUp(() {
    mockRepository = MockLogoutRepository();
    usecase = LogoutUsecase(repository: mockRepository);
  });

  test('debe retornar Right(void) cuando el logout es exitoso', () async {
    final request = LogoutRequest(accessToken: 'token');

    when(mockRepository(request)).thenAnswer((_) async => const Right(null));

    final result = await usecase.call(request);

    expect(result, equals(const Right(null)));
  });

  test('debe retornar Left(Failure) cuando el logout falla', () async {
    final request = LogoutRequest(accessToken: 'token');
    final failure = Failure<DioExceptionType>(
      message: 'Error',
      data: DioExceptionType.connectionError,
    );

    when(mockRepository(request)).thenAnswer((_) async => Left(failure));

    final result = await usecase.call(request);

    expect(result, equals(Left(failure)));
  });
}
