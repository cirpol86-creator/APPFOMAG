import 'package:bloc_test/bloc_test.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';
import 'package:fomagapp/data/model/delete_account_model.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_bloc.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_event.dart';
import 'package:fomagapp/presentation/account/bloc/delete_account_state.dart';
import 'package:fomagapp/presentation/account/usecase/delete_account_usecase.dart';
import 'package:fomagapp/presentation/account/usecase/logout_usecase.dart';
import 'package:fomagapp/presentation/analytics/usecase/track_event_usecase.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'delete_account_bloc_test.mocks.dart';

@GenerateMocks([DeleteAccountUsecase, LogoutUsecase, TrackUserEventUseCase])
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late MockDeleteAccountUsecase mockDeleteAccountUsecase;
  late MockLogoutUsecase mockLogoutUsecase;
  late MockTrackUserEventUseCase mockTrackUserEventUseCase;
  late DeleteAccountBloc bloc;

  setUp(() {
    mockDeleteAccountUsecase = MockDeleteAccountUsecase();
    mockLogoutUsecase = MockLogoutUsecase();
    mockTrackUserEventUseCase = MockTrackUserEventUseCase();

    bloc = DeleteAccountBloc(
      deleteAccountUsecase: mockDeleteAccountUsecase,
      logoutUsecase: mockLogoutUsecase,
      trackUserEventUseCase: mockTrackUserEventUseCase,
    );
  });

  group('DeleteAccountBloc', () {
    final deleteModel = DeleteAccountModel(
      title: 'Cuenta eliminada',
      message: 'Tu cuenta ha sido eliminada con éxito.',
    );

    test('estado inicial debe ser DeleteAccountInitial', () {
      expect(bloc.state, DeleteAccountInitial());
    });

    blocTest<DeleteAccountBloc, DeleteAccountState>(
      'emite [Loading, Success] cuando la eliminación es exitosa',
      build: () {
        when(
          mockDeleteAccountUsecase.deleteAccount(),
        ).thenAnswer((_) async => Right(deleteModel));
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteAccount()),
      expect: () => [DeleteAccountLoading(), DeleteAccountSuccess(deleteModel)],
      verify: (_) {
        verify(mockDeleteAccountUsecase.deleteAccount()).called(1);
      },
    );

    blocTest<DeleteAccountBloc, DeleteAccountState>(
      'emite [Loading, Error] cuando falla la eliminación de cuenta',
      build: () {
        when(mockDeleteAccountUsecase.deleteAccount()).thenAnswer(
          (_) async => Left(
            Failure<DioExceptionType>(
              message: 'Error inesperado',
              data: DioExceptionType.badResponse,
            ),
          ),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(DeleteAccount()),
      expect:
          () => [
            DeleteAccountLoading(),
            const DeleteAccountError(message: 'Error inesperado'),
          ],
    );

    blocTest<DeleteAccountBloc, DeleteAccountState>(
      'solo llama al trackUserEvent cuando se envía TrackerEvent',
      build: () {
        when(mockTrackUserEventUseCase.call(any)).thenAnswer((_) async {});
        return bloc;
      },
      act: (bloc) => bloc.add(TrackerEvent()),
      expect: () => [],
      verify: (_) {
        verify(mockTrackUserEventUseCase.call(any)).called(1);
      },
    );

    blocTest<DeleteAccountBloc, DeleteAccountState>(
      'emite [Loading, Logouted] cuando el logout es exitoso al primer intento',
      build: () {
        when(mockLogoutUsecase(any)).thenAnswer((_) async => const Right(null));
        return bloc;
      },
      act: (bloc) => bloc.add(Logout()),
      expect: () => [DeleteAccountLoading(), Logouted()],
      verify: (_) {
        verify(mockLogoutUsecase(any)).called(1);
      },
    );

    blocTest<DeleteAccountBloc, DeleteAccountState>(
      'emite [Loading, Logouted] luego de 3 intentos fallidos de logout',
      build: () {
        when(mockLogoutUsecase(any)).thenAnswer(
          (_) async => Left(
            Failure<DioExceptionType>(
              message: 'Error logout',
              data: DioExceptionType.connectionTimeout,
            ),
          ),
        );
        return bloc;
      },
      act: (bloc) => bloc.add(Logout()),
      expect: () => [DeleteAccountLoading(), Logouted()],
      verify: (_) {
        verify(mockLogoutUsecase(any)).called(3);
      },
    );
  });
  test('DeleteAccountEvent: igualdad y props funcionan correctamente', () {
    expect(DeleteAccount(), DeleteAccount());
    expect(Logout(), Logout());
    expect(TrackerEvent(), TrackerEvent());

    expect(DeleteAccount().props, []);
    expect(Logout().props, []);
    expect(TrackerEvent().props, []);
  });
}
