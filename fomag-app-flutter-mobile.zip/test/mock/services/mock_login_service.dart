import 'package:mockito/annotations.dart';
import 'package:fomagapp/core/network/services/abstract/login_service.dart';

@GenerateMocks([LoginService])
void main() {}
