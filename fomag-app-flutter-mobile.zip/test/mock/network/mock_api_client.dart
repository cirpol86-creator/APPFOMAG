import 'package:mockito/annotations.dart';
import 'package:fomagapp/core/network/api_client.dart';

@GenerateMocks([ApiClient])
void main() {}
