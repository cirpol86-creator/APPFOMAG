import 'package:fomagapp/data/repositories/login_repository.dart';
import 'package:mockito/annotations.dart';

@GenerateMocks([LoginRepository])
void main() {}
