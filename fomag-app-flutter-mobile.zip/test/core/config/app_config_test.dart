import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/enviroment/environment.dart';

class MockEnvironment extends Environment {
  MockEnvironment({required super.baseDomain}) : super(envName: 'Test');
}

void main() {
  group('AppConfig', () {
    test('should create singleton instance', () {
      final config1 = AppConfig.shared;
      final config2 = AppConfig.shared;

      expect(config1, equals(config2));
      expect(identical(config1, config2), isTrue);
    });

    test('should set environment through factory constructor', () {
      final mockEnv = MockEnvironment(baseDomain: 'test.com');
      final config = AppConfig(env: mockEnv);

      expect(config.baseDomain, equals('test.com'));
      expect(AppConfig.shared.baseDomain, equals('test.com'));
    });

    test('should return empty string when environment is not set', () {
      final config = AppConfig.shared;
      config.env = null;

      expect(config.baseDomain, equals(''));
    });

    test('should update baseDomain when environment changes', () {
      final config = AppConfig.shared;
      final mockEnv1 = MockEnvironment(baseDomain: 'test1.com');
      final mockEnv2 = MockEnvironment(baseDomain: 'test2.com');

      config.env = mockEnv1;
      expect(config.baseDomain, equals('test1.com'));

      config.env = mockEnv2;
      expect(config.baseDomain, equals('test2.com'));
    });

    test('should return environment name', () {
      final mockEnv = MockEnvironment(baseDomain: 'test.com');
      final config = AppConfig(env: mockEnv);

      expect(config.enviromentName, equals('Test'));
    });
  });
}
