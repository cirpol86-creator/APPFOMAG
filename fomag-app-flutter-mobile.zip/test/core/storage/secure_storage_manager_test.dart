import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/core/storage/secure_storage_manager.dart';

@GenerateMocks([FlutterSecureStorage])
import 'secure_storage_manager_test.mocks.dart';

void main() {
  late MockFlutterSecureStorage mockStorage;

  setUp(() {
    mockStorage = MockFlutterSecureStorage();
    SecureStorageManager.setStorage(mockStorage);
  });
  group('SecureStorageManager', () {
    test('setDocumentNumber writes to storage', () async {
      await SecureStorageManager.setDocumentNumber('12345');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyDocumentNumber,
          value: '12345',
        ),
      ).called(1);
    });

    test('getDocumentNumber reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyDocumentNumber),
      ).thenAnswer((_) async => '12345');
      final result = await SecureStorageManager.getDocumentNumber();
      expect(result, '12345');
    });

    test('setProfile writes map as json string', () async {
      final profile = {'name': 'test'};
      await SecureStorageManager.setProfile(profile);
      verify(
        mockStorage.write(key: 'keyProfile', value: jsonEncode(profile)),
      ).called(1);
    });

    test('getProfileMap returns map from json string', () async {
      when(
        mockStorage.read(key: 'keyProfile'),
      ).thenAnswer((_) async => '{"name":"test"}');
      final result = await SecureStorageManager.getProfileMap();
      expect(result, {'name': 'test'});
    });

    test('getProfileMap returns null if no value', () async {
      when(mockStorage.read(key: 'keyProfile')).thenAnswer((_) async => null);
      final result = await SecureStorageManager.getProfileMap();
      expect(result, null);
    });

    test('setPassword writes to storage', () async {
      await SecureStorageManager.setPassword('pass');
      verify(
        mockStorage.write(key: SecureStorageManager.keyPassword, value: 'pass'),
      ).called(1);
    });

    test('getPassword reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyPassword),
      ).thenAnswer((_) async => 'pass');
      final result = await SecureStorageManager.getPassword();
      expect(result, 'pass');
    });

    test('setSessionToken writes to storage', () async {
      await SecureStorageManager.setSessionToken('token');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keySessionToken,
          value: 'token',
        ),
      ).called(1);
    });

    test('getSessionToken reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keySessionToken),
      ).thenAnswer((_) async => 'token');
      final result = await SecureStorageManager.getSessionToken();
      expect(result, 'token');
    });

    test('setChallenge writes to storage', () async {
      await SecureStorageManager.setChallenge('challenge');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyChallenge,
          value: 'challenge',
        ),
      ).called(1);
    });

    test('getChallenge reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyChallenge),
      ).thenAnswer((_) async => 'challenge');
      final result = await SecureStorageManager.getChallenge();
      expect(result, 'challenge');
    });

    test('setChallengeName writes to storage', () async {
      await SecureStorageManager.setChallengeName('challengeName');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyChallengeName,
          value: 'challengeName',
        ),
      ).called(1);
    });

    test('getChallengeName reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyChallengeName),
      ).thenAnswer((_) async => 'challengeName');
      final result = await SecureStorageManager.getChallengeName();
      expect(result, 'challengeName');
    });

    test('setUserName writes to storage', () async {
      await SecureStorageManager.setUserName('user');
      verify(
        mockStorage.write(key: SecureStorageManager.keyUserName, value: 'user'),
      ).called(1);
    });

    test('getUserName reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyUserName),
      ).thenAnswer((_) async => 'user');
      final result = await SecureStorageManager.getUserName();
      expect(result, 'user');
    });

    test('setAccessToken writes to storage', () async {
      await SecureStorageManager.setAccessToken('access');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyAccessToken,
          value: 'access',
        ),
      ).called(1);
    });

    test('getAccessToken reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyAccessToken),
      ).thenAnswer((_) async => 'access');
      final result = await SecureStorageManager.getAccessToken();
      expect(result, 'access');
    });

    test('setRefreshToken writes to storage', () async {
      await SecureStorageManager.setRefreshToken('refresh');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyRefreshToken,
          value: 'refresh',
        ),
      ).called(1);
    });

    test('getRefreshToken reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyRefreshToken),
      ).thenAnswer((_) async => 'refresh');
      final result = await SecureStorageManager.getRefreshToken();
      expect(result, 'refresh');
    });

    test('setTypeDocument writes to storage', () async {
      await SecureStorageManager.setTypeDocument('type');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyTypeDocument,
          value: 'type',
        ),
      ).called(1);
    });

    test('getTypeDocument reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyTypeDocument),
      ).thenAnswer((_) async => 'type');
      final result = await SecureStorageManager.getTypeDocument();
      expect(result, 'type');
    });

    test('setIdToken writes to storage', () async {
      await SecureStorageManager.setIdToken('idtoken');
      verify(
        mockStorage.write(
          key: SecureStorageManager.keyIdToken,
          value: 'idtoken',
        ),
      ).called(1);
    });

    test('getIdToken reads from storage', () async {
      when(
        mockStorage.read(key: SecureStorageManager.keyIdToken),
      ).thenAnswer((_) async => 'idtoken');
      final result = await SecureStorageManager.getIdToken();
      expect(result, 'idtoken');
    });

    test('clearAll calls deleteAll', () async {
      await SecureStorageManager.clearAll();
      verify(mockStorage.deleteAll()).called(1);
    });
    // Puedes agregar tests similares para los otros setters y getters si lo necesitas.
  });
  tearDown(() {
    // Limpiar el mock después de cada prueba
  });
}
