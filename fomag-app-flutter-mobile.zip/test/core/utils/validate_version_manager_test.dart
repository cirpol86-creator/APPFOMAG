import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/utils/validate_version_manager.dart';
import 'package:package_info_plus/package_info_plus.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('ValidateVersionManager', () {
    setUp(() {
      PackageInfo.setMockInitialValues(
        appName: 'test',
        packageName: 'test',
        version: '1.0.0',
        buildNumber: '1',
        buildSignature: 'test',
      );
    });

    test('getVersion returns version from PackageInfo', () async {
      // Act
      final version = await ValidateVersionManager.getVersion();

      // Assert
      expect(version, equals('1.0.0'));
    });

    test('props returns empty list', () {
      // Arrange
      final manager = ValidateVersionManager();

      // Act
      final props = manager.props;

      // Assert
      expect(props, isEmpty);
    });
  });
}
