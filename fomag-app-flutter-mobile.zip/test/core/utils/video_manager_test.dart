import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/utils/video_manager.dart';
import 'package:mockito/mockito.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';

// Mocks
class MockVideoPlayerController extends Mock implements VideoPlayerController {
  @override
  Future<void> dispose() => Future.value();
}

class MockChewieController extends Mock implements ChewieController {
  @override
  Future<void> dispose() => Future.value();
}

void main() {
  group('VideoManager', () {
    late VideoManager videoManager;

    setUp(() {
      videoManager = VideoManager();
    });

    test('should set and get videoController', () {
      final mockController = MockVideoPlayerController();
      videoManager.videoController = mockController;
      expect(videoManager.videoController, mockController);
    });

    test('should set and get chewieController', () {
      final mockChewie = MockChewieController();
      videoManager.chewieController = mockChewie;
      expect(videoManager.chewieController, mockChewie);
    });

    test('should set and get widthVideo', () {
      videoManager.widthVideo = 1920.0;
      expect(videoManager.widthVideo, 1920.0);
    });

    test('should set and get heightVideo', () {
      videoManager.heightVideo = 1080.0;
      expect(videoManager.heightVideo, 1080.0);
    });

    test('should set and get aspectRatio', () {
      videoManager.aspectRatio = 16 / 9;
      expect(videoManager.aspectRatio, 16 / 9);
    });
  });
}
