import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/utils/svg_manager.dart';
import 'package:flutter_svg/svg.dart';

void main() {
  group('SvgManager', () {
    test('has correct asset paths', () {
      expect(SvgManager.logo, isA<SvgPicture>());
      expect(SvgManager.arrowLeft, isA<SvgPicture>());
      expect(SvgManager.stroke, isA<SvgPicture>());
      expect(SvgManager.retry, isA<SvgPicture>());
      expect(SvgManager.menu, isA<SvgPicture>());
      expect(SvgManager.user, isA<SvgPicture>());
      expect(SvgManager.house, isA<SvgPicture>());
      expect(SvgManager.headset, isA<SvgPicture>());
      expect(SvgManager.news, isA<SvgPicture>());
      expect(SvgManager.hospital, isA<SvgPicture>());
      expect(SvgManager.ask, isA<SvgPicture>());
      expect(SvgManager.checkCloud, isA<SvgPicture>());
      expect(SvgManager.phone, isA<SvgPicture>());
      expect(SvgManager.certificate, isA<SvgPicture>());
      expect(SvgManager.arrowRightBordered, isA<SvgPicture>());
      expect(SvgManager.checkBordered, isA<SvgPicture>());
      expect(SvgManager.arrowRightSimple, isA<SvgPicture>());
      expect(SvgManager.arrowLeftSimple, isA<SvgPicture>());
      expect(SvgManager.happyFace, isA<SvgPicture>());
      expect(SvgManager.logout, isA<SvgPicture>());
      expect(SvgManager.key, isA<SvgPicture>());
      expect(SvgManager.withoutInternet, isA<SvgPicture>());
      expect(SvgManager.mapPinned, isA<SvgPicture>());
    });

    test('extends Equatable with correct props', () {
      final manager = SvgManager();

      expect(manager.props, []);
    });

    test('getSvgWithColor returns SvgPicture', () {
      final svg = SvgManager.getSvgWithColor(
        SvgManager.logoPath,
        const Color(0xFF000000),
      );
      expect(svg, isA<SvgPicture>());
    });
  });
}
