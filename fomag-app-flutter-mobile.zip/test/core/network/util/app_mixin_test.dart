import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/util/app_mixin.dart';
import 'package:mockito/mockito.dart';

// Mock de Connectivity para pruebas
class MockConnectivity extends Mock implements Connectivity {
  @override
  Future<List<ConnectivityResult>> checkConnectivity() async {
    return connectivityResults;
  }

  List<ConnectivityResult> connectivityResults = [ConnectivityResult.wifi];
}

// Clase de prueba para ConnectivityMixin
class TestConnectivity with ConnectivityMixin {
  final MockConnectivity _mockConnectivity;

  TestConnectivity(this._mockConnectivity);

  @override
  Connectivity get connectivity => _mockConnectivity;
}

// Clase de prueba para AfterLayoutMixin
class TestAfterLayoutWidget extends StatefulWidget {
  final Function(BuildContext) onAfterLayoutCallback;

  const TestAfterLayoutWidget({super.key, required this.onAfterLayoutCallback});

  @override
  TestAfterLayoutWidgetState createState() => TestAfterLayoutWidgetState();
}

class TestAfterLayoutWidgetState extends State<TestAfterLayoutWidget>
    with AfterLayoutMixin {
  @override
  Widget build(BuildContext context) {
    return Container();
  }

  @override
  Future<void> afterFirstLayout(BuildContext context) async {
    widget.onAfterLayoutCallback(context);
  }
}

void main() {
  group('ConnectivityMixin', () {
    late MockConnectivity mockConnectivity;
    late TestConnectivity testConnectivity;

    setUp(() {
      mockConnectivity = MockConnectivity();
      testConnectivity = TestConnectivity(mockConnectivity);
    });

    test(
      'isInConnection should return true when there is an internet connection',
      () async {
        // Configurar el mock para simular conexión WiFi
        mockConnectivity.connectivityResults = [ConnectivityResult.wifi];

        // Verificar que isInConnection devuelve true
        final result = await testConnectivity.isInConnection();
        expect(result, true);
      },
    );

    test('isInConnection should return true for mobile connection', () async {
      // Configurar el mock para simular conexión móvil
      mockConnectivity.connectivityResults = [ConnectivityResult.mobile];

      // Verificar que isInConnection devuelve true
      final result = await testConnectivity.isInConnection();
      expect(result, true);
    });

    test('isInConnection should return true for ethernet connection', () async {
      // Configurar el mock para simular conexión ethernet
      mockConnectivity.connectivityResults = [ConnectivityResult.ethernet];

      // Verificar que isInConnection devuelve true
      final result = await testConnectivity.isInConnection();
      expect(result, true);
    });

    test(
      'isInConnection should return false when there is no internet connection',
      () async {
        // Configurar el mock para simular sin conexión
        mockConnectivity.connectivityResults = [ConnectivityResult.none];

        // Verificar que isInConnection devuelve false
        final result = await testConnectivity.isInConnection();
        expect(result, false);
      },
    );

    test(
      'isInConnection should return false when connectivity list is empty',
      () async {
        // Configurar el mock para simular una lista vacía de resultados
        mockConnectivity.connectivityResults = [];

        // Verificar que isInConnection devuelve false en caso de una lista vacía
        final result = await testConnectivity.isInConnection();
        expect(result, false);
      },
    );
  });

  group('AfterLayoutMixin', () {
    testWidgets('afterFirstLayout should be called after first layout', (
      WidgetTester tester,
    ) async {
      bool afterLayoutCalled = false;

      // Crear un widget que utiliza AfterLayoutMixin
      await tester.pumpWidget(
        MaterialApp(
          home: TestAfterLayoutWidget(
            onAfterLayoutCallback: (_) {
              afterLayoutCalled = true;
            },
          ),
        ),
      );

      // Después de pump, el callback debería haberse llamado en el siguiente frame
      await tester.pumpAndSettle();

      // Verificar que afterFirstLayout se llamó
      expect(afterLayoutCalled, true);
    });

    testWidgets('afterFirstLayout should have access to context', (
      WidgetTester tester,
    ) async {
      late BuildContext capturedContext;

      // Crear un widget que utiliza AfterLayoutMixin y captura el contexto
      await tester.pumpWidget(
        MaterialApp(
          home: TestAfterLayoutWidget(
            onAfterLayoutCallback: (context) {
              capturedContext = context;
            },
          ),
        ),
      );

      // Esperar a que se complete el layout
      await tester.pumpAndSettle();

      // Verificar que el contexto pasado a afterFirstLayout es válido
      expect(capturedContext, isNotNull);
      expect(capturedContext.findRenderObject(), isNotNull);
    });
  });
}
