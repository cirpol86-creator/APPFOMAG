import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'package:fomagapp/core/network/interceptor/curl_log.dart';
import 'dart:async';

class _TestErrorInterceptorHandler extends ErrorInterceptorHandler {
  final void Function(DioException) onNext;

  _TestErrorInterceptorHandler({required this.onNext});

  @override
  void next(DioException err) {
    onNext(err);
  }
}

void main() {
  group('CurlLogInterceptor', () {
    late CurlLogInterceptor interceptor;

    setUp(() {
      interceptor = CurlLogInterceptor();
    });

    test('should create with default configuration', () {
      expect(interceptor, isNotNull);
      expect(interceptor, isA<PrettyDioLogger>());
    });

    test('should create with disabled request body', () {
      final interceptorWithDisabledBody = CurlLogInterceptor(
        disableRequestBody: true,
      );
      expect(interceptorWithDisabledBody, isNotNull);
      expect(interceptorWithDisabledBody, isA<PrettyDioLogger>());
    });

    test('should handle onRequest', () {
      final requestOptions = RequestOptions(
        path: '/test',
        method: 'GET',
        headers: {'Content-Type': 'application/json'},
      );
      final handler = RequestInterceptorHandler();

      interceptor.onRequest(requestOptions, handler);
      expect(handler.isCompleted, true);
    });

    test('should handle onResponse', () {
      final requestOptions = RequestOptions(path: '/test', method: 'GET');
      final response = Response(
        requestOptions: requestOptions,
        data: {'test': 'data'},
        statusCode: 200,
      );
      final handler = ResponseInterceptorHandler();

      interceptor.onResponse(response, handler);
      expect(handler.isCompleted, true);
    });

    test('should handle onError', () async {
      final requestOptions = RequestOptions(
        path: '/test',
        method: 'GET',
        headers: {'Content-Type': 'application/json'},
      );

      final error = DioException(
        requestOptions: requestOptions,
        type: DioExceptionType.connectionError,
        error: 'Connection error',
        message: 'Failed to connect to server',
      );

      final completer = Completer<DioException>();

      final handler = _TestErrorInterceptorHandler(onNext: completer.complete);

      // Llamar al interceptor
      interceptor.onError(error, handler);

      final result = await completer.future;

      expect(result.type, DioExceptionType.connectionError);
      expect(result.error, 'Connection error');
      expect(result.message, 'Failed to connect to server');
    });
  });
}
