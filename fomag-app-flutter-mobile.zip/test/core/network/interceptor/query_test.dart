import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:fomagapp/core/network/interceptor/query.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'dart:async';
import 'package:fomagapp/core/network/util/const.dart';

@GenerateMocks([Connectivity, Dio])
import 'query_test.mocks.dart';

class _TestErrorInterceptorHandler extends ErrorInterceptorHandler {
  final void Function(DioException) onNext;

  _TestErrorInterceptorHandler({required this.onNext});

  @override
  void next(DioException err) {
    onNext(err);
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late QueryInterceptor interceptor;
  late MockDio mockDio;
  late MockConnectivity mockConnectivity;

  setUp(() {
    mockDio = MockDio();
    mockConnectivity = MockConnectivity();
    interceptor = QueryInterceptor(
      dio: mockDio,
      identityBaseDomain: 'test.com',
      connectivity: mockConnectivity,
    );
  });

  group('QueryInterceptor - onRequest', () {
    test('should add mobile client type header', () async {
      final options = RequestOptions();
      final handler = RequestInterceptorHandler();

      when(
        mockConnectivity.checkConnectivity(),
      ).thenAnswer((_) async => [ConnectivityResult.wifi]);

      await interceptor.onRequest(options, handler);
      expect(options.headers['Client-Type'], 'mobile');
    });

    test('should handle ignoreConnection flag', () async {
      final interceptor = QueryInterceptor(
        dio: mockDio,
        identityBaseDomain: 'test.com',
        connectivity: mockConnectivity,
        ignoreConnection: true,
      );

      final options = RequestOptions();
      final handler = RequestInterceptorHandler();

      await interceptor.onRequest(options, handler);
      verifyNever(mockConnectivity.checkConnectivity());
    });
  });

  group('QueryInterceptor - onResponse', () {
    test('should throw error for unauthorized response', () async {
      final response = Response(
        requestOptions: RequestOptions(),
        statusCode: 401,
      );
      final handler = ResponseInterceptorHandler();

      expect(
        () => interceptor.onResponse(response, handler),
        throwsA(isA<DioException>()),
      );
    });

    test(
      'should throw error for invalid json response when expected',
      () async {
        final interceptor = QueryInterceptor(
          dio: mockDio,
          identityBaseDomain: 'test.com',
          expectResponseJson: true,
          connectivity: mockConnectivity,
        );

        final response = Response(
          requestOptions: RequestOptions(),
          statusCode: 200,
          data: 'not json',
        );
        final handler = ResponseInterceptorHandler();

        expect(
          () => interceptor.onResponse(response, handler),
          throwsA(isA<DioException>()),
        );
      },
    );

    test('should handle no content response correctly', () async {
      final response = Response(
        requestOptions: RequestOptions(),
        statusCode: 204,
      );
      final handler = ResponseInterceptorHandler();

      await interceptor.onResponse(response, handler);
      expect(handler.isCompleted, true);
    });

    test('should handle valid json response', () async {
      final response = Response(
        requestOptions: RequestOptions(),
        statusCode: 200,
        data: {'key': 'value'},
        headers: Headers.fromMap({
          'content-type': ['application/json'],
        }),
      );
      final handler = ResponseInterceptorHandler();

      await interceptor.onResponse(response, handler);
      expect(handler.isCompleted, true);
    });
  });

  group('QueryInterceptor - onError', () {
    test('should handle unauthorized error with token refresh', () async {
      final error = DioException(
        requestOptions: RequestOptions(),
        response: Response(requestOptions: RequestOptions(), statusCode: 401),
      );
      final handler = ErrorInterceptorHandler();

      final newResponse = Response(
        requestOptions: RequestOptions(),
        statusCode: 200,
      );

      when(mockDio.fetch(any)).thenAnswer((_) async => newResponse);

      await interceptor.onError(error, handler);
      expect(handler.isCompleted, true);
    });

    test('should handle form data in error retry', () async {
      final formData = FormData.fromMap({'key': 'value'});
      final error = DioException(
        requestOptions: RequestOptions(data: formData),
        response: Response(requestOptions: RequestOptions(), statusCode: 401),
      );
      final handler = ErrorInterceptorHandler();

      final newResponse = Response(
        requestOptions: RequestOptions(),
        statusCode: 200,
      );

      when(mockDio.fetch(any)).thenAnswer((_) async => newResponse);

      await interceptor.onError(error, handler);
      expect(handler.isCompleted, true);
    });

    test('should handle error with ignoreToken flag', () async {
      final interceptor = QueryInterceptor(
        dio: mockDio,
        identityBaseDomain: 'test.com',
        connectivity: mockConnectivity,
        ignoreToken: true,
      );

      final error = DioException(
        requestOptions: RequestOptions(),
        response: Response(requestOptions: RequestOptions(), statusCode: 401),
        type: DioExceptionType.badResponse,
      );
      final completer = Completer<DioException>();
      final handler = _TestErrorInterceptorHandler(onNext: completer.complete);
      await interceptor.onError(error, handler);
      final result = await completer.future;

      expect(result.type, DioExceptionType.badResponse);
      expect(result.message, Const.defaultMessageErrorServer);
    });

    test('should handle server error', () async {
      final error = DioException(
        requestOptions: RequestOptions(),
        response: Response(
          requestOptions: RequestOptions(),
          statusCode: 500,
          data: {
            "message":
                "Se presentó un error en el servicio. Por favor, intente más tarde.",
          },
        ),
      );
      final completer = Completer<DioException>();
      final handler = _TestErrorInterceptorHandler(onNext: completer.complete);
      await interceptor.onError(error, handler);
      final result = await completer.future;

      expect(result.type, DioExceptionType.connectionError);
      expect(result.message, Const.defaultMessageErrorServer);
    });
  });

  group('QueryInterceptor - Helper Methods', () {
    test('isResponseOkButNoContent should return true for 204', () {
      final response = Response(
        requestOptions: RequestOptions(),
        statusCode: 204,
      );
      expect(interceptor.isResponseOkButNoContent(response), true);
    });

    test(
      'isResponseHeaderTypeJson should return true for json content type',
      () {
        final headers = {
          'content-type': ['application/json'],
        };
        expect(interceptor.isResponseHeaderTypeJson(headers), true);
      },
    );

    test(
      'isResponseHeaderTypeJson should return false for non-json content type',
      () {
        final headers = <String, List<String>>{
          'content-type': ['text/plain'],
        };
        expect(interceptor.isResponseHeaderTypeJson(headers), false);
      },
    );

    test(
      'isResponseHeaderTypeJson should return null for missing content type',
      () {
        final headers = <String, List<String>>{};
        expect(interceptor.isResponseHeaderTypeJson(headers), null);
      },
    );
  });
}
