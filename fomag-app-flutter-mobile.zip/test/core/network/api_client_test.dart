import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/model/response/generic/generic_response.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/request/otp_code_password/otp_code_password_request.dart';
import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

// Generar mocks para Dio
@GenerateMocks([Dio])
import 'api_client_test.mocks.dart';

void main() {
  late ApiClient apiClient;
  late MockDio mockDio;

  const baseUrl = 'https://test-api.example.com';

  setUp(() {
    mockDio = MockDio();
    apiClient = ApiClient(mockDio, baseUrl: baseUrl);
    when(mockDio.options).thenReturn(BaseOptions());
  });

  group('ApiClient - Login', () {
    final loginRequest = LoginRequest(
      documentType: '3',
      documentNumber: '1030596883',
      password: 'Periferia2025*',
    );

    test('should make successful login request', () async {
      // Preparar respuesta mock
      final authResponse = GenericResponse(
        message: 'ok',
        data: AuthResponse(
          challenge: Challenge.mfaRequired,
          session:
              'AYABeAbAgcuxpM1W7ugqEOG0fogAHQABAAdTZXJ2aWNlABBDb2duaXRvVXNlclBvb2xzAAEAB2F3cy1rbXMAS2Fybjphd3M6a21zOnVzLWVhc3QtMTo3NDU2MjM0Njc1NTU6a2V5L2IxNTVhZmNhLWJmMjktNGVlZC1hZmQ4LWE5ZTA5MzY1M2RiZQC4AQIBAHhR9E4zNbI1ofi3Y01_Ljgh2wK-ZaC__bKufjbgmejy4gETyCkiX3By-b6jOwajVqx4AAAAfjB8BgkqhkiG9w0BBwagbzBtAgEAMGgGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMuln9SHi_r9VnXyIKAgEQgDsL5aYayOCkJ2qulJuRIPvc2svtWyoRyEOgD9NJeIiWp2fXC6hv_t7OLF2VM051z2XlYOzl6q0ALqKocgIAAAAADAAAEAAAAAAAAAAAAAAAAABOe9m-YVOCXdD6RNTBrDk0_____wAAAAEAAAAAAAAAAAAAAAEAAALGM9OUQo8BHqdj4iy6rZnlZ0hoXO3fVSOrSfcpf9Ze1zJf7E0zFkPuJpqydtuQt7XsbE9n5bdMeW2_dTabz3sfyJZYL9fpBaO6hIkC2IIEavEbk0uzxxhFrGHVwDVnXz7oVqXqBMgjpPAE0v5U0Nh5Ry5WjPoyuWwGetH3Vza8DLjewnxWzBzzibERqUja1Ww5pWX3YiVAs96cTgOQ1zQJIjQXOQREmBLuoyBieKQXyA5Q3x9jiw6r9cOKPcFMJF9blb3J2uYi9khWFvwH3t3URvqEPvYTabIklFYmXkMs1X2grTW4a87dQ17qPkOzDnXGc_rym85vFVQfAJ3GQP38p9W8ITw-9QR27l80tNZjrGNDXLTPKUN56XrhSb2FIKB865zIIfVsm6tx7FUnqUwZO2Ib9r4enyN-DgIkQOU_V4BHctzVdjyXar0jvQqAWrXqHPHC60A0n0yNN2vSVVdNFgORLHsAdYdjYPI5LHxDcEbqS5JuKgmI1-TK_0_m25ohG8jsQwqEhhyMYNGweMrmlbz64G_yDLA0VRJETp7VhWesZynnmdLYv2R5PidI7SlyLLzbpsaNOPX-1UkwIl2keE4JWUW2l2ndDkZyI3Y8KtQhw6x_mDvPYQZHPvDaHatahJb9jSHEW3vy-whLKTdoCDCeV4-FfsBG9-1HumlFPkq9BKK48MXU-oy7y_UCKUhrgPEWrtDKpr4vampoceSiEKQt7q0jKDAMx2yc3ZBjGhTfHWGs3acsYO7T5BLEfuowy6Dr6sY9f-QsMwWv6hAgItEIDsU3GCaN-ltTPug7eO9fUw9ucBd5bXtSvPiFEpvcoZp35t47bVT7tlqQLx-yadCzP1IxiIWmFIvnNwFJHvAQnJTO0T28TN4n8yOwDi0mgxifDw0hdN1wPzgB0zGetCDovpSDN0QJd9GR5CX3Cx2oIWIX7sfJMlICsNvFe-OdgN_PfDrD',
          challengeName: 'EMAIL_OTP',
          userName: 'test@example.com',
        ),
      );

      final httpResponse = Response(
        data: authResponse.toJson(authResponse.data!.toJson),
        statusCode: 200,
        requestOptions: RequestOptions(path: '/authenticate'),
      );

      // Configurar el mock para devolver la respuesta adecuada
      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      // Ejecutar la llamada al API
      final response = await apiClient.login(loginRequest);

      // Verificar resultado
      expect(response.response.statusCode, 200);
      expect(response.data.data!.challenge, 'MFA_REQUIRED');
      expect(response.data.data!.challengeName, 'EMAIL_OTP');
      expect(response.data.data!.userName, 'test@example.com');
      expect(response.data.data!.session, isNotEmpty);
    });

    test('should handle login error', () async {
      // Configurar el mock para lanzar error
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/authenticate'),
          response: Response(
            statusCode: 401,
            data: {'message': 'Invalid credentials'},
            requestOptions: RequestOptions(path: '/authenticate'),
          ),
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(() => apiClient.login(loginRequest), throwsA(isA<DioException>()));
    });

    test('should handle network error during login', () async {
      // Configurar error de red
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/authenticate'),
          type: DioExceptionType.connectionError,
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(() => apiClient.login(loginRequest), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - Register', () {
    final registerRequest = RegisterRequest(
      documentType: '3',
      documentNumber: '123456789',
      fullName: 'user test',
      email: 'test@example.com',
      mobile: '3001234567',
      password: 'password123*',
      acceptanceTerms: true,
    );

    test('should make successful register request', () async {
      // Preparar respuesta mock
      final accountResponse = RegisterResponse();

      final httpResponse = Response(
        data: {'message': accountResponse.message},
        statusCode: 201,
        requestOptions: RequestOptions(path: '/mobile/auth/register'),
      );

      // Configurar el mock para devolver la respuesta adecuada
      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      // Ejecutar la llamada al API
      final response = await apiClient.register(registerRequest);

      // Verificar resultado
      expect(response.response.statusCode, 201);
    });

    test('should handle register error', () async {
      // Configurar el mock para lanzar error
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: 'mobile/auth/register'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Usuario ya existe'},
            requestOptions: RequestOptions(path: 'mobile/auth/register'),
          ),
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(
        () => apiClient.register(registerRequest),
        throwsA(isA<DioException>()),
      );
    });

    test('should handle network error during register', () async {
      // Configurar error de red
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: 'mobile/auth/register'),
          type: DioExceptionType.connectionError,
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(
        () => apiClient.register(registerRequest),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - OTP Validate', () {
    final otpRequest = OtpValidateRequest(
      userName: 'test@example.com',
      code: '123456',
      session: 'session_id',
      challengeType: 'challenge_type',
    );

    test('should make successful OTP validation request', () async {
      // Preparar respuesta mock
      final authResponse = GenericOtpResponse(
        message: OtpValidateResponse(
          accessToken: 'access_token',
          idToken: 'id_token',
          refreshToken: 'refresh_token',
        ),
      );

      final httpResponse = Response(
        data: authResponse.toJson(authResponse.message.toJson),
        statusCode: 200,
        requestOptions: RequestOptions(path: '/otp/validate'),
      );

      // Configurar el mock para devolver la respuesta adecuada
      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      // Ejecutar la llamada al API
      final response = await apiClient.otpValidate(otpRequest);
      final responseData = response.data.message;

      // Verificar resultado
      expect(response.response.statusCode, 200);
      expect(responseData.accessToken, 'access_token');
      expect(responseData.idToken, 'id_token');
      expect(responseData.refreshToken, 'refresh_token');
    });

    test('should handle invalid OTP error', () async {
      // Configurar el mock para lanzar error
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/otp/validate'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid OTP code'},
            requestOptions: RequestOptions(path: '/otp/validate'),
          ),
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(
        () => apiClient.otpValidate(otpRequest),
        throwsA(isA<DioException>()),
      );
    });

    test('should handle network error during OTP validation', () async {
      // Configurar error de red
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/otp/validate'),
          type: DioExceptionType.connectionError,
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(
        () => apiClient.otpValidate(otpRequest),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Logout', () {
    final logoutRequest = LogoutRequest(accessToken: 'access_token');

    test('should make successful logout request', () async {
      // Preparar respuesta mock
      final httpResponse = Response<Map<String, dynamic>>(
        data: {},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/auth/logout'),
      );

      // Configurar el mock para devolver la respuesta adecuada
      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      // Ejecutar la llamada al API
      final response = await apiClient.logout(logoutRequest);

      // Verificar resultado
      expect(response.response.statusCode, 200);
    });

    test('should handle logout error', () async {
      // Configurar el mock para lanzar error
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/auth/logout'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Logout error'},
            requestOptions: RequestOptions(path: '/mobile/auth/logout'),
          ),
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(
        () => apiClient.logout(logoutRequest),
        throwsA(isA<DioException>()),
      );
    });

    test('should handle network error during logout', () async {
      // Configurar error de red
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/auth/logout'),
          type: DioExceptionType.connectionError,
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(
        () => apiClient.logout(logoutRequest),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Get Departments', () {
    test('should make successful getDepartments request', () async {
      // Preparar datos de ejemplo
      final departments = [
        DepartmentsHealthCenterResponse(id: 1, name: 'Departamento 1'),
      ];
      final genericResponse =
          GenericResponse<List<DepartmentsHealthCenterResponse>>(
            message: 'ok',
            data: departments,
          );

      final httpResponse = Response<Map<String, dynamic>>(
        data: genericResponse.toJson(
          (list) => list.map((e) => e.toJson()).toList(),
        ),
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/departments'),
      );

      // Configurar el mock para devolver la respuesta adecuada
      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      // Ejecutar la llamada al API
      final response = await apiClient.getDepartments();

      // Verificar resultado
      expect(response.response.statusCode, 200);
      expect(response.data.data, isA<List<DepartmentsHealthCenterResponse>>());
      expect(response.data.message, 'ok');
    });

    test('should handle getDepartments error', () async {
      // Configurar el mock para lanzar error
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/departments'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Error'},
            requestOptions: RequestOptions(path: '/mobile/departments'),
          ),
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(() => apiClient.getDepartments(), throwsA(isA<DioException>()));
    });

    test('should handle network error during getDepartments', () async {
      // Configurar error de red
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/departments'),
          type: DioExceptionType.connectionError,
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(() => apiClient.getDepartments(), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - Get Cities', () {
    test('should make successful getCities request', () async {
      // Preparar datos de ejemplo
      final cities = [CitiesResponse(id: 1, name: 'Ciudad 1', departmentId: 2)];
      final genericResponse = GenericResponse<List<CitiesResponse>>(
        message: 'ok',
        data: cities,
      );

      final httpResponse = Response<Map<String, dynamic>>(
        data: genericResponse.toJson(
          (list) => list.map((e) => e.toJson()).toList(),
        ),
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/cities'),
      );

      // Configurar el mock para devolver la respuesta adecuada
      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      // Ejecutar la llamada al API
      final response = await apiClient.getCities(1);

      // Verificar resultado
      expect(response.response.statusCode, 200);
      expect(response.data.data, isA<List<CitiesResponse>>());
      expect(response.data.message, 'ok');
    });

    test('should handle getCities error', () async {
      // Configurar el mock para lanzar error
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/cities'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Error'},
            requestOptions: RequestOptions(path: '/mobile/cities'),
          ),
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(() => apiClient.getCities(1), throwsA(isA<DioException>()));
    });

    test('should handle network error during getCities', () async {
      // Configurar error de red
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/cities'),
          type: DioExceptionType.connectionError,
        ),
      );

      // Ejecutar y verificar que se lanza una excepción
      expect(() => apiClient.getCities(1), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - Get News By ID', () {
    test('should make successful getNewById request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'uuid': 1, 'title': 'Test News'},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/news'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getNewById(1);

      expect(response.response.statusCode, 200);
    });

    test('should handle getNewById error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/news'),
          response: Response(
            statusCode: 404,
            data: {'message': 'News not found'},
            requestOptions: RequestOptions(path: '/mobile/news'),
          ),
        ),
      );

      expect(() => apiClient.getNewById(1), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - Get News', () {
    test('should make successful getNews request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'news': []},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/news'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getNews();

      expect(response.response.statusCode, 200);
    });

    test('should handle getNews error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/news'),
          response: Response(
            statusCode: 500,
            data: {'message': 'Server error'},
            requestOptions: RequestOptions(path: '/mobile/news'),
          ),
        ),
      );

      expect(() => apiClient.getNews(), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - OTP Code Password', () {
    test('should make successful otpCodePassword request', () async {
      final authResponse = AuthResponse(
        challenge: Challenge.mfaRequired,
        session: 'session_id',
        challengeName: 'EMAIL_OTP',
        userName: 'test@example.com',
      );

      final httpResponse = Response<Map<String, dynamic>>(
        data: authResponse.toJson(authResponse),
        statusCode: 200,
        requestOptions: RequestOptions(path: '/otp/sendCode'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.otpCodePassword(
        OtpCodePasswordRequest(code: 123456),
      );

      expect(response.response.statusCode, 200);
      expect(response.data.challenge, 'MFA_REQUIRED');
      expect(response.data.challengeName, 'EMAIL_OTP');
    });

    test('should handle otpCodePassword error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/otp/sendCode'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid request'},
            requestOptions: RequestOptions(path: '/otp/sendCode'),
          ),
        ),
      );

      expect(
        () => apiClient.otpCodePassword(OtpCodePasswordRequest(code: 123456)),
        throwsA(isA<DioException>()),
      );
    });

    test('should handle network error during otpCodePassword', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/otp/sendCode'),
          type: DioExceptionType.connectionError,
        ),
      );

      expect(
        () => apiClient.otpCodePassword(OtpCodePasswordRequest(code: 123456)),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Send Email Code', () {
    test('should make successful sendEmailCode request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'message': 'Email sent'},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/auth/forgot-password'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.sendEmailCode(
        EmailCodeRequest(typeDocument: '3', documentNumber: '123456789'),
      );

      expect(response.response.statusCode, 200);
    });

    test('should handle sendEmailCode error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/auth/forgot-password'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid email'},
            requestOptions: RequestOptions(
              path: '/mobile/auth/forgot-password',
            ),
          ),
        ),
      );

      expect(
        () => apiClient.sendEmailCode(
          EmailCodeRequest(typeDocument: '3', documentNumber: 'invalid'),
        ),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Get Certificate Types', () {
    test('should make successful getTypesCertificates request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'types': []},
        statusCode: 200,
        requestOptions: RequestOptions(
          path: '/mobile/certifications/certificates',
        ),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getTypesCertificates();

      expect(response.response.statusCode, 200);
    });

    test('should handle getTypesCertificates error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(
            path: '/mobile/certifications/certificates',
          ),
          response: Response(
            statusCode: 500,
            data: {'message': 'Server error'},
            requestOptions: RequestOptions(
              path: '/mobile/certifications/certificates',
            ),
          ),
        ),
      );

      expect(
        () => apiClient.getTypesCertificates(),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Garnishments List', () {
    test('should make successful garnishmentsList request', () async {
      final garnishments = [
        GarnishmentsCertificateResponse(
          nameCourt: 'Juzgado Test',
          natureProcess: 'Civil',
          officialEmbargo: 'OF-001',
          claimantDocumentNumber: '123456789',
          fullNameClaimant: 'Juan Pérez',
          surnameClaimant: 'García',
          processNumber: 'PROC-001',
          descriptionOfServices: 'Servicios legales',
          consecutiveGarnishment: '001',
          state: 'Activo',
        ),
      ];

      final httpResponse = Response<List<Map<String, dynamic>>>(
        data: garnishments.map((e) => e.toJson()).toList(),
        statusCode: 200,
        requestOptions: RequestOptions(
          path: '/mobile/certifications/embargo-details',
        ),
      );

      when(
        mockDio.fetch<List<Map<String, dynamic>>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.garnishmentsList(
        GarnishmentRequest(documentType: '3', documentNumber: '123456789'),
      );

      expect(response.response.statusCode, 200);
      expect(response.data, isA<List<GarnishmentsCertificateResponse>>());
    });

    test('should handle garnishmentsList error', () async {
      when(mockDio.fetch<List<Map<String, dynamic>>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(
            path: '/mobile/certifications/embargo-details',
          ),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid request'},
            requestOptions: RequestOptions(
              path: '/mobile/certifications/embargo-details',
            ),
          ),
        ),
      );

      expect(
        () => apiClient.garnishmentsList(
          GarnishmentRequest(documentType: '3', documentNumber: 'invalid'),
        ),
        throwsA(isA<DioException>()),
      );
    });

    test('should handle network error during garnishmentsList', () async {
      when(mockDio.fetch<List<Map<String, dynamic>>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(
            path: '/mobile/certifications/embargo-details',
          ),
          type: DioExceptionType.connectionError,
        ),
      );

      expect(
        () => apiClient.garnishmentsList(
          GarnishmentRequest(documentType: '3', documentNumber: '123456789'),
        ),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Confirm Forgot Password', () {
    test('should make successful confirmForgotPassword request', () async {
      final confirmResponse = ConfirmForgotPasswordResponse(
        message: 'Password updated successfully',
      );

      final httpResponse = Response<Map<String, dynamic>>(
        data: confirmResponse.toJson(),
        statusCode: 200,
        requestOptions: RequestOptions(
          path: '/mobile/auth/confirm-forgot-password',
        ),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.confirmForgotPassword(
        ConfirmForgotPasswordRequest(
          documentType: '3',
          documentNumber: '123456789',
          password: 'newPassword123*',
          code: '123456',
        ),
      );

      expect(response.response.statusCode, 200);
      expect(response.data.message, 'Password updated successfully');
    });

    test('should handle confirmForgotPassword error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(
            path: '/mobile/auth/confirm-forgot-password',
          ),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid code'},
            requestOptions: RequestOptions(
              path: '/mobile/auth/confirm-forgot-password',
            ),
          ),
        ),
      );

      expect(
        () => apiClient.confirmForgotPassword(
          ConfirmForgotPasswordRequest(
            documentType: '3',
            documentNumber: '123456789',
            password: 'newPassword123*',
            code: 'invalid',
          ),
        ),
        throwsA(isA<DioException>()),
      );
    });

    test('should handle network error during confirmForgotPassword', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(
            path: '/mobile/auth/confirm-forgot-password',
          ),
          type: DioExceptionType.connectionError,
        ),
      );

      expect(
        () => apiClient.confirmForgotPassword(
          ConfirmForgotPasswordRequest(
            documentType: '3',
            documentNumber: '123456789',
            password: 'newPassword123*',
            code: '123456',
          ),
        ),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Generate Certificate', () {
    test('should make successful generateCertificate request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'certificate': 'data'},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/test/path'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.generateCertificate('test/path', {
        'type': 'test',
      });

      expect(response.response.statusCode, 200);
    });

    test('should handle generateCertificate error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/test/path'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid certificate type'},
            requestOptions: RequestOptions(path: '/test/path'),
          ),
        ),
      );

      expect(
        () => apiClient.generateCertificate('test/path', {}),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Get Health Centers', () {
    test('should make successful getHealthCenters request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'centers': []},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/health-centers'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getHealthCenters(1);

      expect(response.response.statusCode, 200);
    });

    test('should handle getHealthCenters error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/health-centers'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid city ID'},
            requestOptions: RequestOptions(path: '/mobile/health-centers'),
          ),
        ),
      );

      expect(
        () => apiClient.getHealthCenters(999),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Get Terms and Conditions', () {
    test('should make successful getTermsAndConditions request', () async {
      final httpResponse = Response<String>(
        data: 'Terms and conditions content',
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/terms-and-conditions'),
      );

      when(mockDio.fetch<String>(any)).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getTermsAndConditions();

      expect(response.response.statusCode, 200);
      expect(response.data, 'Terms and conditions content');
    });

    test('should handle getTermsAndConditions error', () async {
      when(mockDio.fetch<String>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/terms-and-conditions'),
          response: Response(
            statusCode: 404,
            data: 'Not found',
            requestOptions: RequestOptions(
              path: '/mobile/terms-and-conditions',
            ),
          ),
        ),
      );

      expect(
        () => apiClient.getTermsAndConditions(),
        throwsA(isA<DioException>()),
      );
    });
  });

  group('ApiClient - Get Contact List', () {
    test('should make successful getContactList request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'contacts': []},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/admin/contact-us'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getContactList();

      expect(response.response.statusCode, 200);
    });

    test('should handle getContactList error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/admin/contact-us'),
          response: Response(
            statusCode: 403,
            data: {'message': 'Access denied'},
            requestOptions: RequestOptions(path: '/admin/contact-us'),
          ),
        ),
      );

      expect(() => apiClient.getContactList(), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - Delete Account', () {
    test('should make successful deleteAccount request', () async {
      final httpResponse = Response<Map<String, dynamic>>(
        data: {'message': 'Account deleted'},
        statusCode: 200,
        requestOptions: RequestOptions(path: '/mobile/auth/deleteAccount'),
      );

      when(
        mockDio.fetch<Map<String, dynamic>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.deleteAccount();

      expect(response.response.statusCode, 200);
    });

    test('should handle deleteAccount error', () async {
      when(mockDio.fetch<Map<String, dynamic>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(path: '/mobile/auth/deleteAccount'),
          response: Response(
            statusCode: 400,
            data: {'message': 'Cannot delete account'},
            requestOptions: RequestOptions(path: '/mobile/auth/deleteAccount'),
          ),
        ),
      );

      expect(() => apiClient.deleteAccount(), throwsA(isA<DioException>()));
    });
  });

  group('ApiClient - Get Pay Interest Certificate', () {
    test('should make successful getPayInterestCertificate request', () async {
      final httpResponse = Response<List<String>>(
        data: ['certificate1', 'certificate2'],
        statusCode: 200,
        requestOptions: RequestOptions(
          path: '/mobile/certifications/severance-pay-interest',
        ),
      );

      when(
        mockDio.fetch<List<String>>(any),
      ).thenAnswer((_) async => httpResponse);

      final response = await apiClient.getPayInterestCertificate(
        PayInterestCertificateRequest(
          documentNumber: '123456789',
          vinculacionType: 'test',
        ),
      );

      expect(response.response.statusCode, 200);
      expect(response.data, isA<List<String>>());
      expect(response.data.length, 2);
    });

    test('should handle getPayInterestCertificate error', () async {
      when(mockDio.fetch<List<String>>(any)).thenThrow(
        DioException(
          requestOptions: RequestOptions(
            path: '/mobile/certifications/severance-pay-interest',
          ),
          response: Response(
            statusCode: 400,
            data: {'message': 'Invalid request'},
            requestOptions: RequestOptions(
              path: '/mobile/certifications/severance-pay-interest',
            ),
          ),
        ),
      );

      expect(
        () => apiClient.getPayInterestCertificate(
          PayInterestCertificateRequest(
            documentNumber: 'invalid',
            vinculacionType: 'invalid',
          ),
        ),
        throwsA(isA<DioException>()),
      );
    });

    test(
      'should handle network error during getPayInterestCertificate',
      () async {
        when(mockDio.fetch<List<String>>(any)).thenThrow(
          DioException(
            requestOptions: RequestOptions(
              path: '/mobile/certifications/severance-pay-interest',
            ),
            type: DioExceptionType.connectionError,
          ),
        );

        expect(
          () => apiClient.getPayInterestCertificate(
            PayInterestCertificateRequest(
              documentNumber: '123456789',
              vinculacionType: 'test',
            ),
          ),
          throwsA(isA<DioException>()),
        );
      },
    );
  });
}
