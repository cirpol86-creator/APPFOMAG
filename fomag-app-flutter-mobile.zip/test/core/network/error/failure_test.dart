import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/error/failure.dart';

void main() {
  group('Failure', () {
    test('should create a basic failure with message', () {
      const failure = Failure(message: 'Test error');
      expect(failure.message, 'Test error');
      expect(failure.data, null);
    });

    test('should create a failure with message and data', () {
      const failure = Failure(message: 'Test error', data: {'key': 'value'});
      expect(failure.message, 'Test error');
      expect(failure.data, {'key': 'value'});
    });

    test('should be equal when message is the same', () {
      const failure1 = Failure(message: 'Test error');
      const failure2 = Failure(message: 'Test error');
      expect(failure1, equals(failure2));
    });

    test('should not be equal when message is different', () {
      const failure1 = Failure(message: 'Test error 1');
      const failure2 = Failure(message: 'Test error 2');
      expect(failure1, isNot(equals(failure2)));
    });
  });

  group('ServerFailure', () {
    test('should create a server failure with message', () {
      const failure = ServerFailure(message: 'Server error');
      expect(failure.message, 'Server error');
      expect(failure.data, null);
    });

    test('should create a server failure with message and data', () {
      const failure = ServerFailure<Map<String, int>>(
        message: 'Server error',
        data: {'status': 500},
      );
      expect(failure.message, 'Server error');
      expect(failure.data, {'status': 500});
    });
  });

  group('NoConnectionFailure', () {
    test('should create a no connection failure with default message', () {
      const failure = NoConnectionFailure();
      expect(failure.message, 'No connection!');
      expect(failure.data, null);
    });
  });

  group('NoAuthenticationFailure', () {
    test('should create a no authentication failure with default message', () {
      const failure = NoAuthenticationFailure();
      expect(failure.message, 'Please sign in');
      expect(failure.data, null);
    });
  });

  group('mapFailureToMessage', () {
    test('should return message for ServerFailure', () {
      const failure = ServerFailure(message: 'Server error');
      expect(mapFailureToMessage(failure), 'Server error');
    });

    test('should return message for NoConnectionFailure', () {
      const failure = NoConnectionFailure();
      expect(mapFailureToMessage(failure), 'No connection!');
    });

    test('should return message for NoAuthenticationFailure', () {
      const failure = NoAuthenticationFailure();
      expect(mapFailureToMessage(failure), 'Please sign in');
    });

    test('should return message for basic Failure', () {
      const failure = Failure(message: 'Basic error');
      expect(mapFailureToMessage(failure), 'Basic error');
    });
  });
}
