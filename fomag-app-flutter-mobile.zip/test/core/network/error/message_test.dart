import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/error/message.dart';
import 'package:fomagapp/core/network/util/const.dart';

void main() {
  group('ErrorMessageManager', () {
    test('should return connection error message', () {
      final error = DioException(
        requestOptions: RequestOptions(),
        type: DioExceptionType.connectionError,
      );
      expect(
        ErrorMessageManager.getErrorMessage(error),
        'Se ha presentado un error con la conexión, por favor vuelva a intentarlo más tarde.',
      );
    });

    test('should return timeout error message', () {
      final error = DioException(
        requestOptions: RequestOptions(),
        type: DioExceptionType.receiveTimeout,
      );
      expect(
        ErrorMessageManager.getErrorMessage(error),
        'Tiempo de espera de respuesta excedido.',
      );
    });

    test('should return message from response data when available', () {
      final error = DioException(
        requestOptions: RequestOptions(),
        response: Response(
          requestOptions: RequestOptions(),
          data: {'message': Const.defaultMessageErrorServer},
        ),
      );
      expect(
        ErrorMessageManager.getErrorMessage(error),
        Const.defaultMessageErrorServer,
      );
    });

    test('should return default error message for unknown error types', () {
      final error = DioException(
        requestOptions: RequestOptions(),
        type: DioExceptionType.badResponse,
      );
      expect(
        ErrorMessageManager.getErrorMessage(error),
        Const.defaultMessageErrorServer,
      );
    });

    test(
      'should return default error message when response data is not a map',
      () {
        final error = DioException(
          requestOptions: RequestOptions(),
          response: Response(
            requestOptions: RequestOptions(),
            data: 'Not a map',
          ),
        );
        expect(
          ErrorMessageManager.getErrorMessage(error),
          Const.defaultMessageErrorServer,
        );
      },
    );

    test(
      'should return default error message when response data map has no message',
      () {
        final error = DioException(
          requestOptions: RequestOptions(),
          response: Response(
            requestOptions: RequestOptions(),
            data: {'otherKey': 'value'},
          ),
        );
        expect(
          ErrorMessageManager.getErrorMessage(error),
          Const.defaultMessageErrorServer,
        );
      },
    );
  });
}
