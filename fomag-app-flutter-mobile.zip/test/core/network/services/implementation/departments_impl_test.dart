import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:fomagapp/core/network/services/implementation/departments_impl.dart';
import 'package:fomagapp/data/model/response/departments_health_center/departments_health_center_respnse.dart';
import 'package:fomagapp/data/model/response/generic/generic_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late DepartmentsImpl departmentsService;

  setUp(() {
    mockApiClient = MockApiClient();
    departmentsService = DepartmentsImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar lista de DepartmentsHealthCenterResponse correctamente',
    () async {
      final mockResponse = [
        DepartmentsHealthCenterResponse(id: 1, name: 'Antioquia'),
        DepartmentsHealthCenterResponse(id: 2, name: 'Cundinamarca'),
      ];

      final genericResponse =
          GenericResponse<List<DepartmentsHealthCenterResponse>>(
            content: mockResponse,
          );

      final httpResponse =
          HttpResponse<GenericResponse<List<DepartmentsHealthCenterResponse>>>(
            genericResponse,
            Response(
              data: {'content': mockResponse.map((e) => e.toJson()).toList()},
              requestOptions: RequestOptions(path: ''),
              statusCode: 200,
            ),
          );

      when(
        mockApiClient.getDepartments(),
      ).thenAnswer((_) async => httpResponse);

      final result = await departmentsService.call();

      expect(result.length, 2);
      expect(result.first.name, 'Antioquia');
    },
  );
}
