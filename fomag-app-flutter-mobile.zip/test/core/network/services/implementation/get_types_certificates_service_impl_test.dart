import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:fomagapp/core/network/services/implementation/get_types_certificates_service_impl.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type_response.dart';
import 'package:fomagapp/data/model/response/certificate_types/certificate_type.dart';
import 'package:fomagapp/data/model/response/certificates/certificate_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late GetTypesCertificatesServiceImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = GetTypesCertificatesServiceImpl(apiClient: mockApiClient);
  });

  group('GetTypesCertificatesServiceImpl', () {
    test(
      'debe retornar CertificateTypeResponse al obtener tipos de certificado',
      () async {
        // Arrange
        final types = [
          const CertificateType(
            id: 6,
            name: 'Certificado de salud',
            path: '/salud',
            state: 'ACTIVO',
          ),
          const CertificateType(
            id: 12,
            name: 'Embargo',
            path: '/embargo',
            state: 'ACTIVO',
          ),
        ];

        final responseModel = CertificateTypeResponse(
          httpCode: 200,
          message: 'Tipos cargados',
          content: types,
        );

        final httpResponse = HttpResponse<CertificateTypeResponse>(
          responseModel,
          Response(
            data: responseModel.toJson(),
            statusCode: 200,
            requestOptions: RequestOptions(path: ''),
          ),
        );

        when(
          mockApiClient.getTypesCertificates(),
        ).thenAnswer((_) async => httpResponse);

        final result = await service.call();

        expect(result.httpCode, 200);
        expect(result.content.length, 2);
        expect(result.content.first.name, 'Certificado de salud');
        expect(result.content.first.isHealthCertificate, isTrue);
        expect(result.content.last.isGarnishment, isTrue);
      },
    );

    test('debe retornar CertificateResponse al generar certificado', () async {
      const path = '/certificados/generar';
      final entries = {'documentType': '1', 'documentNumber': '123456789'};

      final certResponse = CertificateResponse(
        true,
        'https://example.com/cert.pdf',
      );

      final httpResponse = HttpResponse<CertificateResponse>(
        certResponse,
        Response(
          data: certResponse.toJson(),
          statusCode: 200,
          requestOptions: RequestOptions(path: ''),
        ),
      );

      when(
        mockApiClient.generateCertificate(path, entries),
      ).thenAnswer((_) async => httpResponse);

      final result = await service.generateCertificate(path, entries);

      expect(result.url, isNotNull);
      expect(result.url, contains('cert.pdf'));
      expect(result.isSuccess, isTrue);
    });
  });
}
