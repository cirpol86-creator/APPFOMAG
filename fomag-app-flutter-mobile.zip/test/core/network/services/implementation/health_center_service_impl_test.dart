import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart';
import 'package:fomagapp/core/network/services/implementation/health_center_impl.dart';
import 'package:fomagapp/data/model/response/generic/generic_response.dart';
import 'package:retrofit/retrofit.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/data/model/response/health_center/health_center_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late HealthCenterImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = HealthCenterImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar lista de centros de salud para un id de departamento',
    () async {
      // Arrange
      const requestId = 1;

      final response = GenericResponse<List<HealthCenterResponse>>(
        message: 'OK',
        content: [
          HealthCenterResponse(
            id: 1,
            name: 'Centro de salud',
            address: 'Cra 1 # 2-3',
            phone1: '1234567',
            phone2: '7654321',
          ),
        ],
      );

      final httpResponse = HttpResponse(
        response,
        Response(requestOptions: RequestOptions(path: '')),
      );

      when(
        mockApiClient.getHealthCenters(requestId),
      ).thenAnswer((_) async => httpResponse);

      // Act
      final result = await service.call(requestId);

      // Assert
      expect(result, isA<List<HealthCenterResponse>>());
      expect(result.first.name, 'Centro Médico Norte');
      expect(result.first.phone2, '6018888888');
      verify(mockApiClient.getHealthCenters(requestId)).called(1);
    },
  );
}
