import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/garnishments_list_service_impl.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:fomagapp/data/model/request/garnisment/garnishment_request.dart';
import 'package:fomagapp/data/model/response/garnishments_certificate/garnishments_certificate_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late GarnishmentsListImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = GarnishmentsListImpl(apiClient: mockApiClient);
  });

  test('debe retornar una lista de GarnishmentsCertificateResponse', () async {
    // Arrange
    final request = GarnishmentRequest(
      documentNumber: '123456789',
      documentType: '1',
    );

    final responseList = [
      GarnishmentsCertificateResponse(
        nameCourt: 'Juzgado Civil',
        natureProcess: 'Ordinario',
        officialEmbargo: 'Oficio #123',
        claimantDocumentNumber: '987654321',
        fullNameClaimant: 'Juan Pérez',
        surnameClaimant: 'Pérez',
        processNumber: 'PROC001',
        descriptionOfServices: 'Demanda por alimentos',
        consecutiveGarnishment: '001',
        state: 'Activo',
      ),
    ];

    final httpResponse = HttpResponse<List<GarnishmentsCertificateResponse>>(
      responseList,
      Response(
        data: responseList.map((e) => e.toJson()).toList(),
        statusCode: 200,
        requestOptions: RequestOptions(path: ''),
      ),
    );

    when(
      mockApiClient.garnishmentsList(request),
    ).thenAnswer((_) async => httpResponse);

    // Act
    final result = await service.call(request);

    // Assert
    expect(result, isA<List<GarnishmentsCertificateResponse>>());
    expect(result.length, 1);
    expect(result.first.nameCourt, 'Juzgado Civil');
  });
}
