import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/terms_conditions_service_impl.dart';
import 'package:mockito/mockito.dart';
import 'package:retrofit/dio.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late TermsConditionsServiceImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = TermsConditionsServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar la descripción de los términos y condiciones desde la respuesta JSON',
    () async {
      const expectedDescription = 'Estos son los términos y condiciones.';
      final mockJson = jsonEncode({
        'content': {'descripcion': expectedDescription},
      });

      final httpResponse = HttpResponse(
        mockJson,
        Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
      );

      when(
        mockApiClient.getTermsAndConditions(),
      ).thenAnswer((_) async => httpResponse);

      final result = await service.fetchTermsAndConditions();

      expect(result, equals(expectedDescription));
    },
  );

  test(
    'debe retornar una cadena vacía si no hay descripción en el contenido',
    () async {
      final mockJson = jsonEncode({'content': {}});

      final httpResponse = HttpResponse(
        mockJson,
        Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
      );

      when(
        mockApiClient.getTermsAndConditions(),
      ).thenAnswer((_) async => httpResponse);

      final result = await service.fetchTermsAndConditions();

      expect(result, isEmpty);
    },
  );
}
