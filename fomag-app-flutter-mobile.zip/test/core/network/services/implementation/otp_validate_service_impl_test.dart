import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/otp_validate_service_impl.dart';
import 'package:fomagapp/core/network/services/abstract/otp_validate_service.dart';
import 'package:fomagapp/data/model/request/otp_vaidate/otp_validate_request.dart';
import 'package:fomagapp/data/model/response/otp_validate/otp_validate_response.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late OtpValidateService otpValidateService;

  setUp(() {
    mockApiClient = MockApiClient();
    otpValidateService = OtpValidateServiceImpl(apiClient: mockApiClient);
  });
  test(
    'debe retornar OtpValidateResponse cuando la validación del OTP es exitosa',
    () async {
      final otpValidateRequest = OtpValidateRequest(
        // Completa los campos requeridos según tu modelo
        userName: '',
        code: '',
        session: '',
        challengeType: '',
      );

      final otpValidateResponse = OtpValidateResponse(
        // Completa los campos requeridos según tu modelo
        accessToken: '2221212',
        idToken: '',
        refreshToken: '',
      );

      final genericResponse = GenericOtpResponse<OtpValidateResponse>(
        message: otpValidateResponse,
      );

      final httpResponse =
          HttpResponse<GenericOtpResponse<OtpValidateResponse>>(
            genericResponse,
            Response(
              data: otpValidateResponse, // puede ser cualquier mapa válido
              requestOptions: RequestOptions(path: ''),
              statusCode: 200,
            ),
          );

      when(
        mockApiClient.otpValidate(otpValidateRequest),
      ).thenAnswer((_) async => httpResponse);

      final result = await otpValidateService.call(otpValidateRequest);
      expect(result.accessToken, '2221212');
    },
  );

  test('debe lanzar una excepción cuando el registro falla', () async {
    final otpValidateRequest = OtpValidateRequest(
      // Completa los campos requeridos según tu modelo
      userName: '',
      code: '',
      session: '',
      challengeType: '',
    );

    when(mockApiClient.otpValidate(otpValidateRequest)).thenThrow(
      DioError(requestOptions: RequestOptions(path: ''), error: 'Error'),
    );

    expect(
      () async => await otpValidateService.call(otpValidateRequest),
      throwsA(isA<DioError>()),
    );
  });
}
