import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/news_service_impl.dart';
import 'package:fomagapp/data/model/response/news/news_response.dart';
import 'package:mockito/mockito.dart';
import 'package:retrofit/dio.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late NewsServiceImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = NewsServiceImpl(apiClient: mockApiClient);
  });

  test('debe retornar NewsResponse con lista de noticias', () async {
    final newsResponse = NewsResponse(
      httpCode: 200,
      message: 'Noticias encontradas',
      content: [
        NewsContent(
          id: 1,
          title: 'Noticia 1',
          imageBanner: 'https://example.com/banner1.png',
          idReference: 123,
          body: 'Contenido de la noticia 1',
          date: '2025-07-07',
        ),
        NewsContent(
          id: 2,
          title: 'Noticia 2',
          imageBanner: 'https://example.com/banner2.png',
          idReference: 456,
          body: 'Contenido de la noticia 2',
          date: '2025-07-06',
        ),
      ],
    );

    final httpResponse = HttpResponse(
      newsResponse,
      Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
    );

    when(mockApiClient.getNews()).thenAnswer((_) async => httpResponse);

    final result = await service.call();

    expect(result.httpCode, equals(200));
    expect(result.message, equals('Noticias encontradas'));
    expect(result.content.length, equals(2));
    expect(result.content[0].title, equals('Noticia 1'));
  });
}
