import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/register_service_impl.dart';
import 'package:fomagapp/data/model/request/register/register_request.dart';
import 'package:fomagapp/data/model/response/register/register_response.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late RegisterServiceImpl registerService;

  setUp(() {
    mockApiClient = MockApiClient();
    registerService = RegisterServiceImpl(apiClient: mockApiClient);
  });
  test(
    'debe retornar RegisterResponse cuando el registro es exitoso',
    () async {
      final registerRequest = RegisterRequest(
        // Completa los campos requeridos según tu modelo
        documentType: '1',
        documentNumber: '123456',
        password: 'password',
        email: 'test@email.com',
        // agrega otros campos si es necesario
      );

      final registerResponse = RegisterResponse(
        // Completa los campos requeridos según tu modelo
        message: 'Registro exitoso',
        // agrega otros campos si es necesario
      );

      final httpResponse = HttpResponse<RegisterResponse>(
        registerResponse,
        Response(
          data: registerResponse, // puede ser cualquier mapa válido
          requestOptions: RequestOptions(path: ''),
          statusCode: 200,
        ),
      );

      when(
        mockApiClient.register(registerRequest),
      ).thenAnswer((_) async => httpResponse);

      final result = await registerService.call(registerRequest);
      expect(result.message, 'Registro exitoso');
    },
  );

  test('debe lanzar una excepción cuando el registro falla', () async {
    final registerRequest = RegisterRequest(
      documentType: '1',
      documentNumber: '123456',
      password: 'password',
      email: 'test@email.com',
    );

    when(mockApiClient.register(registerRequest)).thenThrow(
      DioError(
        requestOptions: RequestOptions(path: ''),
        error: 'Error de registro',
      ),
    );

    expect(
      () async => await registerService.call(registerRequest),
      throwsA(isA<DioError>()),
    );
  });
}
