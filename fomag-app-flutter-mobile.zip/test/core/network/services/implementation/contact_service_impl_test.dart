import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/contact_services_impl.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:fomagapp/data/model/response/contact/contact_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late ContactServiceImpl contactService;

  setUp(() {
    mockApiClient = MockApiClient();
    contactService = ContactServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar una lista de ContentResponse cuando getContacts es exitoso',
    () async {
      final contactList = [
        ContentResponse(
          id: 1,
          nombreCentroAtencion: 'Centro 1',
          ciudad: 'Bogotá',
          direccion: 'Calle 123',
          telefonoContacto: '123456789',
          horarioAtencionPublico: 'Lunes a Viernes',
          latitud: 4.6097100,
          longitud: -74.0817500,
          estado: 1,
        ),
      ];

      final contactResponse = ContactResponse(
        code: 200,
        message: 'Éxito',
        content: contactList,
      );

      final httpResponse = HttpResponse<ContactResponse>(
        contactResponse,
        Response(
          data: contactResponse,
          requestOptions: RequestOptions(path: ''),
          statusCode: 200,
        ),
      );

      when(
        mockApiClient.getContactList(),
      ).thenAnswer((_) async => httpResponse);

      final result = await contactService.getContacts();

      expect(result.length, 1);
      expect(result.first.nombreCentroAtencion, 'Centro 1');
      expect(result.first.latitud, 4.60971);
    },
  );
}
