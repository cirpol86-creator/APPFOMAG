import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/login_service_impl.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:fomagapp/data/model/request/login/login_request.dart';
import 'package:fomagapp/data/model/response/auth/auth_response.dart';
import 'package:fomagapp/data/model/response/generic/generic_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late LoginServiceImpl loginService;

  setUp(() {
    mockApiClient = MockApiClient();
    loginService = LoginServiceImpl(apiClient: mockApiClient);
  });

  test('debe retornar AuthResponse cuando login es exitoso', () async {
    final loginRequest = LoginRequest(
      documentType: '3',
      documentNumber: 'test',
      password: '1234',
    );

    final authResponse = AuthResponse(
      userName: 'test',
      challenge: Challenge.mfaRequired,
      session: 'SESSION_ID',
      challengeName: 'CUSTOM_CHALLENGE',
    );

    final genericResponse = GenericResponse<AuthResponse>(data: authResponse);

    final httpResponse = HttpResponse<GenericResponse<AuthResponse>>(
      genericResponse,
      Response(
        data: authResponse, // puede ser cualquier mapa válido
        requestOptions: RequestOptions(path: ''),
        statusCode: 200,
      ),
    );

    when(
      mockApiClient.login(loginRequest),
    ).thenAnswer((_) async => httpResponse);

    final result = await loginService.call(loginRequest);

    expect(result.userName, 'test');
    expect(result.session, 'SESSION_ID');
  });
}
