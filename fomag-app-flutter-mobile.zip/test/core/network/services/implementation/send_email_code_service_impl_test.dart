import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/send_email_code_service_impl.dart';
import 'package:fomagapp/data/model/request/email_code/email_code_request.dart';
import 'package:fomagapp/data/model/response/forgot_password/forgot_password_response.dart';
import 'package:mockito/mockito.dart';
import 'package:retrofit/dio.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late SendEmailCodeServiceImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = SendEmailCodeServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar ForgotPasswordResponse cuando el correo se envía correctamente',
    () async {
      final request = EmailCodeRequest(
        typeDocument: '1',
        documentNumber: '1234567890',
      );

      final expectedResponse = ForgotPasswordResponse(
        message: 'Código enviado correctamente',
      );

      final httpResponse = HttpResponse(
        expectedResponse,
        Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
      );

      when(
        mockApiClient.sendEmailCode(request),
      ).thenAnswer((_) async => httpResponse);

      final result = await service.call(request);

      expect(result, isA<ForgotPasswordResponse>());
      expect(result.message, equals('Código enviado correctamente'));
    },
  );
}
