import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/payment_interest_certificate_service_impl.dart';
import 'package:fomagapp/data/model/request/pay_interest_certificate/pay_interest_certificate_request.dart';
import 'package:mockito/mockito.dart';
import 'package:retrofit/dio.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late PaymentInterestCertificateServiceImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = PaymentInterestCertificateServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar una lista de strings con los certificados de intereses',
    () async {
      final request = PayInterestCertificateRequest(
        documentNumber: '123456789',
        vinculacionType: 'DOCENTE',
      );

      final expectedList = ['Certificado 1', 'Certificado 2'];

      final httpResponse = HttpResponse(
        expectedList,
        Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
      );

      when(
        mockApiClient.getPayInterestCertificate(request),
      ).thenAnswer((_) async => httpResponse);

      final result = await service.call(request);

      expect(result, isA<List<String>>());
      expect(result.length, equals(2));
      expect(result.first, equals('Certificado 1'));
    },
  );
}
