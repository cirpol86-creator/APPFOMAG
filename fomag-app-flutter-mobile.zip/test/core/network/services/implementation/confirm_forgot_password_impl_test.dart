import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/confirm_forgot_password_impl.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:fomagapp/data/model/request/confirm_forgot_password/confirm_forgot_password_request.dart';
import 'package:fomagapp/data/model/response/confirm_forgot_password/confirm_forgot_password_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late ConfirmForgotPasswordServiceImpl service;

  setUp(() {
    mockApiClient = MockApiClient();
    service = ConfirmForgotPasswordServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar ConfirmForgotPasswordResponse cuando la confirmación es exitosa',
    () async {
      final request = ConfirmForgotPasswordRequest(
        documentType: '1',
        documentNumber: '123456789',
        password: 'nuevaClave123',
        code: 'ABC123',
      );

      final expectedResponse = ConfirmForgotPasswordResponse(
        message: 'Contraseña actualizada correctamente',
      );

      final httpResponse = HttpResponse<ConfirmForgotPasswordResponse>(
        expectedResponse,
        Response(
          data: expectedResponse,
          requestOptions: RequestOptions(path: ''),
          statusCode: 200,
        ),
      );

      when(
        mockApiClient.confirmForgotPassword(request),
      ).thenAnswer((_) async => httpResponse);

      final result = await service.call(request);

      expect(result.message, 'Contraseña actualizada correctamente');
    },
  );
}
