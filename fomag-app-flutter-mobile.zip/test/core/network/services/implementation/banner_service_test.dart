import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/banner_service_impl.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:retrofit/dio.dart';
import 'package:dio/dio.dart';

import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/data/model/response/banner/banner_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

@GenerateMocks([ApiClient])
void main() {
  late MockApiClient mockApiClient;
  late BannerServiceImpl bannerService;

  setUp(() {
    mockApiClient = MockApiClient();
    bannerService = BannerServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar BannerResponse cuando el servicio responde correctamente',
    () async {
      final mockResponse = BannerResponse(
        message: 'Banner retrieved successfully',
        type: 'video',
        url: 'https://example.com/banner.mp4',
      );

      final httpResponse = HttpResponse(
        mockResponse,
        Response(
          requestOptions: RequestOptions(path: '/banner'),
          statusCode: 200,
        ),
      );

      when(mockApiClient.getBanner()).thenAnswer((_) async => httpResponse);

      final result = await bannerService.getBanner();

      expect(result.message, equals('Banner retrieved successfully'));
      expect(result.type, equals('video'));
      expect(result.url, equals('https://example.com/banner.mp4'));

      verify(mockApiClient.getBanner()).called(1);
    },
  );
}
