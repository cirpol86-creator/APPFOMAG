import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:fomagapp/core/network/services/implementation/delete_account_service_impl.dart';
import 'package:fomagapp/data/model/response/account/delete/delete_account_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late DeleteAccountServiceImpl deleteAccountService;

  setUp(() {
    mockApiClient = MockApiClient();
    deleteAccountService = DeleteAccountServiceImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar DeleteAccountResponse cuando se elimina correctamente la cuenta',
    () async {
      final expectedResponse = DeleteAccountResponse(
        message: 'Cuenta eliminada con éxito',
      );

      final httpResponse = HttpResponse<DeleteAccountResponse>(
        expectedResponse,
        Response(
          data: expectedResponse.toJson(),
          requestOptions: RequestOptions(path: ''),
          statusCode: 200,
        ),
      );

      when(mockApiClient.deleteAccount()).thenAnswer((_) async => httpResponse);

      final result = await deleteAccountService.deleteAccount();

      expect(result.message, 'Cuenta eliminada con éxito');
    },
  );
}
