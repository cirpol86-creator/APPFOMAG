import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:fomagapp/core/network/services/implementation/cities_impl.dart';
import 'package:fomagapp/data/model/response/cities/cities_response.dart';
import 'package:fomagapp/data/model/response/generic/generic_response.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late MockApiClient mockApiClient;
  late CitiesImpl citiesService;

  setUp(() {
    mockApiClient = MockApiClient();
    citiesService = CitiesImpl(apiClient: mockApiClient);
  });

  test(
    'debe retornar una lista de CitiesResponse cuando la llamada es exitosa',
    () async {
      const departmentId = 5;

      final citiesList = [
        CitiesResponse(id: 1, name: 'Bogotá', departmentId: departmentId),
        CitiesResponse(id: 2, name: 'Medellín', departmentId: departmentId),
      ];

      final genericResponse = GenericResponse<List<CitiesResponse>>(
        content: citiesList,
      );

      final httpResponse = HttpResponse<GenericResponse<List<CitiesResponse>>>(
        genericResponse,
        Response(
          data: citiesList,
          requestOptions: RequestOptions(path: ''),
          statusCode: 200,
        ),
      );

      when(
        mockApiClient.getCities(departmentId),
      ).thenAnswer((_) async => httpResponse);

      final result = await citiesService.call(departmentId);

      expect(result.length, 2);
      expect(result[0].name, 'Bogotá');
      expect(result[1].id, 2);
    },
  );
}
