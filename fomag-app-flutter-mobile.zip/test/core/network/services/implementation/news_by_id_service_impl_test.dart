import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/news_id_by_service_impl.dart';
import 'package:fomagapp/data/model/response/news_by_id/news_by_id_response.dart';
import 'package:mockito/mockito.dart';
import 'package:retrofit/dio.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late NewsByIdServiceImpl service;
  late MockApiClient mockApiClient;

  setUp(() {
    mockApiClient = MockApiClient();
    service = NewsByIdServiceImpl(apiClient: mockApiClient);
  });

  test('debe retornar NewsByIdResponse cuando se consulta por ID', () async {
    const newsId = 101;

    final mockResponse = NewsByIdResponse(
      httpCode: 200,
      message: 'Noticia encontrada',
      content: NewsByIdContent(
        id: newsId,
        title: 'Título de la noticia',
        imagebanner: 'https://url-imagen.com/banner.jpg',
        idReference: 42,
        body: 'Contenido completo de la noticia.',
        date: '2025-07-07',
      ),
    );

    final httpResponse = HttpResponse(
      mockResponse,
      Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
    );

    when(
      mockApiClient.getNewById(newsId),
    ).thenAnswer((_) async => httpResponse);

    final result = await service.call(newsId);

    expect(result.httpCode, equals(200));
    expect(result.message, equals('Noticia encontrada'));
    expect(result.content.id, equals(newsId));
    expect(result.content.title, equals('Título de la noticia'));
  });
}
