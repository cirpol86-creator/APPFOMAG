import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/network/services/implementation/logout_impl.dart';
import 'package:fomagapp/data/model/request/logout/logout_request.dart';
import 'package:mockito/mockito.dart';
import 'package:retrofit/dio.dart';

import '../../../../mock/network/mock_api_client.mocks.dart';

void main() {
  late LogoutServiceImpl service;
  late MockApiClient mockApiClient;

  setUp(() {
    mockApiClient = MockApiClient();
    service = LogoutServiceImpl(apiClient: mockApiClient);
  });

  test('debe llamar al logout del ApiClient con el request correcto', () async {
    final request = LogoutRequest(accessToken: 'token123');

    when(mockApiClient.logout(request)).thenAnswer(
      (_) async => HttpResponse(
        null,
        Response(requestOptions: RequestOptions(path: ''), statusCode: 200),
      ),
    );

    await service.call(request);

    verify(mockApiClient.logout(request)).called(1);
  });
}
