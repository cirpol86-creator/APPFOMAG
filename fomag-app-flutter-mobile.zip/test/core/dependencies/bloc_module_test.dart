import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fomagapp/core/dependencies/bloc_module.dart';
import 'package:fomagapp/core/dependencies/usecase_module.dart';
import 'package:fomagapp/core/dependencies/repository_module.dart';
import 'package:fomagapp/core/dependencies/services_module.dart';
import 'package:fomagapp/core/dependencies/client_module.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';
import 'package:fomagapp/presentation/login/bloc/login_bloc.dart';
import 'package:fomagapp/presentation/health/bloc/health_center_bloc.dart';
import 'package:fomagapp/presentation/home/bloc/home_bloc.dart';
import 'package:fomagapp/presentation/login/usecase/login_usecase.dart';
import 'package:fomagapp/presentation/otp_verification/bloc/otp_verification_bloc.dart';
import 'package:fomagapp/presentation/password_reset/bloc/password_reset_bloc.dart';

import 'package:fomagapp/presentation/password_reset/usecase/send_email_code_usecase.dart';
import 'package:fomagapp/presentation/register/bloc/register_bloc.dart';
import 'package:fomagapp/presentation/register/usecase/register_usecase.dart';
import 'package:mockito/mockito.dart';
import 'package:fomagapp/presentation/health/usecase/get_health_center_usecase.dart';
import 'package:fomagapp/presentation/otp_verification/usecase/otp_verification_usecase.dart';

// Mocks de los use cases
class MockLoginUseCase extends Mock implements LoginUseCase {}

class MockGetHealthCenterUsecase extends Mock
    implements GetHealthCenterUsecase {}

class MockOtpVerificationUseCase extends Mock
    implements OtpVerificationUseCase {}

class MockRegisterUseCase extends Mock implements RegisterUseCase {}

class MockSendEmailCodeUseCase extends Mock implements SendCodeUseCase {}

class TestBlocModule
    with
        ConfigModule,
        ClientModule,
        ServiceModule,
        RepositoryModule,
        UseCaseModule,
        BlocModule {
  @override
  LoginUseCase get loginUseCase => MockLoginUseCase();
  @override
  GetHealthCenterUsecase get getHealthCenterUsecase =>
      MockGetHealthCenterUsecase();
  @override
  OtpVerificationUseCase get otpVerificationUseCase =>
      MockOtpVerificationUseCase();
  @override
  RegisterUseCase get registerUseCase => MockRegisterUseCase();
  @override
  SendCodeUseCase get sendEmailCodeUseCase => MockSendEmailCodeUseCase();
}

void main() {
  late TestBlocModule blocModule;

  setUp(() {
    blocModule = TestBlocModule();
  });

  group('BlocModule', () {
    // ...existing code...
    test('should provide all bloc providers', () {
      final providers = blocModule.blocProviders;

      expect(providers.length, 6);

      // Test each provider's type
      expect(providers[0], isA<BlocProvider<LoginBloc>>());
      expect(providers[1], isA<BlocProvider<HealthCenterBloc>>());
      expect(providers[2], isA<BlocProvider<HomeBloc>>());
      expect(providers[3], isA<BlocProvider<OtpVerificationBloc>>());
      expect(providers[4], isA<BlocProvider<RegisterBloc>>());
      expect(providers[5], isA<BlocProvider<PasswordResetBloc>>());
    });

    test('LoginBloc provider should be created with loginUseCase', () {
      final providers = blocModule.blocProviders;
      final loginProvider = providers[0];
      expect(loginProvider, isA<BlocProvider<LoginBloc>>());
    });

    test(
      'HealthCenterBloc provider should be created with getHealthCenterUsecase',
      () {
        final providers = blocModule.blocProviders;
        final healthCenterProvider = providers[1];
        expect(healthCenterProvider, isA<BlocProvider<HealthCenterBloc>>());
      },
    );

    test(
      'OtpVerificationBloc provider should be created with otpVerificationUseCase',
      () {
        final providers = blocModule.blocProviders;
        final otpProvider = providers[3];
        expect(otpProvider, isA<BlocProvider<OtpVerificationBloc>>());
      },
    );

    test(
      'PasswordResetBloc provider should be created with passwordResetUseCase',
      () {
        final providers = blocModule.blocProviders;
        final passwordResetProvider = providers[5];
        expect(passwordResetProvider, isA<BlocProvider<PasswordResetBloc>>());
      },
    );

    test('RegisterBloc provider should be created with registerUseCase', () {
      final providers = blocModule.blocProviders;
      final registerProvider = providers[4];
      expect(registerProvider, isA<BlocProvider<RegisterBloc>>());
    });
  });
}

class MockBuildContext extends BuildContext {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}
