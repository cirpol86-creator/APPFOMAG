import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';

class TestClass with ConfigModule {}

void main() {
  group('ConfigModule', () {
    test('appConfig getter returns AppConfig.shared', () {
      final testClass = TestClass();

      // Verify that appConfig returns the shared instance
      expect(testClass.appConfig, equals(AppConfig.shared));
      expect(identical(testClass.appConfig, AppConfig.shared), isTrue);
    });

    test('multiple instances return the same config', () {
      final testClass1 = TestClass();
      final testClass2 = TestClass();

      // Verify that different instances return the same config
      expect(testClass1.appConfig, equals(testClass2.appConfig));
      expect(identical(testClass1.appConfig, testClass2.appConfig), isTrue);
    });

    test('appConfig is of type AppConfig', () {
      final testClass = TestClass();

      // Verify that appConfig is of the correct type
      expect(testClass.appConfig, isA<AppConfig>());
    });
  });
}
