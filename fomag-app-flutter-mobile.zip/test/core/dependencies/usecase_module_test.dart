import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/dependencies/usecase_module.dart';
import 'package:fomagapp/core/dependencies/repository_module.dart';
import 'package:fomagapp/core/dependencies/services_module.dart';
import 'package:fomagapp/core/dependencies/client_module.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';
import 'package:fomagapp/presentation/login/usecase/login_usecase.dart';
import 'package:fomagapp/presentation/register/usecase/register_usecase.dart';
import 'package:fomagapp/presentation/health/usecase/get_health_center_usecase.dart';
import 'package:fomagapp/presentation/otp_verification/usecase/otp_verification_usecase.dart';

class TestUseCaseModule
    with
        ConfigModule,
        ClientModule,
        ServiceModule,
        RepositoryModule,
        UseCaseModule {}

void main() {
  late TestUseCaseModule useCaseModule;

  setUp(() {
    useCaseModule = TestUseCaseModule();
  });

  group('UseCaseModule', () {
    test('should provide LoginUseCase instance', () {
      expect(useCaseModule.loginUseCase, isA<LoginUseCase>());
    });

    test('should provide RegisterUseCase instance', () {
      expect(useCaseModule.registerUseCase, isA<RegisterUseCase>());
    });

    test('should provide GetHealthCenterUsecase instance', () {
      expect(
        useCaseModule.getHealthCenterUsecase,
        isA<GetHealthCenterUsecase>(),
      );
    });

    test('should provide OtpVerificationUseCase instance', () {
      expect(
        useCaseModule.otpVerificationUseCase,
        isA<OtpVerificationUseCase>(),
      );
    });
  });
}
