import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/dependencies/client_module.dart';
import 'package:fomagapp/core/network/api_client.dart';
import 'package:fomagapp/core/config/app_config.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';

class TestClass with ConfigModule, ClientModule {}

void main() {
  group('ClientModule', () {
    test('apiClient returns ApiClient instance', () {
      final testClass = TestClass();

      // Verify that apiClient returns an ApiClient instance
      expect(testClass.apiClient, isA<ApiClient>());
    });

    test('inherits from ConfigModule', () {
      final testClass = TestClass();

      // Verify that we can access appConfig from ConfigModule
      expect(testClass.appConfig, equals(AppConfig.shared));
    });
  });
}
