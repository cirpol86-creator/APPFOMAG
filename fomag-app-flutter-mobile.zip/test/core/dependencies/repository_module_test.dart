import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/dependencies/repository_module.dart';
import 'package:fomagapp/core/dependencies/services_module.dart';
import 'package:fomagapp/core/dependencies/client_module.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';
import 'package:fomagapp/data/repositories/departments_health_center_repository.dart';
import 'package:fomagapp/data/repositories/login_repository.dart';
import 'package:fomagapp/data/repositories/health_center_repository.dart';
import 'package:fomagapp/data/repositories/otp_verification_repository.dart';
import 'package:fomagapp/data/repositories/register_repository.dart';

class TestRepositoryModule
    with ConfigModule, ClientModule, ServiceModule, RepositoryModule {}

void main() {
  late TestRepositoryModule repositoryModule;

  setUp(() {
    repositoryModule = TestRepositoryModule();
  });

  group('RepositoryModule', () {
    test('should provide LoginRepository instance', () {
      expect(repositoryModule.loginRepository, isA<LoginRepository>());
    });

    test('should provide RegisterRepository instance', () {
      expect(repositoryModule.registerRepository, isA<RegisterRepository>());
    });

    test('should provide HealthCenterRepository instance', () {
      expect(
        repositoryModule.healthCenterRepository,
        isA<HealthCenterRepository>(),
      );
    });

    test('should provide DepartmentsRepository instance', () {
      expect(
        repositoryModule.departmentsHealthCenterRepository,
        isA<DepartmentsHealthCenterRepository>(),
      );
    });

    test('should provide OtpVerificationRepository instance', () {
      expect(
        repositoryModule.otpVerificationRepository,
        isA<OtpVerificationRepository>(),
      );
    });
  });
}
