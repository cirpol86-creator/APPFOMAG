import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/dependencies/client_module.dart';
import 'package:fomagapp/core/dependencies/config_module.dart';
import 'package:fomagapp/core/dependencies/services_module.dart';
import 'package:fomagapp/core/network/services/implementation/login_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/otp_validate_service_impl.dart';
import 'package:fomagapp/core/network/services/implementation/register_service_impl.dart';
import 'package:fomagapp/core/network/services/abstract/login_service.dart';
import 'package:fomagapp/core/network/services/abstract/otp_validate_service.dart';
import 'package:fomagapp/core/network/services/abstract/register_service.dart';

// Create a test class that uses the ServiceModule
class TestServiceModule with ConfigModule, ClientModule, ServiceModule {}

void main() {
  late TestServiceModule serviceModule;

  setUp(() {
    serviceModule = TestServiceModule();
  });

  group('ServiceModule', () {
    test('should provide LoginService implementation', () {
      // Act
      final loginService = serviceModule.loginService;

      // Assert
      expect(loginService, isA<LoginServiceImpl>());
      expect(loginService, isA<LoginService>());
    });

    test('should provide RegisterService implementation', () {
      // Act
      final registerService = serviceModule.registerService;

      // Assert
      expect(registerService, isA<RegisterServiceImpl>());
      expect(registerService, isA<RegisterService>());
    });

    test('should provide OtpValidateService implementation', () {
      // Act
      final otpService = serviceModule.otpService;

      // Assert
      expect(otpService, isA<OtpValidateServiceImpl>());
      expect(otpService, isA<OtpValidateService>());
    });
  });
}
