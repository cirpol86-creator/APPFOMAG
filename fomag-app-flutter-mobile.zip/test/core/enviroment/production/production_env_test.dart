import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/enviroment/production/production_env.dart';
import 'package:fomagapp/core/enviroment/environment.dart';

void main() {
  group('ProductionEnvironment', () {
    test('should create production environment with correct base domain', () {
      final env = ProductionEnvironment.production();

      expect(env, isA<Environment>());
      expect(
        env.baseDomain,
        equals('https://appmovilfomag.fiduprevisora.com.co/prd'),
      );
    });

    test('should create a new instance each time', () {
      final env1 = ProductionEnvironment.production();
      final env2 = ProductionEnvironment.production();

      expect(env1, isNot(same(env2)));
      expect(env1.baseDomain, equals(env2.baseDomain));
    });
  });
}
