import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/enviroment/environment.dart';

void main() {
  group('Environment', () {
    test('should create environment with base domain', () {
      const baseDomain = 'https://test.com';
      final env = Environment(baseDomain: baseDomain, envName: 'Test');

      expect(env.baseDomain, equals(baseDomain));
    });

    test('should create production environment through factory', () {
      final env = Environment.production();

      expect(env, isA<Environment>());
      expect(
        env.baseDomain,
        equals('https://appmovilfomag.fiduprevisora.com.co/prd'),
      );
    });

    test('should create development environment through factory', () {
      final env = Environment.development();

      expect(env, isA<Environment>());
      expect(
        env.baseDomain,
        equals('https://1jkwxw263c.execute-api.us-east-1.amazonaws.com/'),
      );
    });

    test('should create development environment through factory', () {
      final env = Environment.quality();

      expect(env, isA<Environment>());
      expect(
        env.baseDomain,
        equals('https://817lfej1sa.execute-api.us-east-1.amazonaws.com/'),
      );
    });

    test('should create different instances for each factory method', () {
      final prodEnv = Environment.production();
      final devEnv = Environment.development();

      expect(prodEnv, isNot(same(devEnv)));
      expect(prodEnv.baseDomain, isNot(equals(devEnv.baseDomain)));
    });

    test('should create quality environment through factory', () {
      final env = Environment.quality();

      expect(env, isA<Environment>());
      expect(env.baseDomain, isNotEmpty);
    });

    test('should create environment with custom remote base URL', () {
      const customUrl = 'https://custom-api.com/';
      final env = Environment.production(remoteBaseUrl: customUrl);

      expect(env.baseDomain, equals(customUrl));
    });

    test(
      'should create development environment with custom remote base URL',
      () {
        const customUrl = 'https://dev-api.com/';
        final env = Environment.development(remoteBaseUrl: customUrl);

        expect(env.baseDomain, equals(customUrl));
      },
    );

    test('should create quality environment with custom remote base URL', () {
      const customUrl = 'https://qa-api.com/';
      final env = Environment.quality(remoteBaseUrl: customUrl);

      expect(env.baseDomain, equals(customUrl));
    });
  });
}
