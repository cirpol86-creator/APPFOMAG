import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/enviroment/development/development_env.dart';
import 'package:fomagapp/core/enviroment/environment.dart';

void main() {
  group('DevelopmentEnvironment', () {
    test('should create development environment with correct base domain', () {
      final env = DevelopmentEnvironment.development();

      expect(env, isA<Environment>());
      expect(
        env.baseDomain,
        equals('https://1jkwxw263c.execute-api.us-east-1.amazonaws.com/'),
      );
    });

    test('should create a new instance each time', () {
      final env1 = DevelopmentEnvironment.development();
      final env2 = DevelopmentEnvironment.development();

      expect(env1, isNot(same(env2)));
      expect(env1.baseDomain, equals(env2.baseDomain));
    });
  });
}
