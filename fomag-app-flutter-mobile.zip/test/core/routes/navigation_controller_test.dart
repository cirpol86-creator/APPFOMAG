import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:go_router/go_router.dart';
import 'package:mockito/mockito.dart';

// Mock para GoRouter
class MockGoRouter extends Mock implements GoRouter {
  final List<String> navigationHistory = [];
  String? currentRoute;

  @override
  void go(String location, {Object? extra}) {
    navigationHistory.add(location);
    currentRoute = location;
  }

  @override
  Future<T?> push<T extends Object?>(String location, {Object? extra}) {
    navigationHistory.add(location);
    currentRoute = location;
    return Future.value(null);
  }

  @override
  Future<T?> replace<T extends Object?>(String location, {Object? extra}) {
    navigationHistory.add(location);
    currentRoute = location;
    return Future.value(null);
  }

  @override
  void pop<T extends Object?>([T? result]) {
    if (navigationHistory.isNotEmpty) {
      navigationHistory.removeLast();
      currentRoute =
          navigationHistory.isNotEmpty ? navigationHistory.last : null;
    }
  }

  @override
  bool canPop() {
    return navigationHistory.length > 1;
  }
}

// Widget para probar NavigationController con un contexto real
class TestNavigation extends StatelessWidget {
  final Widget child;
  final MockGoRouter mockRouter;

  const TestNavigation({
    super.key,
    required this.child,
    required this.mockRouter,
  });

  @override
  Widget build(BuildContext context) {
    return InheritedGoRouter(
      goRouter: mockRouter,
      child: MaterialApp(
        navigatorKey: NavigationController.globalNavigatorKey,
        home: child,
      ),
    );
  }
}

// Widget para envolver GoRouter
class InheritedGoRouter extends InheritedWidget {
  final GoRouter goRouter;

  const InheritedGoRouter({
    super.key,
    required this.goRouter,
    required super.child,
  });

  static InheritedGoRouter of(BuildContext context) {
    final InheritedGoRouter? result =
        context.dependOnInheritedWidgetOfExactType<InheritedGoRouter>();
    assert(result != null, 'No InheritedGoRouter found in context');
    return result!;
  }

  @override
  bool updateShouldNotify(InheritedGoRouter oldWidget) {
    return goRouter != oldWidget.goRouter;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late MockGoRouter mockRouter;

  setUp(() {
    mockRouter = MockGoRouter();
  });

  group('NavigationController - Static Fields', () {
    test('should have a global navigator key', () {
      expect(NavigationController.globalNavigatorKey, isNotNull);
      expect(
        NavigationController.globalNavigatorKey,
        isA<GlobalKey<NavigatorState>>(),
      );
    });

    test('should extend Equatable with proper props', () {
      final controller1 = NavigationController();
      final controller2 = NavigationController();

      // Verificar que dos instancias son iguales
      expect(controller1, equals(controller2));

      // Verificar que los props contienen el globalNavigatorKey
      expect(
        controller1.props,
        equals([NavigationController.globalNavigatorKey]),
      );
    });
  });

  group('TransitionType enum', () {
    test('should have all required transition types', () {
      expect(TransitionType.values.length, equals(4));
      expect(TransitionType.values, contains(TransitionType.fade));
      expect(TransitionType.values, contains(TransitionType.slideRight));
      expect(TransitionType.values, contains(TransitionType.slideUp));
      expect(TransitionType.values, contains(TransitionType.none));
    });
  });

  group('NavigationController.push', () {
    testWidgets('should push a new route', (WidgetTester tester) async {
      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.push('/test-route', router: mockRouter);
                },
                child: const Text('Navigate'),
              );
            },
          ),
        ),
      );

      await tester.tap(find.text('Navigate'));
      await tester.pumpAndSettle();

      expect(mockRouter.navigationHistory.contains('/test-route'), isTrue);
    });

    testWidgets('should replace current route when replace is true', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.push(
                    '/test-route',
                    replace: true,
                    router: mockRouter,
                  );
                },
                child: const Text('Navigate Replace'),
              );
            },
          ),
        ),
      );

      await tester.tap(find.text('Navigate Replace'));
      await tester.pumpAndSettle();

      expect(mockRouter.navigationHistory.contains('/test-route'), isTrue);
    });

    testWidgets('should clean stack when clean is true', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.push(
                    '/test-route',
                    clean: true,
                    router: mockRouter,
                  );
                },
                child: const Text('Navigate Clean'),
              );
            },
          ),
        ),
      );

      await tester.tap(find.text('Navigate Clean'));
      await tester.pumpAndSettle();

      expect(mockRouter.navigationHistory.contains('/test-route'), isTrue);
    });

    testWidgets('should pass arguments to the route', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.push(
                    '/test-route',
                    arguments: {'id': 123},
                    router: mockRouter,
                  );
                },
                child: const Text('Navigate With Args'),
              );
            },
          ),
        ),
      );

      await tester.tap(find.text('Navigate With Args'));
      await tester.pumpAndSettle();

      expect(mockRouter.navigationHistory.contains('/test-route'), isTrue);
    });
  });

  group('NavigationController.drawerItemTap', () {
    testWidgets('should go to login route when login route is tapped', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.drawerItemTap(
                    Routes.login.routePath,
                    router: mockRouter,
                  );
                },
                child: const Text('Go to Login'),
              );
            },
          ),
        ),
      );

      await tester.tap(find.text('Go to Login'));
      await tester.pumpAndSettle();

      expect(
        mockRouter.navigationHistory.contains(Routes.login.routePath),
        isTrue,
      );
    });

    testWidgets('should push other routes when not login', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.drawerItemTap(
                    Routes.home.routePath,
                    router: mockRouter,
                  );
                },
                child: const Text('Go to Home'),
              );
            },
          ),
        ),
      );

      await tester.tap(find.text('Go to Home'));
      await tester.pumpAndSettle();

      expect(
        mockRouter.navigationHistory.contains(Routes.home.routePath),
        isTrue,
      );
    });
  });

  group('NavigationController.pop', () {
    testWidgets('should pop the current route if can pop', (
      WidgetTester tester,
    ) async {
      // Preparar el router con una historia de navegación
      mockRouter.navigationHistory.addAll(['/first', '/second']);

      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.pop(router: mockRouter);
                },
                child: const Text('Go Back'),
              );
            },
          ),
        ),
      );

      expect(mockRouter.navigationHistory.length, 2);

      await tester.tap(find.text('Go Back'));
      await tester.pumpAndSettle();

      expect(mockRouter.navigationHistory.length, 1);
      expect(mockRouter.navigationHistory.last, equals('/first'));
    });

    testWidgets('should not pop if cannot pop', (WidgetTester tester) async {
      // Router con solo una ruta en la historia
      mockRouter.navigationHistory.add('/first');

      await tester.pumpWidget(
        TestNavigation(
          mockRouter: mockRouter,
          child: Builder(
            builder: (context) {
              return ElevatedButton(
                onPressed: () {
                  NavigationController.pop(router: mockRouter);
                },
                child: const Text('Try Pop'),
              );
            },
          ),
        ),
      );

      expect(mockRouter.navigationHistory.length, 1);

      await tester.tap(find.text('Try Pop'));
      await tester.pumpAndSettle();

      // No debería cambiar la historia
      expect(mockRouter.navigationHistory.length, 1);
      expect(mockRouter.navigationHistory.last, equals('/first'));
    });
  });

  group('Routes Extensions', () {
    test('Routes extension methods should work correctly', () {
      // Probar que podemos obtener la ruta y el nombre de las rutas
      expect(Routes.home.routePath, '/home');
      expect(Routes.home.routeName, 'home');

      expect(Routes.splashScreen.routePath, '/splashScreen');
      expect(Routes.splashScreen.routeName, 'splashScreen');

      expect(Routes.login.routePath, '/login');
      expect(Routes.login.routeName, 'login');

      expect(Routes.register.routePath, '/register');
      expect(Routes.register.routeName, 'register');

      // Probar más rutas
      expect(Routes.profile.routePath, '/profile');
      expect(Routes.profile.routeName, 'profile');

      expect(Routes.pqr.routePath, '/pqr');
      expect(Routes.pqr.routeName, 'pqr');

      expect(Routes.createPqr.routePath, '/createPqr');
      expect(Routes.createPqr.routeName, 'createPqr');
    });
  });
}
