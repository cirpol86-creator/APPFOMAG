import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/routes/name_routes.dart';
import 'package:fomagapp/core/routes/routes.dart';

void main() {
  group('NamedRoute', () {
    test('should extend Equatable', () {
      final route1 = NamedRoute(appRoute: AppRoute.home);
      final route2 = NamedRoute(appRoute: AppRoute.home);
      final route3 = NamedRoute(appRoute: AppRoute.login);

      // Same AppRoute should make objects equal
      expect(route1, equals(route2));

      // Different AppRoute should make objects not equal
      expect(route1, isNot(equals(route3)));

      // Props should contain all equality components
      expect(route1.props, equals([AppRoute.home, 'home', '/home']));
    });

    test('routeName should return the name of the AppRoute', () {
      expect(
        NamedRoute(appRoute: AppRoute.unknown).routeName,
        equals('unknown'),
      );
      expect(
        NamedRoute(appRoute: AppRoute.splashScreen).routeName,
        equals('splashScreen'),
      );
      expect(NamedRoute(appRoute: AppRoute.login).routeName, equals('login'));
      expect(NamedRoute(appRoute: AppRoute.home).routeName, equals('home'));
      expect(
        NamedRoute(appRoute: AppRoute.register).routeName,
        equals('register'),
      );
    });

    test('routePath should return the name with a leading slash', () {
      expect(
        NamedRoute(appRoute: AppRoute.unknown).routePath,
        equals('/unknown'),
      );
      expect(
        NamedRoute(appRoute: AppRoute.splashScreen).routePath,
        equals('/splashScreen'),
      );
      expect(NamedRoute(appRoute: AppRoute.login).routePath, equals('/login'));
      expect(NamedRoute(appRoute: AppRoute.home).routePath, equals('/home'));
      expect(
        NamedRoute(appRoute: AppRoute.register).routePath,
        equals('/register'),
      );
    });

    test('should work with all AppRoute values', () {
      // For each enum value, create a NamedRoute and verify its properties
      for (final route in AppRoute.values) {
        final namedRoute = NamedRoute(appRoute: route);

        expect(namedRoute.appRoute, equals(route));
        expect(namedRoute.routeName, equals(route.name));
        expect(namedRoute.routePath, equals('/${route.name}'));
      }
    });

    test('constructor should require appRoute parameter', () {
      // This test verifies the constructor requires the appRoute parameter
      const namedRoute = NamedRoute(appRoute: AppRoute.home);
      expect(namedRoute.appRoute, equals(AppRoute.home));
    });
  });
}
