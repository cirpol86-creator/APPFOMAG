import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/routes/name_routes.dart';
import 'package:fomagapp/core/routes/routes.dart';

void main() {
  group('AppRoute Enum', () {
    test('should contain all required routes', () {
      // Test that all expected routes are defined in the enum
      expect(AppRoute.values.length, equals(18));

      // Test individual enum values exist
      expect(AppRoute.unknown, isA<AppRoute>());
      expect(AppRoute.splashScreen, isA<AppRoute>());
      expect(AppRoute.login, isA<AppRoute>());
      expect(AppRoute.healthcenter, isA<AppRoute>());
      expect(AppRoute.home, isA<AppRoute>());
      expect(AppRoute.register, isA<AppRoute>());
      expect(AppRoute.pqr, isA<AppRoute>());
      expect(AppRoute.createPqr, isA<AppRoute>());
      expect(AppRoute.contact, isA<AppRoute>());
      expect(AppRoute.certificates, isA<AppRoute>());
      expect(AppRoute.profile, isA<AppRoute>());
      expect(AppRoute.otpVerification, isA<AppRoute>());
      expect(AppRoute.suspendedAccount, isA<AppRoute>());
      expect(AppRoute.progressLoader, isA<AppRoute>());
      expect(AppRoute.listNews, isA<AppRoute>());
      expect(AppRoute.newInfo, isA<AppRoute>());
      expect(AppRoute.survey, isA<AppRoute>());
      expect(AppRoute.passwordReset, isA<AppRoute>());
    });

    test('enum values should have correct names', () {
      // Test enum values have the expected string representations
      expect(AppRoute.unknown.name, equals('unknown'));
      expect(AppRoute.splashScreen.name, equals('splashScreen'));
      expect(AppRoute.login.name, equals('login'));
      expect(AppRoute.healthcenter.name, equals('healthcenter'));
      expect(AppRoute.home.name, equals('home'));
      expect(AppRoute.register.name, equals('register'));
    });
  });

  group('Routes Class', () {
    test('should extend Equatable', () {
      // Test Routes class is properly extending Equatable
      expect(Routes().props, isEmpty);
    });

    test('should provide NamedRoute getters for each AppRoute', () {
      // Test each getter in the Routes class returns the correct NamedRoute
      expect(Routes.unknown, isA<NamedRoute>());
      expect(Routes.unknown.appRoute, equals(AppRoute.unknown));

      expect(Routes.splashScreen, isA<NamedRoute>());
      expect(Routes.splashScreen.appRoute, equals(AppRoute.splashScreen));

      expect(Routes.login, isA<NamedRoute>());
      expect(Routes.login.appRoute, equals(AppRoute.login));

      expect(Routes.healthcenter, isA<NamedRoute>());
      expect(Routes.healthcenter.appRoute, equals(AppRoute.healthcenter));

      expect(Routes.home, isA<NamedRoute>());
      expect(Routes.home.appRoute, equals(AppRoute.home));

      expect(Routes.register, isA<NamedRoute>());
      expect(Routes.register.appRoute, equals(AppRoute.register));

      expect(Routes.pqr, isA<NamedRoute>());
      expect(Routes.pqr.appRoute, equals(AppRoute.pqr));

      expect(Routes.createPqr, isA<NamedRoute>());
      expect(Routes.createPqr.appRoute, equals(AppRoute.createPqr));

      expect(Routes.contact, isA<NamedRoute>());
      expect(Routes.contact.appRoute, equals(AppRoute.contact));

      expect(Routes.profile, isA<NamedRoute>());
      expect(Routes.profile.appRoute, equals(AppRoute.profile));

      expect(Routes.certificates, isA<NamedRoute>());
      expect(Routes.certificates.appRoute, equals(AppRoute.certificates));

      expect(Routes.otpVerification, isA<NamedRoute>());
      expect(Routes.otpVerification.appRoute, equals(AppRoute.otpVerification));

      expect(Routes.progressLoader, isA<NamedRoute>());
      expect(Routes.progressLoader.appRoute, equals(AppRoute.progressLoader));

      expect(Routes.listNews, isA<NamedRoute>());
      expect(Routes.listNews.appRoute, equals(AppRoute.listNews));

      expect(Routes.newInfo, isA<NamedRoute>());
      expect(Routes.newInfo.appRoute, equals(AppRoute.newInfo));

      expect(Routes.survey, isA<NamedRoute>());
      expect(Routes.survey.appRoute, equals(AppRoute.survey));

      expect(Routes.passwordReset, isA<NamedRoute>());
      expect(Routes.passwordReset.appRoute, equals(AppRoute.passwordReset));
    });

    test('should have a getter for each AppRoute enum value', () {
      // Test that every enum value has a corresponding getter in Routes
      final appRouteValues = AppRoute.values;

      // Get a list of all the route getters by creating a map and checking the appRoute property
      final routeGetters = {
        Routes.unknown.appRoute,
        Routes.splashScreen.appRoute,
        Routes.login.appRoute,
        Routes.healthcenter.appRoute,
        Routes.home.appRoute,
        Routes.register.appRoute,
        Routes.pqr.appRoute,
        Routes.createPqr.appRoute,
        Routes.contact.appRoute,
        Routes.certificates.appRoute,
        Routes.profile.appRoute,
        Routes.otpVerification.appRoute,
        Routes.progressLoader.appRoute,
        Routes.listNews.appRoute,
        Routes.newInfo.appRoute,
        Routes.survey.appRoute,
        Routes.passwordReset.appRoute,
        Routes.suspendedAccount.appRoute,
      };

      // Check that every enum value has a corresponding getter
      for (final route in appRouteValues) {
        expect(
          routeGetters.contains(route),
          isTrue,
          reason: 'Missing Routes getter for AppRoute.${route.name}',
        );
      }

      // Check that all getters correspond to a valid enum value
      expect(
        routeGetters.length,
        equals(appRouteValues.length),
        reason:
            'Number of Routes getters does not match number of AppRoute values',
      );
    });
  });
}
