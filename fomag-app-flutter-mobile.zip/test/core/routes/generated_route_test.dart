import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fomagapp/core/routes/generated_route.dart';
import 'package:fomagapp/core/routes/navigation_controller.dart';
import 'package:fomagapp/core/routes/routes.dart';
import 'package:fomagapp/presentation/app.dart';
import 'package:fomagapp/presentation/splash/not_found_page.dart';
import 'package:go_router/go_router.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('RouterManager', () {
    test('should extend Equatable', () {
      final manager1 = RouterManager();
      final manager2 = RouterManager();

      // Two instances should be equal
      expect(manager1, equals(manager2));

      // But they should be different instances (not singleton)
      expect(identical(manager1, manager2), isFalse);

      // Props should be empty list
      expect(manager1.props, isEmpty);
    });

    group('Router configuration', () {
      test('router should be a GoRouter instance', () {
        expect(RouterManager.router, isA<GoRouter>());
      });

      test('router should use the NavigationController globalNavigatorKey', () {
        expect(
          RouterManager.router.routerDelegate.navigatorKey,
          equals(NavigationController.globalNavigatorKey),
        );
      });

      test('router should have splashScreen as initialLocation', () {
        // Verificar que la ruta inicial sea la correcta
        final goRouter = RouterManager.router;
        expect(goRouter, isNotNull);
        expect(goRouter.configuration, isA<RouteConfiguration>());
        expect(
          goRouter.routeInformationProvider.value.uri.path,
          Routes.splashScreen.routePath,
        );
        expect(goRouter.routeInformationProvider, isNotNull);
        expect(goRouter.routeInformationParser, isNotNull);
      });

      testWidgets(
        'router should have errorBuilder configured to return NotFoundPage',
        (tester) async {
          final GoRouter router = RouterManager.router;
          final String newPath = '/ruta-no-existe';

          await tester.pumpWidget(const MyApp());

          await tester.pumpAndSettle();
          router.go(newPath);
          await tester.pumpAndSettle();

          expect(router.routeInformationProvider.value.uri.path, newPath);
          expect(find.byType(NotFoundPage), findsOneWidget);
        },
      );
    });

    group('Routes', () {
      test('routes should be configured for all app routes', () {
        final routes = RouterManager.router.configuration.routes;

        // Verify we have routes
        expect(routes, isNotEmpty);

        // Verificar que tenemos exactamente 11 rutas configuradas
        expect(routes.whereType<GoRoute>().length, equals(17));

        // Get all paths
        final paths =
            routes.whereType<GoRoute>().map((route) => route.path).toList();

        // Check for required paths
        expect(paths, contains(Routes.splashScreen.routePath));
        expect(paths, contains(Routes.home.routePath));
        expect(paths, contains(Routes.login.routePath));
        expect(paths, contains(Routes.register.routePath));
        expect(paths, contains(Routes.otpVerification.routePath));
        expect(paths, contains(Routes.healthcenter.routePath));
        expect(paths, contains(Routes.certificates.routePath));
        expect(paths, contains(Routes.profile.routePath));
        expect(paths, contains(Routes.pqr.routePath));
        expect(paths, contains(Routes.createPqr.routePath));
        expect(paths, contains(Routes.contact.routePath));
        expect(paths, contains(Routes.suspendedAccount.routePath));
        expect(paths, contains(Routes.progressLoader.routePath));
      });

      test('routes should include names from Routes class', () {
        final routes = RouterManager.router.configuration.routes;

        // Get all route names
        final names =
            routes.whereType<GoRoute>().map((route) => route.name).toList();

        // Check for required names
        expect(names, contains(Routes.splashScreen.routeName));
        expect(names, contains(Routes.home.routeName));
        expect(names, contains(Routes.login.routeName));
        expect(names, contains(Routes.register.routeName));
        expect(names, contains(Routes.otpVerification.routeName));
        expect(names, contains(Routes.healthcenter.routeName));
        expect(names, contains(Routes.certificates.routeName));
        expect(names, contains(Routes.profile.routeName));
        expect(names, contains(Routes.pqr.routeName));
        expect(names, contains(Routes.createPqr.routeName));
        expect(names, contains(Routes.contact.routeName));
        expect(names, contains(Routes.suspendedAccount.routeName));
      });

      test(
        'each route should have the correct builder function configured',
        () {
          final routes = RouterManager.router.configuration.routes;

          // Crear un mapa de rutas para facilitar las pruebas
          final routeMap = <String, GoRoute>{};
          for (final route in routes.whereType<GoRoute>()) {
            routeMap[route.path] = route;
          }

          // Verificar que cada ruta tenga la función builder configurada
          expect(
            routeMap[Routes.splashScreen.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.home.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.login.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.register.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.otpVerification.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.healthcenter.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.certificates.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.profile.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.pqr.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.createPqr.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.contact.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
          expect(
            routeMap[Routes.suspendedAccount.routePath]!.builder,
            isA<Widget? Function(BuildContext, GoRouterState)>(),
          );
        },
      );
    });
  });
}
